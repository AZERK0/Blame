import { createTool } from "@cline/sdk";
import { redactSecurityValue } from "../security-secret-redaction.js";
import { lightEditCodeInputSchema, lightReadCodeInputSchema, lightRunTaskInputSchema, lightSearchCodeInputSchema, } from "./light-contracts.js";
import { lightToolContext } from "./light-executor.js";
import { LightWorkspace } from "./light-workspace.js";
export const lightReadToolNames = ["search_code", "read_code"];
export const lightWriteToolNames = ["edit_code", "run_task"];
export function lightSemanticHarnessTools(workspaceRoot, options = {}) {
    if (!workspaceRoot)
        return [];
    const workspace = options.executor
        ? executorWorkspace(workspaceRoot, options)
        : new LightWorkspace(workspaceRoot, {
            refreshPreviewDependencies: options.refreshPreviewDependencies,
            sessionId: options.taskContract?.session_id ?? "unscoped-session",
            taskContract: options.taskContract,
        });
    return lightWorkspaceTools(workspace, options.taskContract?.environment);
}
function executorWorkspace(workspaceRoot, options) {
    const invoke = executorInvocation(workspaceRoot, options);
    return {
        editCode: (input, context) => invoke("edit_code", input, lightToolContext(context), context?.signal),
        readCode: (input, context) => invoke("read_code", input, lightToolContext(context), context.signal),
        runTask: (input, context) => invoke("run_task", input, lightToolContext(context), context.signal),
        searchCode: (input, signal) => invoke("search_code", input, {}, signal),
    };
}
function executorInvocation(workspaceRoot, options) {
    return (tool, input, context = {}, signal) => options.executor({
        input,
        taskContract: options.taskContract,
        tool,
        toolContext: context,
        workspaceRoot,
    }, signal);
}
function lightWorkspaceTools(workspace, environment) {
    return [
        searchCodeTool(workspace),
        readCodeTool(workspace),
        editCodeTool(workspace),
        runTaskTool(workspace, environment),
    ];
}
function searchCodeTool(workspace) {
    return harnessTool({
        name: "search_code",
        description: 'Find source by path, text, symbol, or references. For JS/TS semantic references, set mode to references and query to a symbol sN alias or path#qualifiedName; results state compiler project scope and any lexical fallback. Bare-name fallback proposes nextSearches; choose the intended declaration. Search results do not authorize edits: read the target first. Whitespace separates query terms; punctuation stays literal. Scope accepts paths and *, **, ?, or {a,b} globs; multiple scopes use an array such as ["src","spec"]. Spaces in a scope string are literal. Returns up to eight short results; generated outputs and node_modules are excluded.',
        schema: lightSearchCodeInputSchema,
        execute: (input, context) => workspace.searchCode(input, context.signal),
    });
}
function readCodeTool(workspace) {
    return harnessTool({
        name: "read_code",
        description: "Read a text file or local image, compact directory, sN alias, path#qualifiedName, @changes, @checks, or @capabilities. @checks lists current-source check observations without running them; unknown counts stay null. A line range selects those lines; otherwise omit view for automatic raw/outline routing. Truncated reads propose nextRead and outline routes without granting unseen coverage. Use view signature on a symbol to inspect its declaration header without its body; read the symbol body before behavioral edits or rename. Symbol outlines list contained declarations. Results expose editTargets and containedBy relationships. Generated outputs and ordinary node_modules reads are excluded. For installed dependency types, use view declaration with localFile#importBinding or localFile#importBinding.exportedMember: the configured JS/TS compiler resolves a bounded read-only declaration with package/version identity. This grants no edit coverage and does not establish dependency runtime behavior; follow nextRead for continuation.",
        schema: lightReadCodeInputSchema,
        execute: (input, context) => workspace.readCode(input, context),
    });
}
function editCodeTool(workspace) {
    return harnessTool({
        name: "edit_code",
        description: 'Atomically apply symbol operations or focused Cline patches. Each operation uses kind "symbol" or "patch"; symbol edits put the edit action in action. Example: {"operations":[{"kind":"symbol","target":"s1","action":"replace_body","content":"return 2;"}]}. For configured JS/TS, action "rename" with content containing only the new identifier computes related edits via the compiler, preserving existing aliases; first read the complete target declaration. Rename must be the sole operation in a batch; unavailable/incomplete projects or name capture are blocked. Its static guard is not test evidence; run required checks after editing. Set patch target to an observed sN alias to restrict one Update File to that symbol; the header must match its file. Choose the smaller precise edit: replace_body replaces the entire observed body. For a brace-delimited body, unbraced content inherits existing indentation; one-line content becomes inline. Include the outer braces to preserve explicit layout, or use a file patch. For a new file, patch may contain complete raw text; existing files require Cline patch syntax. Do not combine a parent with its containedBy child. The runtime handles freshness, overlaps, and supported syntax checks.',
        schema: lightEditCodeInputSchema,
        execute: (input, context) => workspace.editCode(input, {
            sessionId: context.sessionId,
            toolCallId: context.toolCallId,
            signal: context.signal,
        }),
    });
}
function runTaskTool(workspace, environment) {
    return harnessTool({
        name: "run_task",
        description: "Run project tasks, inspections, generators, formatters, or requested setup. A command still running after the initial wait returns a session-bound rN id; inspect that id with the returned cursor to receive only new output without relaunching it. Source changes are journaled and require a subsequent check. Explicit calls execute; finish_task reuses fresh validation. Use the dependency operation for Node packages and native commands for other ecosystems. " +
            (environment?.managedPreview === false
                ? "For requested services, detach the process and redirect its input/output so the command can finish. "
                : "Use the managed preview for services. ") +
            "Prettier on explicit files uses atomic edits. Test results include reporting counters; null is unknown and pending is distinct from skipped. Returns bounded output and code/environment diagnostics.",
        schema: lightRunTaskInputSchema,
        execute: (input, context) => workspace.runTask(input, context),
    });
}
function harnessTool(definition) {
    return createTool({
        name: definition.name,
        description: definition.description,
        inputSchema: definition.schema,
        retryable: false,
        maxRetries: 0,
        async execute(value, context) {
            const parsed = definition.schema.safeParse(value);
            if (!parsed.success)
                return invalidInput(parsed.error);
            return modelToolResponse(await definition.execute(parsed.data, context));
        },
    });
}
function modelToolResponse(result) {
    if (result.status !== "ok" || !result.content)
        return redactSecurityValue(result);
    const { content, ...text } = result;
    return [{ type: "text", text: JSON.stringify(redactSecurityValue(text)) }, ...content];
}
function invalidInput(error) {
    return {
        status: "blocked",
        category: "input",
        message: error.issues
            .slice(0, 5)
            .map((issue) => `${issue.path.join(".") || "input"}: ${issue.message}`)
            .join("; "),
    };
}
