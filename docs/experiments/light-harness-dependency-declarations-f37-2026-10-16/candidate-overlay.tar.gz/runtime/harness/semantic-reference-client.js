import { readFile, realpath, stat } from "node:fs/promises";
import { Worker } from "node:worker_threads";
import { sha256 } from "./light-identity.js";
import { semanticReferenceLimits, } from "./semantic-reference-types.js";
export async function querySemanticReferences(request, signal, timeoutMs = semanticReferenceLimits.timeoutMs) {
    return queryCompiler(request, signal, timeoutMs);
}
export async function queryDependencyDeclaration(request, signal, timeoutMs = semanticReferenceLimits.timeoutMs) {
    return queryCompiler(request, signal, timeoutMs);
}
async function queryCompiler(request, signal, timeoutMs) {
    signal?.throwIfAborted();
    const worker = new Worker(new URL("./semantic-reference-worker.js", import.meta.url), {
        workerData: request,
        resourceLimits: {
            maxOldGenerationSizeMb: semanticReferenceLimits.workerHeapMb,
        },
        // Strip host test/loader arguments; workers execute the packaged JS module.
        execArgv: [],
    });
    let timer;
    let onAbort;
    try {
        return await new Promise((resolve, reject) => {
            const unavailable = (reason) => resolve({ status: "unavailable", reason });
            onAbort = () => reject(signal?.reason ?? new Error("Reference query cancelled"));
            signal?.addEventListener("abort", onAbort, { once: true });
            worker.once("message", resolve);
            worker.once("error", () => unavailable("worker_failed"));
            worker.once("exit", () => unavailable("worker_exited"));
            timer = setTimeout(() => unavailable("query_timeout"), timeoutMs);
            if (signal?.aborted)
                onAbort();
        });
    }
    finally {
        if (timer)
            clearTimeout(timer);
        if (onAbort)
            signal?.removeEventListener("abort", onAbort);
        await worker.terminate();
    }
}
export async function referenceFootprintIsCurrent(footprint, signal) {
    // Bounded batches keep file-descriptor pressure independent of project size.
    const checks = [
        ...(footprint.realpaths ?? []).map(({ path, resolved }) => async () => {
            try {
                return await realpath(path) === resolved;
            }
            catch {
                return false;
            }
        }),
        ...footprint.reads.map(({ path, hash }) => async () => {
            try {
                return sha256(await readFile(path)) === hash;
            }
            catch {
                return false;
            }
        }),
        ...footprint.existence.map(({ path, exists }) => async () => {
            try {
                return (await stat(path)).isFile() === exists;
            }
            catch {
                return !exists;
            }
        }),
    ];
    for (let index = 0; index < checks.length; index += 32) {
        signal?.throwIfAborted();
        if ((await Promise.all(checks.slice(index, index + 32).map((check) => check()))).some((current) => !current))
            return false;
    }
    return true;
}
