import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
export async function writeDevelopmentAttachment(name, content, directory, storage) {
    if (storage) {
        const result = await storage.executor({
            tool: "store_attachment",
            workspaceRoot: storage.workspaceRoot,
            input: { name, contentBase64: content.toString("base64") },
        });
        const data = result.status === "ok"
            ? result.data
            : undefined;
        if (typeof data?.path !== "string" || !data.path)
            throw new Error(`Unable to store attachment ${name} in the workspace`);
        return data.path;
    }
    await mkdir(directory, { recursive: true });
    const filename = name.replace(/[^a-zA-Z0-9._-]/g, "_") || "attachment";
    const path = join(directory, `${randomUUID()}-${filename}`);
    await writeFile(path, content);
    return path;
}
export async function storeWorkspaceAttachment(workspaceRoot, input) {
    const attachment = input;
    if (typeof attachment?.name !== "string" ||
        typeof attachment.contentBase64 !== "string")
        throw new Error("Invalid workspace attachment");
    return writeDevelopmentAttachment(attachment.name, Buffer.from(attachment.contentBase64, "base64"), join(workspaceRoot, ".blame", "attachments", randomUUID()));
}
