export function reasoningConfig(reasoningSelection) {
    if (reasoningSelection === "none")
        return { thinking: false };
    if (reasoningSelection === "enabled")
        return { thinking: true };
    return reasoningSelection
        ? { reasoningEffort: reasoningSelection, thinking: true }
        : {};
}
