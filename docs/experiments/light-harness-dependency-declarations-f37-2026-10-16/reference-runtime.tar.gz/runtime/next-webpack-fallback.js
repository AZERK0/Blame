export function commandWithNextWebpackFallback(command) {
    if (/\s--(?:webpack|turbo|turbopack)\b/.test(command))
        return command;
    const direct = commandWithDirectNextWebpack(command);
    if (direct !== command)
        return direct;
    return commandWithPackageManagerWebpack(command);
}
function commandWithDirectNextWebpack(command) {
    return command.replace(/\b(next\s+dev)(?=\s|$)/, "$1 --webpack");
}
function commandWithPackageManagerWebpack(command) {
    return command.replace(/\b((?:(?:corepack|bun)\s+)?(?:pnpm|npm|bun|yarn)(?:\s+(?!--webpack|--turbo|--turbopack|&&|\|\||;)[^\s;&|]+)*\s+(?:run\s+)?dev)(?=(?:\s*(?:&&|\|\||;)|["')\]]|\s*$))/, (match) => `${match}${packageManagerArgumentSeparator(match)}--webpack`);
}
function packageManagerArgumentSeparator(command) {
    if (/\b(?:pnpm|yarn|corepack\s+(?:pnpm|yarn))\b/.test(command))
        return " ";
    return " -- ";
}
