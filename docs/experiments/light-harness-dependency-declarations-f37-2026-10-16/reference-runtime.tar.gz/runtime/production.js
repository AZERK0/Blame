import { delimiter, isAbsolute, relative, resolve } from "node:path";
import { supplementalModelConfig } from "./supplemental-model-config.js";
import { getBlameTelemetry, sanitizeText, } from "@blame/telemetry";
const secretKeys = [
    "access",
    "apiKey",
    "authorization",
    "headers",
    "oauthCredentials",
    "refresh",
    "token",
];
const allowedLogKeys = new Set([
    "cacheReadTokens",
    "cacheWriteTokens",
    "capsuleHash",
    "ccrHashCount",
    "checkpointEnabled",
    "compressed",
    "compactedEventHash",
    "compressionRatio",
    "contextUtilizationRatio",
    "configExtensions",
    "cost",
    "disableMcpSettingsTools",
    "durationMs",
    "errorType",
    "estimatedInputTokens",
    "fallback",
    "inputTokens",
    "maxIterations",
    "maxInputTokens",
    "messageBuilderMaxToolResultChars",
    "messageBuilderMaxTotalTextBytes",
    "messageBuilderMinOutdatedRewriteBytes",
    "messageCount",
    "messageCountAfter",
    "messageCountBefore",
    "maxParallelToolCalls",
    "mode",
    "modelId",
    "outputTokens",
    "promptLength",
    "providerId",
    "pluginPathCount",
    "sessionId",
    "status",
    "storyId",
    "success",
    "tailMessages",
    "targetTokens",
    "toolName",
    "toolResultTokens",
    "totalCacheReadTokens",
    "totalCacheWriteTokens",
    "totalCost",
    "totalInputTokens",
    "totalOutputTokens",
    "tokensAfter",
    "tokensBefore",
    "tokensSaved",
    "transformsApplied",
    "triggerTokens",
]);
const stableStringLogKeys = new Set([
    "capsuleHash",
    "compactedEventHash",
    "errorType",
    "mode",
    "modelId",
    "providerId",
    "sessionId",
    "status",
    "storyId",
    "toolName",
]);
const stableStringPattern = /^[A-Za-z0-9][A-Za-z0-9._:@-]{0,127}$/;
export function loadProductionConfig(env = process.env) {
    return {
        checkpointEnabled: booleanValue(env.BLAME_AGENT_CHECKPOINTS_ENABLED, true),
        compactionEnabled: booleanValue(env.BLAME_AGENT_COMPACTION_ENABLED, true),
        compactionPreserveRecentTokens: positiveNumber(env.BLAME_AGENT_COMPACTION_PRESERVE_RECENT_TOKENS),
        compactionStrategy: compactionStrategy(env.BLAME_AGENT_COMPACTION_STRATEGY),
        configExtensions: configExtensions(env.BLAME_AGENT_CONFIG_EXTENSIONS),
        disableMcpSettingsTools: !booleanValue(env.BLAME_AGENT_MCP_SETTINGS_TOOLS_ENABLED, true),
        maxInputTokens: positiveNumber(env.BLAME_AGENT_MAX_INPUT_TOKENS),
        messageBuilderMaxToolResultChars: positiveNumber(env.BLAME_AGENT_MESSAGE_BUILDER_MAX_TOOL_RESULT_CHARS),
        messageBuilderMaxTotalTextBytes: positiveNumber(env.BLAME_AGENT_MESSAGE_BUILDER_MAX_TOTAL_TEXT_BYTES),
        messageBuilderMinOutdatedRewriteBytes: positiveNumber(env.BLAME_AGENT_MESSAGE_BUILDER_MIN_OUTDATED_REWRITE_BYTES),
        maxOutputTokens: positiveNumber(env.BLAME_AGENT_MAX_OUTPUT_TOKENS),
        requestMaxOutputTokens: requestOutputLimit(env.BLAME_AGENT_REQUEST_MAX_OUTPUT_TOKENS),
        maxParallelToolCalls: positiveNumber(env.BLAME_AGENT_MAX_PARALLEL_TOOL_CALLS, 8),
        maxSessionCostUsd: positiveNumber(env.BLAME_AGENT_MAX_SESSION_COST_USD),
        maxTotalTokens: positiveNumber(env.BLAME_AGENT_MAX_TOTAL_TOKENS),
        pluginPaths: listValue(env.BLAME_AGENT_PLUGIN_PATHS),
    };
}
export function applyProductionEnvironment(config, env = process.env) {
    setDefaultEnvValue(env, "CLINE_MESSAGE_BUILDER_MAX_TOOL_RESULT_CHARS", config.messageBuilderMaxToolResultChars);
    setDefaultEnvValue(env, "CLINE_MESSAGE_BUILDER_MAX_TOTAL_TEXT_BYTES", config.messageBuilderMaxTotalTextBytes);
    setDefaultEnvValue(env, "CLINE_MESSAGE_BUILDER_MIN_OUTDATED_REWRITE_BYTES", config.messageBuilderMinOutdatedRewriteBytes);
}
export function createProductionLogger() {
    return {
        debug: (_message, metadata) => writeProductionLog("debug", "blame.agent.sdk.debug", metadata),
        log: (_message, metadata) => writeProductionLog("info", "blame.agent.sdk.log", metadata),
        error: (_message, metadata) => writeProductionLog("error", "blame.agent.sdk.error", metadata),
    };
}
function writeProductionLog(severity, eventName, metadata) {
    const record = getBlameTelemetry().structuredLog(severity, eventName, safeLogPayload(metadata));
    const serialized = JSON.stringify(record);
    if (severity === "error")
        console.error(serialized);
    else if (severity === "debug")
        console.debug(serialized);
    else
        console.info(serialized);
}
export function promptMetadata(prompt) {
    return {
        promptLength: prompt.length,
    };
}
export function appendProductionConfig(config, production = loadProductionConfig()) {
    const configWithLimits = config;
    return {
        ...supplementalModelConfig(config),
        ...(production.requestMaxOutputTokens !== undefined ? { maxTokensPerTurn: Math.min(config.maxTokensPerTurn ?? production.requestMaxOutputTokens, production.requestMaxOutputTokens) } : {}),
        execution: {
            ...config.execution,
            loopDetection: config.execution?.loopDetection ?? {
                hardThreshold: 5,
                softThreshold: 3,
            },
            maxConsecutiveMistakes: config.execution?.maxConsecutiveMistakes ?? 3,
        },
        maxConsecutiveMistakes: configWithLimits.maxConsecutiveMistakes ?? 3,
        maxParallelToolCalls: configWithLimits.maxParallelToolCalls ??
            production.maxParallelToolCalls,
    };
}
function requestOutputLimit(value) {
    if (value === undefined)
        return undefined;
    if (!/^\d+$/u.test(value.trim()) || !Number.isSafeInteger(Number(value)) || Number(value) < 1)
        throw new Error("BLAME_AGENT_REQUEST_MAX_OUTPUT_TOKENS must be a positive integer.");
    return Number(value);
}
export function blameCheckpointConfig(config) {
    return {
        enabled: config.checkpointEnabled ?? true,
    };
}
export function blameCompactionConfig(config) {
    return {
        enabled: config.compactionEnabled ?? true,
        ...(config.compactionPreserveRecentTokens
            ? { preserveRecentTokens: config.compactionPreserveRecentTokens }
            : {}),
        strategy: config.compactionStrategy ?? "agentic",
    };
}
export function runtimeConfigExtensions(config) {
    return config.configExtensions?.length ? config.configExtensions : undefined;
}
export function runtimePluginPaths(config, paths) {
    const pluginPaths = [...(config.pluginPaths ?? []), ...(paths ?? [])];
    return pluginPaths.length ? Array.from(new Set(pluginPaths)) : undefined;
}
export function assertWorkspacePath(path, workspaceRoot, label) {
    const resolvedPath = resolve(path);
    const resolvedWorkspace = resolve(workspaceRoot);
    if (!isAbsolute(path))
        throw new Error(`${label} must be an absolute path.`);
    if (!isAbsolute(workspaceRoot))
        throw new Error("workspaceRoot must be an absolute path.");
    if (!isPathInside(resolvedPath, resolvedWorkspace)) {
        throw new Error(`${label} must stay inside workspaceRoot.`);
    }
}
export function assertRepositoryPath(path, label) {
    if (!isAbsolute(path))
        throw new Error(`${label} must be an absolute path.`);
}
export function summarizeUsage(summary) {
    const usage = summary?.aggregateUsage ?? summary?.usage;
    if (!usage)
        return {};
    return {
        cacheReadTokens: usage.cacheReadTokens,
        cacheWriteTokens: usage.cacheWriteTokens,
        cost: usageCost(usage),
        inputTokens: usage.inputTokens,
        outputTokens: usage.outputTokens,
        totalCacheReadTokens: usageTotalCacheReadTokens(usage),
        totalCacheWriteTokens: usageTotalCacheWriteTokens(usage),
        totalCost: usageTotalCost(usage),
        totalInputTokens: usageTotalInputTokens(usage),
        totalOutputTokens: usageTotalOutputTokens(usage),
    };
}
export function shouldAbortForUsage(summary, config) {
    const usage = summary?.aggregateUsage ?? summary?.usage;
    if (!usage)
        return false;
    if (config.maxTotalTokens !== undefined &&
        totalTokens(usage) > config.maxTotalTokens)
        return true;
    if (config.maxSessionCostUsd !== undefined &&
        totalCost(usage) > config.maxSessionCostUsd)
        return true;
    if (config.maxInputTokens !== undefined &&
        usageTotalInputTokens(usage) > config.maxInputTokens)
        return true;
    if (config.maxOutputTokens !== undefined &&
        usageTotalOutputTokens(usage) > config.maxOutputTokens)
        return true;
    return false;
}
export function usageLimitMessage(summary, config) {
    const usage = summary?.aggregateUsage ?? summary?.usage;
    if (!usage)
        return "Usage limit exceeded.";
    if (config.maxTotalTokens !== undefined &&
        totalTokens(usage) > config.maxTotalTokens) {
        return `Total token limit exceeded (${config.maxTotalTokens})`;
    }
    if (config.maxSessionCostUsd !== undefined &&
        totalCost(usage) > config.maxSessionCostUsd) {
        return `Cost limit exceeded ($${config.maxSessionCostUsd.toFixed(2)})`;
    }
    if (config.maxInputTokens !== undefined &&
        usageTotalInputTokens(usage) > config.maxInputTokens) {
        return `Input token limit exceeded (${config.maxInputTokens})`;
    }
    if (config.maxOutputTokens !== undefined &&
        usageTotalOutputTokens(usage) > config.maxOutputTokens) {
        return `Output token limit exceeded (${config.maxOutputTokens})`;
    }
    return "Usage limit exceeded.";
}
export function safeLogPayload(value) {
    if (!isRecord(value))
        return {};
    return Object.fromEntries(Object.entries(value)
        .filter(([key]) => allowedLogKeys.has(key) && !secretKeys.includes(key))
        .map(([key, field]) => [key, safeLogValue(key, field)])
        .filter((entry) => entry[1] !== undefined));
}
function safeLogValue(key, value) {
    if (typeof value === "number" || typeof value === "boolean")
        return value;
    if (typeof value !== "string" || !stableStringLogKeys.has(key))
        return undefined;
    const sanitizedValue = sanitizeText(value);
    if (stableStringPattern.test(sanitizedValue))
        return sanitizedValue;
    return undefined;
}
function positiveNumber(value, fallback) {
    if (!value)
        return fallback;
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
function booleanValue(value, fallback) {
    if (value === undefined)
        return fallback;
    return value !== "false";
}
function compactionStrategy(value) {
    return value === "basic" ? "basic" : "agentic";
}
function configExtensions(value) {
    const allowed = new Set([
        "plugins",
        "rules",
        "skills",
        "workflows",
    ]);
    const values = listValue(value).filter((entry) => allowed.has(entry));
    return values.length ? values : undefined;
}
function listValue(value) {
    if (!value)
        return [];
    return value
        .split(delimiter)
        .flatMap((entry) => entry.split(","))
        .map((entry) => entry.trim())
        .filter(Boolean);
}
function setDefaultEnvValue(env, key, value) {
    if (value === undefined || env[key])
        return;
    env[key] = String(value);
}
function numberValue(value) {
    return typeof value === "number" ? value : 0;
}
function totalTokens(usage) {
    return usageTotalInputTokens(usage) + usageTotalOutputTokens(usage);
}
function totalCost(usage) {
    return usageTotalCost(usage);
}
function usageCost(usage) {
    return "cost" in usage ? usage.cost : undefined;
}
function usageTotalCost(usage) {
    return numberValue(usage.totalCost ?? usageCost(usage));
}
function usageTotalInputTokens(usage) {
    return numberValue("totalInputTokens" in usage ? usage.totalInputTokens : usage.inputTokens);
}
function usageTotalOutputTokens(usage) {
    return numberValue("totalOutputTokens" in usage ? usage.totalOutputTokens : usage.outputTokens);
}
function usageTotalCacheReadTokens(usage) {
    return numberValue("totalCacheReadTokens" in usage
        ? usage.totalCacheReadTokens
        : usage.cacheReadTokens);
}
function usageTotalCacheWriteTokens(usage) {
    return numberValue("totalCacheWriteTokens" in usage
        ? usage.totalCacheWriteTokens
        : usage.cacheWriteTokens);
}
function isPathInside(path, parent) {
    const pathRelativeToParent = relative(parent, path);
    return (pathRelativeToParent === "" ||
        (!pathRelativeToParent.startsWith("..") &&
            !isAbsolute(pathRelativeToParent)));
}
function isRecord(value) {
    return !!value && typeof value === "object";
}
