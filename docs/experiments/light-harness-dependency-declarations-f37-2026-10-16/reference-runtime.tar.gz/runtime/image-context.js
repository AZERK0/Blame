import { createHash } from "node:crypto";
export const maximumImageEncodedBytes = 5 * 1024 * 1024;
const maximumImageContextBytes = 8 * 1024 * 1024;
export function projectImageContext(messages) {
    const images = [];
    for (const message of messages)
        collectMessageImages(message, images);
    if (!images.length)
        return messages;
    const groups = imageGroups(images);
    const selected = selectImages(groups);
    let index = 0;
    return messages.map((message) => mapMessageImages(message, (image) => {
        const group = groups[index++];
        if (!selected.has(group.key))
            return omittedImage(group.bytes);
        return group.first === index - 1 ? image : duplicateImage();
    }));
}
function collectMessageImages(message, images) {
    if (!Array.isArray(message.content))
        return;
    for (const block of message.content) {
        if (nativeImage(block))
            images.push(block);
        else if (block.type === "tool_result")
            collectImages(block.content, images);
    }
}
function collectImages(value, images) {
    if (nativeImage(value))
        images.push(value);
    else if (Array.isArray(value))
        value.forEach((item) => collectImages(item, images));
    else if (value && typeof value === "object")
        Object.values(value).forEach((item) => collectImages(item, images));
}
function nativeImage(value) {
    if (!value || typeof value !== "object")
        return false;
    const image = value;
    return image.type === "image" && typeof image.mediaType === "string" && typeof image.data === "string";
}
function imageGroups(images) {
    const unique = new Map();
    return images.map((image, index) => {
        const key = createHash("sha256").update(image.mediaType).update("\0").update(image.data).digest("hex");
        const group = unique.get(key) ?? { first: index, last: index, bytes: image.data.length, key };
        group.last = index;
        unique.set(key, group);
        return group;
    });
}
function selectImages(groups) {
    const latest = [...new Set(groups)].sort((left, right) => right.last - left.last);
    const selected = new Set();
    let bytes = 0;
    for (const group of latest) {
        if (group.bytes > maximumImageEncodedBytes || bytes + group.bytes > maximumImageContextBytes)
            continue;
        selected.add(group.key);
        bytes += group.bytes;
    }
    return selected;
}
function mapMessageImages(message, replace) {
    if (!Array.isArray(message.content))
        return message;
    const content = message.content.map((block) => {
        if (nativeImage(block))
            return replace(block);
        if (block.type !== "tool_result")
            return block;
        return { ...block, content: mapOutputImages(block.content, replace) };
    });
    return { ...message, content };
}
function mapOutputImages(value, replace) {
    if (nativeImage(value))
        return replace(value);
    if (Array.isArray(value))
        return value.map((item) => mapOutputImages(item, replace));
    if (!value || typeof value !== "object")
        return value;
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, mapOutputImages(item, replace)]));
}
function duplicateImage() {
    return { type: "text", text: "Duplicate image data; see the earlier result." };
}
function omittedImage(bytes) {
    return { type: "text", text: bytes > maximumImageEncodedBytes
            ? "Image exceeds the provider image limit. Resize or crop it before reading again."
            : "Image omitted to make room for recent images. View it again if needed." };
}
