import { randomUUID } from "node:crypto";
import { lstat, mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { boundedDiagnostic } from "./light-diagnostic.js";
export async function validationOutput(workspaceRoot, output) {
    if (output.length <= 1_200)
        return { output };
    try {
        const directory = await validationLogDirectory(workspaceRoot);
        const name = `validation-${randomUUID()}.log`;
        await writeFile(join(directory, name), output, { flag: "wx", mode: 0o600 });
        return {
            output: boundedDiagnostic(output, "", 900),
            outputLog: `.blame/logs/${name}`,
        };
    }
    catch {
        return { output: boundedDiagnostic(output, "", 4_000) };
    }
}
async function validationLogDirectory(workspaceRoot) {
    let directory = workspaceRoot;
    for (const segment of [".blame", "logs"]) {
        directory = join(directory, segment);
        await mkdir(directory).catch((error) => {
            if (error.code !== "EEXIST")
                throw error;
        });
        const metadata = await lstat(directory);
        if (!metadata.isDirectory() || metadata.isSymbolicLink())
            throw new Error("Validation log directory is not a regular directory.");
    }
    return directory;
}
