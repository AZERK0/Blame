import { parseCode } from "./code-intelligence.js";
export function symbolsTouchedByPatch(path, content, patch) {
    if (!content || patch.mode !== "update")
        return [];
    const parsed = parseCode(path, content);
    if (!parsed.supported)
        return [];
    return [
        ...new Set(patch.replacements.flatMap((replacement) => {
            const symbol = smallestContainingSymbol(parsed.symbols, replacement);
            return symbol ? [symbol.qualified_name] : [];
        })),
    ];
}
function smallestContainingSymbol(symbols, replacement) {
    return symbols
        .filter((symbol) => containsReplacement(symbol.range_utf8_bytes, replacement))
        .sort((left, right) => rangeSize(left.range_utf8_bytes) - rangeSize(right.range_utf8_bytes))[0];
}
function containsReplacement(range, replacement) {
    if (replacement.start === replacement.end)
        return range[0] < replacement.start && replacement.start < range[1];
    return range[0] <= replacement.start && replacement.end <= range[1];
}
function rangeSize([start, end]) {
    return end - start;
}
