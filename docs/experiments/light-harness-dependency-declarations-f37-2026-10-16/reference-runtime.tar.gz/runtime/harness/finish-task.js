import { createLightCompletionTool, } from "./light-completion.js";
import { lightToolContext, } from "./light-executor.js";
import { LightFinishService } from "./light-finish-service.js";
export function createFinishTaskTool(options) {
    if (options.executor)
        return createLightCompletionTool((summary, context) => finishRemotely(options, summary, context));
    const service = new LightFinishService(options);
    return createLightCompletionTool((summary, context) => service.finish(summary, context));
}
async function finishRemotely(options, summary, context) {
    const result = await options.executor({
        input: { summary },
        taskContract: options.taskContract,
        tool: "finish_task",
        toolContext: lightToolContext(context),
        workspaceRoot: options.workspaceRoot,
    }, context.signal);
    if (result.status !== "ok")
        throw new Error(result.message);
    const data = recordValue(result.data);
    const notification = data.notification;
    const activities = Array.isArray(data.validationActivities)
        ? data.validationActivities
        : [];
    for (const activity of activities)
        await options.onValidationActivity?.(activity);
    if (notification)
        await options.onComplete?.(notification);
    return typeof data.summary === "string" ? data.summary : summary;
}
function recordValue(value) {
    return value && typeof value === "object"
        ? value
        : {};
}
