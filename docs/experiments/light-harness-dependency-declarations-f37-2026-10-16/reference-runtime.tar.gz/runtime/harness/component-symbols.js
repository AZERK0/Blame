export function componentElementBodyRange(node, context) {
    if (!isContainerElement(node))
        return undefined;
    const children = node.children();
    const start = children.find((child) => ["start_tag", "script_start_tag", "style_start_tag"].includes(String(child.kind())));
    const end = [...children]
        .reverse()
        .find((child) => ["end_tag", "script_end_tag", "style_end_tag"].includes(String(child.kind())));
    if (!start || !end)
        return undefined;
    return [nodeEnd(start, context), nodeStart(end, context)];
}
export function componentElementName(node) {
    const tag = node
        .children()
        .flatMap((child) => [child, ...child.children()])
        .find((child) => child.kind() === "tag_name")
        ?.text()
        .trim();
    if (!tag)
        return undefined;
    const opening = node.children()[0]?.text() ?? "";
    const id = opening.match(/\bid\s*=\s*["']([^"']+)["']/u)?.[1];
    return id ? `${tag}#${id}` : tag;
}
function isContainerElement(node) {
    return ["element", "script_element", "style_element"].includes(String(node.kind()));
}
function nodeStart(node, context) {
    return context.byteOffset + context.utf8Offsets[node.range().start.index];
}
function nodeEnd(node, context) {
    return context.byteOffset + context.utf8Offsets[node.range().end.index];
}
