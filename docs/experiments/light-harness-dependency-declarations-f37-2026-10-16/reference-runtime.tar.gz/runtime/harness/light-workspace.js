import { isUtf8 } from "node:buffer";
import { codeObservation, presentObservation } from "./code-observation.js";
import { readIsolatedEnvironmentImage, readWorkspaceImage } from "./light-images.js";
import { pythonBodyRange } from "./python-body.js";
import { outlineSymbol, parseCode, symbolEditRange, } from "./code-intelligence.js";
import { LightAliasRegistry, SymbolResolutionError, } from "./light-aliases.js";
import { capabilityForPath, lightCapabilityDescription, runtimeCapabilityRegistry, } from "./light-capabilities.js";
import { LightEditService } from "./light-edit.js";
import { LightCommitService } from "./light-commit.js";
import { autoSearchResult, autoSymbolCandidates, editTargetSymbols, emptySearchScope, enclosingSymbol, firstTermIndex, lexicalQuery, lineRange, matchedTerm, outlineCandidates, pathMatches, qualifiedTarget, rankedTextMatches, recordValue, requestedLineRange, routedView, scopedCandidates, searchMode, searchSymbolResult, searchTerms, sourceLine, stringValue, symbolicPath, symbolMatches, symbolSearchResult, textSearchResult, uniqueSearchResults, } from "./light-navigation.js";
import { LightTaskRunner } from "./light-task-runner.js";
import { LightReferenceSearch } from "./light-reference-search.js";
import { searchWithRipgrep, } from "./lexical-search.js";
import { ReadCoverage } from "./read-coverage.js";
import { SessionJournal } from "./session-journal.js";
import { currentValidationReport } from "./light-validation-report.js";
import { sha256 } from "./light-identity.js";
import { assertMutableWorkspacePath, WorkspaceFiles, } from "./workspace-files.js";
const maximumRawCharacters = 64_000;
const maximumOutlineItems = 32;
const maximumDirectoryEntries = 64;
function outlineRangeCandidates(symbols, range) {
    const candidates = outlineCandidates(symbols);
    if (!range)
        return candidates;
    return candidates.filter(({ line_range: [start, end] }) => start <= range.endLine && end >= range.startLine);
}
export class LightWorkspace {
    edits;
    tasks;
    aliases = new LightAliasRegistry();
    references;
    coverage = new ReadCoverage();
    files;
    journal;
    initialization;
    options;
    commits;
    constructor(workspaceRoot, options) {
        this.files = new WorkspaceFiles(workspaceRoot);
        this.references = new LightReferenceSearch(this.files, this.aliases);
        this.commits = new LightCommitService(this.files);
        this.journal = new SessionJournal(workspaceRoot, options.sessionId);
        this.options = options;
        this.edits = new LightEditService(this.aliases, {
            files: this.files,
            journal: this.journal,
        });
        this.tasks = new LightTaskRunner({
            commandEnvironment: options.taskContract?.environment,
            edits: this.edits,
            files: this.files,
            ...(options.initialCommandWaitMs !== undefined
                ? { initialCommandWaitMs: options.initialCommandWaitMs }
                : {}),
            journal: this.journal,
            refreshPreviewDependencies: options.refreshPreviewDependencies,
        });
    }
    get ready() {
        return (this.initialization ??= this.initializeJournal(this.options));
    }
    async editCode(input, context = {}) {
        await this.ready;
        const result = await this.edits.edit(input, context);
        if (result.status === "ok")
            for (const change of arrayValue(recordValue(result.data).changes)) {
                const path = stringValue(recordValue(change).path);
                if (path)
                    this.coverage.invalidatePath(path);
            }
        await this.journal.recordCoverage(this.coverage.snapshot());
        return result;
    }
    async runTask(input, context) {
        await this.ready;
        const result = await this.tasks.run(input, context);
        if (result.status !== "ok")
            return result;
        const paths = arrayValue(recordValue(result.data).paths).flatMap((value) => {
            const path = stringValue(value);
            return path ? [path] : [];
        });
        for (const path of paths)
            this.coverage.invalidatePath(path);
        if (paths.length)
            await this.journal.recordCoverage(this.coverage.snapshot());
        if (recordValue(recordValue(result.data).check).outcome === "failed") {
            const data = recordValue(result.data);
            const output = typeof data.output === "string" ? data.output : "";
            const snippets = [];
            let remaining = 4 * 1024;
            const seen = new Set();
            const locations = [
                ...arrayValue(recordValue(data.check).diagnostics).flatMap((value) => {
                    const diagnostic = recordValue(value);
                    return typeof diagnostic.path === "string" && typeof diagnostic.line === "number"
                        ? [{ path: diagnostic.path, line: diagnostic.line }] : [];
                }),
                ...[...output.matchAll(/(?:^|\s|\()([^\s():]+\.(?:[cm]?[jt]sx?|py|java|cs)):(\d+)(?::\d+)?/gmu)]
                    .map((match) => ({ path: match[1], line: Number(match[2]) })),
            ];
            for (const location of locations) {
                const { line } = location;
                let path;
                try {
                    path = this.files.normalizePath(location.path);
                }
                catch {
                    continue;
                }
                if (snippets.length >= 2)
                    break;
                if (seen.has(path))
                    continue;
                seen.add(path);
                if (!Number.isSafeInteger(line) || line < 1)
                    continue;
                try {
                    const content = (await this.files.read(path)).content;
                    const [start, end] = lineByteRange(content, Math.max(1, line - 2), line + 2);
                    if (end - start > remaining - 512)
                        continue;
                }
                catch {
                    continue;
                }
                const snippet = await this.readCode({ target: path, view: "range",
                    range: { startLine: Math.max(1, line - 2), endLine: line + 2 } }, context);
                if (snippet.status !== "ok")
                    continue;
                const bytes = Buffer.byteLength(JSON.stringify(snippet.data));
                if (bytes > remaining)
                    continue;
                remaining -= bytes;
                snippets.push({ ...recordValue(snippet.data), source: "current workspace; diagnostic revision not certified" });
            }
            if (snippets.length)
                return { ...result, data: { ...data, diagnostics: snippets } };
        }
        return result;
    }
    async searchCode(input, signal) {
        try {
            await this.ready;
            const result = await this.commits.exclusive(() => this.searchCurrentWorkspace(input, signal));
            await this.recordObservationAudit("search_code", input.mode ?? "auto", result);
            return result;
        }
        catch (error) {
            return inputBlocked(error);
        }
    }
    async searchCurrentWorkspace(input, signal) {
        const snapshot = await this.files.snapshot(signal);
        const candidates = scopedCandidates(this.files, snapshot.files, input.scope);
        if (!candidates.length)
            return emptySearchScope(this.files, snapshot.files, input);
        const semantic = input.mode === "references"
            ? await this.references.search(input, snapshot.files, candidates, snapshot.revision.source_revision_id, signal)
            : undefined;
        if (semantic && "status" in semantic)
            return this.persistAliases(semantic);
        const result = await this.searchResult(semantic ? { ...input, query: semantic.lexicalQuery } : input, searchMode(input), candidates, snapshot.revision.source_revision_id, signal);
        const labeled = semantic && result.status === "ok" ? { ...result, data: { ...recordValue(result.data),
                semanticFallback: semantic.fallback,
                ...this.references.recovery(input, recordValue(result.data), semantic.fallback) } } : result;
        const expanded = await this.expandSearch(labeled, snapshot.revision.source_revision_id);
        return this.persistAliases(expanded);
    }
    async expandSearch(result, revision) {
        if (!this.options.experimentalSearchExpansion || result.status !== "ok")
            return result;
        const data = recordValue(result.data);
        const items = arrayValue(data.results);
        if (data.limited || !items.length || items.length > 2 || data.engine === "node")
            return result;
        const observations = [];
        for (const item of items) {
            const alias = stringValue(recordValue(item).alias);
            if (!alias || this.aliases.get(alias)?.kind !== "symbol")
                return result;
            const resolved = await this.aliases.resolveSymbol(alias, this.files, revision);
            const [start, end] = resolved.symbol.range_utf8_bytes;
            if (end - start >= 4 * 1024)
                return result;
            observations.push({ resolved, observation: codeObservation(resolved.path, resolved.content, start, end, "symbol", { alias, qualifiedName: resolved.symbol.qualified_name }) });
        }
        const results = observations.map(({ resolved, observation }) => ({ ...presentObservation(observation),
            lines: resolved.symbol.line_range, context: "Local symbol only; use read_code for imports and surrounding invariants." }));
        if (Buffer.byteLength(JSON.stringify(results)) > 10 * 1024)
            return result;
        for (const { resolved } of observations)
            await this.registerCoverage(resolved.path, resolved.content, [resolved.symbol.range_utf8_bytes], {});
        return { ...result, data: { ...data, results, expanded: true,
                searchComplete: true, scope: "Eligible workspace text files up to 2 MiB; ignore rules applied." } };
    }
    async readCode(input, context) {
        try {
            await this.ready;
            const result = await this.commits.exclusive(() => this.readCurrentWorkspace(input, context));
            await this.recordObservationAudit("read_code", input.view ?? "auto", result);
            return result;
        }
        catch (error) {
            return inputBlocked(error);
        }
    }
    async readCurrentWorkspace(input, context) {
        context.signal?.throwIfAborted();
        const externalImage = await readIsolatedEnvironmentImage(this.files, input.target, context, this.options.taskContract?.environment?.isolated);
        if (externalImage)
            return externalImage;
        const special = await this.specialReadResult(input.target);
        if (special)
            return special;
        const snapshot = await this.files.snapshot(context.signal);
        const directory = await this.directoryReadResult(input, snapshot.files, context);
        return (directory ??
            this.readWorkspaceTarget(input, snapshot.revision.source_revision_id, context));
    }
    async recordObservationAudit(tool, requestedView, result) {
        if (result.status !== "ok")
            return;
        const data = recordValue(result.data);
        const targets = arrayValue(data.results ?? data.items ?? data.editTargets);
        await this.journal.recordObservationAudit({ tool, requestedView,
            renderedView: stringValue(data.view ?? data.mode) ?? "unknown",
            bytes: Buffer.byteLength(JSON.stringify(result.data)),
            aliases: targets.filter((item) => stringValue(recordValue(item).alias)).length + (data.alias ? 1 : 0),
            limited: data.limited === true || data.truncated === true });
    }
    async initializeJournal(options) {
        await this.commits.exclusive(() => this.journal.hydrate());
        this.aliases.hydrate(this.journal.currentAliases());
        this.coverage.hydrate(this.journal.currentCoverage());
        for (const entry of this.journal.currentCoverage().entries)
            this.aliases.rememberObservation(entry.path, entry.hash, entry.intervals);
        const objective = options.taskContract?.objective;
        if (objective)
            await this.journal.ingestUserRequest("initial", objective);
    }
    async persistAliases(result) {
        await this.journal.recordAliases(this.aliases.entries());
        return result;
    }
    async searchResult(input, mode, candidates, revision, signal) {
        if (mode === "symbol" && input.mode === "symbol")
            return symbolSearchResult(await this.symbolSearch(input.query, candidates, revision, signal), candidates);
        const text = await this.textSearch(input.query, candidates, revision, input.mode !== "text", signal);
        if (mode !== "symbol")
            return textSearchResult(mode, text, candidates);
        const symbolCandidates = autoSymbolCandidates(text.results, candidates, input.query);
        const symbols = await this.symbolSearch(input.query, symbolCandidates, revision, signal);
        return autoSearchResult(symbols, text, candidates);
    }
    async specialReadResult(target) {
        if (target === "@checks")
            return { status: "ok", data: currentValidationReport(await this.journal.completionSnapshot()) };
        if (target === "@capabilities")
            return capabilitiesResult();
        if (target === "@changes")
            return {
                status: "ok",
                data: { changes: this.journal.currentChanges() },
            };
        return undefined;
    }
    async directoryReadResult(input, files, context) {
        if (this.aliases.get(input.target) || qualifiedTarget(input.target))
            return undefined;
        const path = this.files.normalizePath(input.target);
        assertMutableWorkspacePath(path);
        if (!(await this.files.pathProfile(path)).directory)
            return undefined;
        const entries = directoryEntries(path, files);
        const content = Buffer.from(JSON.stringify(entries));
        const coverage = await this.registerCoverage(`${path}/`, content, [[0, content.byteLength]], context);
        if (coverage.covered)
            return coveredDirectoryResult(path, coverage.receipt);
        return {
            status: "ok",
            receipt: coverage.receipt,
            data: {
                candidateCount: entries.length,
                entries: entries.slice(0, maximumDirectoryEntries),
                path,
                truncated: entries.length > maximumDirectoryEntries,
                view: "directory",
            },
        };
    }
    async readWorkspaceTarget(input, revision, context) {
        const alias = this.aliases.get(input.target);
        const result = alias?.kind === "path"
            ? await this.readPath({ ...input, target: alias.path }, revision, context)
            : alias?.kind === "range"
                ? await this.readRangeAlias(alias, input, revision, context)
                : alias?.kind === "symbol" || qualifiedTarget(input.target)
                    ? await this.readSymbol(input.target, revision, context, input)
                    : await this.readPath(input, revision, context);
        return this.persistAliases(result);
    }
    async symbolSearch(query, candidates, revision, signal) {
        const selected = [];
        const normalized = query.toLocaleLowerCase();
        for (const path of candidates) {
            signal?.throwIfAborted();
            if (selected.length === 8)
                break;
            if (!symbolicPath(path))
                continue;
            const content = (await this.files.read(path)).content;
            if (content.byteLength > 2 * 1024 * 1024)
                continue;
            for (const symbol of parseCode(path, content).symbols) {
                if (!symbolMatches(symbol, normalized))
                    continue;
                const exact = symbol.name.toLocaleLowerCase() === normalized ||
                    symbol.qualified_name.toLocaleLowerCase() === normalized;
                if (selected.length < 8)
                    selected.push({ path, content, symbol, exact });
                else if (exact && !selected.at(-1).exact) {
                    selected.pop();
                    selected.push({ path, content, symbol, exact });
                }
                // Stable ties retain candidate/source order. Scan the already parsed
                // file for exact names, but retain the bound on visiting further files.
                selected.sort((left, right) => Number(right.exact) - Number(left.exact));
                if (selected.length === 8 && selected.every((item) => item.exact))
                    break;
            }
        }
        // Register only returned aliases; discovery still grants no read coverage.
        return selected.map(({ path, content, symbol }) => this.symbolResult(path, content, symbol, revision));
    }
    symbolResult(path, content, symbol, revision, reason) {
        const { alias, materialized } = this.aliases.registerSymbol(path, content, symbol, revision);
        return searchSymbolResult(alias, path, materialized, reason);
    }
    async textSearch(query, candidates, revision, promoteSymbols, signal) {
        const paths = this.pathSearch(query, candidates);
        const searched = await searchWithRipgrep({
            candidates,
            maximum: 32,
            query: lexicalQuery(query),
            root: this.files.root,
            signal,
        });
        const content = searched.available
            ? await this.materializeMatches(rankedTextMatches(searched.items, query), revision, promoteSymbols)
            : await this.nodeTextSearch(query, candidates, signal);
        const results = uniqueSearchResults([...paths, ...content]);
        return { results: results.slice(0, 8), engine: searched.engine,
            limited: !searched.available || searched.truncated || content.length >= 8 || paths.length >= 8 || results.length > 8 };
    }
    async materializeMatches(matches, revision, promote) {
        const sources = new Map();
        let results = [];
        for (const match of matches) {
            let source = sources.get(match.path);
            if (!source) {
                const { content } = await this.files.read(match.path);
                source = { content, symbols: promote && symbolicPath(match.path) ? parseCode(match.path, content).symbols : [] };
                sources.set(match.path, source);
            }
            results = uniqueSearchResults([...results, this.textMatch(match, revision, source)]);
            if (results.length >= 8)
                break;
        }
        return results;
    }
    pathSearch(query, candidates) {
        return pathMatches(query, candidates).map((path) => ({
            alias: this.aliases.registerPath(path),
            kind: "path",
            path,
            reason: "path_name",
            target: path,
        }));
    }
    textMatch(match, revision, source) {
        const { content } = source;
        const symbol = enclosingSymbol(source.symbols, match.range_utf8_bytes);
        if (symbol)
            return this.symbolResult(match.path, content, symbol, revision, "lexical_symbol");
        const alias = this.aliases.registerRange(match.path, content, match.range_utf8_bytes);
        return {
            alias,
            kind: "text",
            path: match.path,
            lines: match.line_range,
            snippet: match.excerpt,
            reason: match.match_reason,
        };
    }
    async nodeTextSearch(query, candidates, signal) {
        const results = [];
        const terms = searchTerms(query);
        for (const path of candidates) {
            signal?.throwIfAborted();
            if (results.length >= 8)
                break;
            if (await this.files.fileSize(path) > 2 * 1024 * 1024)
                continue;
            const content = (await this.files.read(path)).content;
            const source = content.toString("utf8");
            const index = firstTermIndex(source, terms, query);
            if (index < 0)
                continue;
            const matched = matchedTerm(source, index, terms, query);
            const start = Buffer.byteLength(source.slice(0, index));
            const range = [
                start,
                start + Buffer.byteLength(matched),
            ];
            results.push({
                alias: this.aliases.registerRange(path, content, range),
                kind: "text",
                path,
                lines: lineRange(content, range),
                snippet: sourceLine(source, index),
                reason: terms.length > 1 ? "lexical_regex" : "lexical_exact",
            });
        }
        return results;
    }
    async readPath(input, revision, context) {
        const path = this.files.normalizePath(input.target);
        assertMutableWorkspacePath(path);
        const image = await readWorkspaceImage(this.files, path, context);
        if (image)
            return image;
        const file = await this.files.read(path);
        const source = readableSource(file.content);
        const view = routedView(input, path, source.length);
        if (view === "signature")
            throw new Error("Signature view requires a symbol alias or path#qualifiedName. Read the file outline to choose a declaration.");
        if (view === "outline")
            return await this.readOutlinePath(path, file.content, revision, context, input.range);
        if (view === "range")
            return await this.readLineRange(path, file.content, input, revision, context);
        return await this.raw(path, file.content, revision, context, view === "symbol" ? "symbol_target_missing" : undefined);
    }
    async readOutlinePath(path, content, revision, context, range) {
        const parsed = parseCode(path, content);
        if (parsed.supported)
            return await this.outline(path, content, parsed.symbols, revision, context, range);
        return await this.raw(path, content, revision, context, "symbol_view_unavailable");
    }
    async readLineRange(path, content, input, revision, context) {
        if (!input.range)
            throw new Error("range is required for the range view.");
        const range = lineByteRange(content, input.range.startLine, input.range.endLine);
        const editTargets = this.registerEditTargets(path, content, revision, [
            range,
        ]);
        return await this.coveredContent(path, content, [range], context, "range", undefined, false, editTargets);
    }
    async outline(path, content, symbols, revision, context, range) {
        const projection = await this.prepareOutline(path, content, symbols, revision, context, range);
        if (!projection)
            return emptyOutline(path);
        const { candidates, coverage, editTargets, selected } = projection;
        const items = this.outlineItems(path, content, selected, revision);
        return outlineResult(path, items, candidates.length, coverage.receipt, editTargets);
    }
    async prepareOutline(path, content, symbols, revision, context, range) {
        const candidates = outlineRangeCandidates(symbols, range);
        const selected = candidates.slice(0, maximumOutlineItems);
        if (!selected.length)
            return undefined;
        const interval = range
            ? lineByteRange(content, range.startLine, range.endLine)
            : undefined;
        const editTargets = this.registerEditTargets(path, content, revision, interval ? [interval] : undefined);
        const coverage = await this.registerCoverage(path, content, selected.map(signatureRange), context);
        return { candidates, coverage, editTargets, selected };
    }
    outlineItems(path, content, symbols, revision) {
        const registered = symbols.map((symbol) => {
            const { alias, materialized } = this.aliases.registerSymbol(path, content, symbol, revision);
            return { alias, materialized, symbol };
        });
        return registered.map(({ alias, materialized, symbol }) => {
            const parent = enclosingOutlineTarget(symbol, registered);
            return {
                alias,
                ...outlineSymbol(materialized),
                ...(parent ? { containedBy: parent.alias } : {}),
            };
        });
    }
    async readSymbol(target, revision, context, input = { target }) {
        const resolved = await this.resolveReadSymbol(target, revision);
        if (requestedLineRange(input))
            return this.readLineRange(resolved.path, resolved.content, input, revision, context);
        if (input.view === "outline")
            return this.symbolOutline(resolved, revision, context);
        if (input.view === "signature")
            return this.readSignature(resolved, context);
        const [start, end] = resolved.symbol.range_utf8_bytes;
        if (end - start > maximumRawCharacters) {
            let boundedEnd = start + maximumRawCharacters;
            while (boundedEnd > start && (resolved.content[boundedEnd] & 0xc0) === 0x80)
                boundedEnd--;
            return this.coveredContent(resolved.path, resolved.content, [[start, boundedEnd]], context, "range", "symbol_exceeds_inline_budget", true, [{ alias: resolved.alias, qualifiedName: resolved.symbol.qualified_name }]);
        }
        const { signature, body, imports, coverage } = await this.symbolProjection(resolved, context);
        return symbolContentResult(resolved, signature, body, imports, [signature, body, ...coverage.uncovered], coverage.receipt);
    }
    async resolveReadSymbol(target, revision) {
        const candidate = await this.aliases.resolveSymbol(target, this.files, revision);
        const registered = this.aliases.registerSymbol(candidate.path, candidate.content, candidate.symbol, revision);
        return {
            ...candidate,
            alias: registered.alias,
            materialized: registered.materialized,
        };
    }
    async readSignature(resolved, context) {
        const [start, end] = signatureRange(resolved.symbol);
        let boundedEnd = Math.min(end, start + 4_096);
        while (boundedEnd > start && (resolved.content[boundedEnd] & 0xc0) === 0x80)
            boundedEnd--;
        const coverage = await this.registerCoverage(resolved.path, resolved.content, [[start, boundedEnd]], context);
        return { status: "ok", receipt: coverage.receipt, data: {
                path: resolved.path, alias: resolved.alias, view: "signature",
                qualifiedName: resolved.symbol.qualified_name,
                signature: resolved.content.subarray(start, boundedEnd).toString("utf8"),
                truncated: boundedEnd < end, bodyOmitted: boundedEnd < resolved.symbol.range_utf8_bytes[1],
                guidance: "Only these header bytes were read. Use the symbol view for implementation, type members or a complete declaration before editing or rename.",
            } };
    }
    async symbolOutline(resolved, revision, context) {
        const [start, end] = resolved.symbol.range_utf8_bytes;
        const symbols = parseCode(resolved.path, resolved.content).symbols.filter(({ range_utf8_bytes: range }) => range[0] >= start && range[1] <= end);
        const [startLine, endLine] = resolved.symbol.line_range;
        return this.outline(resolved.path, resolved.content, symbols, revision, context, { startLine, endLine });
    }
    async symbolProjection(resolved, context) {
        const signature = symbolEditRange(resolved.symbol, "signature");
        const range = symbolEditRange(resolved.symbol, "body");
        const body = capabilityForPath(resolved.path)?.language === "python"
            ? pythonBodyRange(resolved.content, range)
            : range;
        const imports = shortImportBlock(resolved.content.toString("utf8"));
        const coverage = await this.registerCoverage(resolved.path, resolved.content, [resolved.symbol.range_utf8_bytes, ...(imports ? [imports.range] : [])], context);
        return { signature, body, imports, coverage };
    }
    async readRangeAlias(alias, input, revision, context) {
        const content = (await this.files.read(alias.path)).content;
        if (sha256(content) !== alias.fileHash)
            throw new Error(`${alias.alias} is stale and cannot be relocated as text.`);
        if (requestedLineRange(input))
            return this.readLineRange(alias.path, content, input, revision, context);
        if (input.view === "symbol") {
            const symbol = enclosingSymbol(parseCode(alias.path, content).symbols, [
                alias.start,
                alias.end,
            ]);
            if (symbol) {
                const registered = this.aliases.registerSymbol(alias.path, content, symbol, revision);
                return this.readSymbol(registered.alias, revision, context);
            }
        }
        const intervals = [[alias.start, alias.end]];
        const editTargets = this.registerEditTargets(alias.path, content, revision, intervals);
        return await this.coveredContent(alias.path, content, intervals, context, "range", undefined, false, editTargets);
    }
    async raw(path, content, revision, context, fallbackReason) {
        let end = Math.min(content.byteLength, maximumRawCharacters);
        while (end > 0 && end < content.length && (content[end] & 0xc0) === 0x80)
            end--;
        const editTargets = this.registerEditTargets(path, content, revision);
        return await this.coveredContent(path, content, [[0, end]], context, "raw", fallbackReason, content.byteLength > end, editTargets);
    }
    async coveredContent(path, content, intervals, context, view, fallbackReason, truncated = false, editTargets = []) {
        const coverage = await this.registerCoverage(path, content, intervals, context);
        return contentResult(path, content, intervals, view, coverage.receipt, fallbackReason, truncated, editTargets);
    }
    registerEditTargets(path, content, revision, intervals) {
        if (content.byteLength > 2 * 1024 * 1024)
            return [];
        const parsed = parseCode(path, content);
        if (!parsed.supported)
            return [];
        return editTargetSymbols(parsed.symbols, intervals).map((symbol) => {
            const { alias, materialized } = this.aliases.registerSymbol(path, content, symbol, revision);
            return { alias, qualifiedName: materialized.qualified_name };
        });
    }
    async registerCoverage(path, content, intervals, context) {
        this.aliases.observe(path, content, intervals);
        const result = this.coverage.register({
            consumerId: context.agentId ||
                context.conversationId ||
                context.sessionId ||
                "lead",
            generation: contextGeneration(context),
            hash: sha256(content),
            intervals,
            path,
        });
        await this.journal.recordCoverage(this.coverage.snapshot());
        return result;
    }
}
function enclosingOutlineTarget(symbol, candidates) {
    return candidates
        .filter(({ symbol: candidate }) => candidate !== symbol &&
        candidate.range_utf8_bytes[0] <= symbol.range_utf8_bytes[0] &&
        candidate.range_utf8_bytes[1] >= symbol.range_utf8_bytes[1])
        .sort((left, right) => byteLength(left.symbol) - byteLength(right.symbol))[0];
}
function byteLength(symbol) {
    return symbol.range_utf8_bytes[1] - symbol.range_utf8_bytes[0];
}
function emptyOutline(path) {
    return {
        status: "ok",
        data: { path, view: "outline", items: [], truncated: false },
    };
}
function directoryEntries(path, files) {
    const prefix = path === "." ? "" : `${path}/`;
    const entries = new Map();
    for (const file of files) {
        if (!file.startsWith(prefix))
            continue;
        const [name, ...descendants] = file.slice(prefix.length).split("/");
        if (!name)
            continue;
        const child = `${prefix}${name}`;
        entries.set(child, descendants.length ? "directory" : "file");
    }
    return [...entries]
        .map(([target, kind]) => ({ kind, target }))
        .sort((left, right) => left.kind.localeCompare(right.kind) ||
        left.target.localeCompare(right.target));
}
function coveredDirectoryResult(path, receipt) {
    return {
        status: "ok",
        data: {
            status: "already_in_context",
            target: path,
            path,
            view: "directory",
        },
        receipt,
    };
}
function outlineResult(path, items, total, receipt, editTargets) {
    return {
        status: "ok",
        receipt,
        data: {
            path,
            view: "outline",
            items,
            editTargets,
            truncated: total > items.length,
        },
    };
}
function symbolContentResult(resolved, signature, body, imports, uncovered, receipt) {
    return {
        status: "ok",
        receipt,
        data: {
            path: resolved.path,
            view: "symbol",
            alias: resolved.alias,
            editTarget: resolved.alias,
            kind: resolved.materialized.kind,
            qualifiedName: resolved.materialized.qualified_name,
            ...symbolProjectedContent(resolved, signature, body, imports, uncovered),
        },
    };
}
function symbolProjectedContent(resolved, signature, body, imports, uncovered) {
    return {
        ...(rangeHasDelta(signature, uncovered)
            ? { signature: resolved.content.subarray(resolved.symbol.range_utf8_bytes[0], body[0]).toString("utf8") }
            : {}),
        ...(rangeHasDelta(body, uncovered)
            ? { body: resolved.content.subarray(body[0], resolved.symbol.range_utf8_bytes[1]).toString("utf8") }
            : {}),
        ...(imports && rangeHasDelta(imports.range, uncovered)
            ? { imports: imports.content }
            : {}),
    };
}
function contentResult(path, content, intervals, view, receipt, fallbackReason, truncated = false, editTargets = []) {
    const segments = intervals.map(([start, end]) => ({
        range: [start, end],
        content: content.subarray(start, end).toString("utf8"),
    }));
    const projected = segments.length === 1 ? { content: segments[0].content } : { segments };
    return {
        status: "ok",
        receipt,
        data: {
            path,
            view,
            complete: intervals.length === 1 &&
                intervals[0][0] === 0 &&
                intervals[0][1] === content.byteLength,
            ...(fallbackReason ? { fallbackReason } : {}),
            ...(editTargets.length ? { editTargets } : {}),
            ...projected,
            truncated,
            ...(truncated ? truncatedReadGuidance(path, content, intervals) : {}),
        },
    };
}
function truncatedReadGuidance(path, content, intervals) {
    const end = Math.max(...intervals.map(([, stop]) => stop));
    // Include the last partial line again: neither byte limits nor UTF-8 may
    // skip source. Hints do not register additional observed coverage.
    const startLine = content.subarray(0, end).toString("utf8").split("\n").length;
    const totalLines = content.toString("utf8").split("\n").length;
    return {
        observedRangesUtf8Bytes: intervals,
        nextRead: { target: path, view: "range", range: { startLine, endLine: Math.min(totalLines, startLine + 79) } },
        alternativeReads: symbolicPath(path) ? [{ target: path, view: "outline" }] : [],
        guidance: "This read is truncated. Continue with nextRead (which repeats a partial boundary line), or inspect the outline and read a relevant symbol. Unseen bytes are not observed edit coverage. An explicit line range can exceed the inline byte limit for a very long line.",
    };
}
function signatureRange(symbol) {
    return symbolEditRange(symbol, "signature");
}
function rangesOverlap(left, right) {
    return left[0] < right[1] && right[0] < left[1];
}
function rangeHasDelta(range, uncovered) {
    return uncovered.some((candidate) => rangesOverlap(range, candidate));
}
function capabilitiesResult() {
    return {
        status: "ok",
        data: {
            description: lightCapabilityDescription(),
            languages: runtimeCapabilityRegistry(),
        },
    };
}
function lineByteRange(content, startLine, endLine) {
    const lines = content.toString("utf8").split(/(?<=\n)/u);
    if (startLine > lines.length)
        throw new Error("Range starts after the end of the file.");
    const start = Buffer.byteLength(lines.slice(0, startLine - 1).join(""));
    const end = Buffer.byteLength(lines.slice(0, Math.min(endLine, lines.length)).join(""));
    return [start, end];
}
function shortImportBlock(source) {
    const expression = /^\s*(?:import\b|from\b|use\b|package\b|using\b|#include\b)/u;
    const lines = source.split(/(?<=\n)/u).slice(0, 40);
    const offsets = lines.reduce((values, line) => {
        values.push((values.at(-1) ?? 0) + line.length);
        return values;
    }, []);
    const selected = lines.flatMap((line, index) => expression.test(line) ? [index] : []);
    if (!selected.length)
        return undefined;
    const start = selected[0] === 0 ? 0 : offsets[selected[0] - 1];
    const end = offsets[selected.at(-1)];
    const content = source.slice(start, end);
    if (content.length > 2_000)
        return undefined;
    return {
        content,
        range: [
            Buffer.byteLength(source.slice(0, start)),
            Buffer.byteLength(source.slice(0, end)),
        ],
    };
}
export function contextGeneration(context) {
    const metadata = context.metadata ?? {};
    const generation = metadata.contextGeneration ?? metadata.contextEpoch;
    if (typeof generation === "string" || typeof generation === "number")
        return String(generation);
    const summary = [...(context.snapshot?.messages ?? [])]
        .reverse()
        .find((message) => message.metadata?.kind === "compaction_summary");
    return summary ? `compaction:${summary.id}` : "initial";
}
function inputBlocked(error) {
    const diagnosticId = `read-${Date.now().toString(36)}`;
    const message = error instanceof Error ? error.message : String(error);
    const recovery = error instanceof SymbolResolutionError && error.candidates.length
        ? JSON.stringify(error.candidates)
        : undefined;
    return {
        status: "blocked",
        category: "input",
        message,
        diagnosticId,
        ...(recovery ? { recovery } : {}),
    };
}
function arrayValue(value) {
    return Array.isArray(value) ? value : [];
}
function readableSource(content) {
    if (content.includes(0) || !isUtf8(content) || content.subarray(0, 5).toString("ascii") === "%PDF-")
        throw new Error("Binary or PDF content is not source text. Use run_task to extract text or render images, then read the output.");
    return content.toString("utf8");
}
