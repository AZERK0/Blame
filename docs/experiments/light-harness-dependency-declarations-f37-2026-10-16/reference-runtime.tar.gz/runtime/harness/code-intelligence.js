import bashLanguage from "@ast-grep/lang-bash";
import cLanguage from "@ast-grep/lang-c";
import cppLanguage from "@ast-grep/lang-cpp";
import csharpLanguage from "@ast-grep/lang-csharp";
import goLanguage from "@ast-grep/lang-go";
import javaLanguage from "@ast-grep/lang-java";
import pythonLanguage from "@ast-grep/lang-python";
import rustLanguage from "@ast-grep/lang-rust";
import { Lang, parse, registerDynamicLanguage, } from "@ast-grep/napi";
import { packagedResourcePath } from "./packaged-resource-path.js";
import { sha256 } from "./light-identity.js";
import { languageCapability, } from "./language-capabilities.js";
import { componentElementBodyRange, componentElementName, } from "./component-symbols.js";
let dynamicLanguagesRegistered = false;
const maximumCachedParses = 64;
const parseCache = new Map();
export function parseCode(path, content) {
    const cacheKey = `${extension(path)}\0${sha256(content)}`;
    const cached = parseCache.get(cacheKey);
    if (cached) {
        parseCache.delete(cacheKey);
        parseCache.set(cacheKey, cached);
        return cached;
    }
    const parsed = parseCodeUncached(path, content);
    parseCache.set(cacheKey, parsed);
    trimParseCache();
    return parsed;
}
export function syntaxBoundaryRange(path, content, target) {
    const parsed = parseCode(path, content);
    const candidate = parsed.trees
        .map((tree) => boundaryCandidate(tree, target))
        .filter((value) => Boolean(value))
        .sort((left, right) => nodeSize(left) - nodeSize(right))[0];
    if (!candidate)
        return target;
    const node = outerInsertionNode(candidate.node);
    const range = byteRange(node, candidate);
    // TS member separators are siblings of method_signature, not part of it.
    // Keep the complete member boundary without consuming a following member.
    const separator = parsed.language === "typescript" && String(node.kind()) === "method_signature"
        ? node.next() : undefined;
    if (separator && [";", ","].includes(String(separator.kind()))) {
        const [start, end] = byteRange(separator, candidate);
        if (!content.subarray(range[1], start).toString("utf8").trim())
            range[1] = end;
    }
    return range;
}
function boundaryCandidate(tree, target) {
    let selected;
    walk(tree.root, (node) => {
        const range = byteRange(node, tree);
        if (range[0] > target[0] || range[1] < target[1])
            return;
        if (!selected || node.text().length < selected.text().length)
            selected = node;
    });
    return selected ? { ...tree, node: selected } : undefined;
}
function outerInsertionNode(initial) {
    let node = initial;
    for (let parent = node.parent(); parent; parent = node.parent()) {
        if (!parent.parent() || isSyntaxContainer(String(parent.kind())))
            break;
        node = parent;
    }
    return node;
}
function isSyntaxContainer(kind) {
    return (syntaxContainerKinds.has(kind) ||
        kind.startsWith("preproc_") ||
        /(?:^|_)(?:body|block|list)$/u.test(kind));
}
function nodeSize(node) {
    const range = byteRange(node.node, node);
    return range[1] - range[0];
}
const syntaxContainerKinds = new Set([
    "arguments",
    "array",
    "document",
    "formal_parameters",
    "jsx_element",
    "module",
    "object",
    "object_type",
    "program",
    "source_file",
    "stylesheet",
]);
export function materializeSymbol(input) {
    const { symbol } = input;
    const { byteOffset, lineOffset, node, root, utf8Offsets, ...publicSymbol } = symbol;
    void byteOffset;
    void lineOffset;
    void node;
    void root;
    void utf8Offsets;
    return publicSymbol;
}
export function symbolEditRange(symbol, view) {
    const range = byteRange(symbol.node, symbol);
    if (view === "symbol")
        return range;
    const elementBody = componentElementBodyRange(symbol.node, symbol);
    if (view === "body" && elementBody)
        return elementBody;
    if (view === "signature" && elementBody)
        return [range[0], elementBody[0]];
    const body = bodyNode(symbol.node);
    if (view === "body")
        return body ? byteRange(body, symbol) : range;
    return [range[0], body ? byteRange(body, symbol)[0] : range[1]];
}
export function outlineSymbol(symbol, include = ["signature"]) {
    return {
        kind: symbol.kind,
        name: symbol.name,
        qualified_name: symbol.qualified_name,
        line_range: symbol.line_range,
        ...(include.includes("signature") ? { signature: symbol.signature } : {}),
        ...(include.includes("visibility") && symbol.visibility
            ? { visibility: symbol.visibility }
            : {}),
    };
}
function parseCodeUncached(path, content) {
    const language = languageName(path);
    try {
        const units = sourceUnits(path, content.toString("utf8"));
        if (!units)
            return unsupportedParse();
        const symbols = [];
        for (const unit of units)
            collectSymbols(unit.root, content, unit, [], symbols);
        return {
            language,
            supported: true,
            symbols,
            errorCount: units.reduce((count, unit) => count + countErrorNodes(unit.root), 0),
            trees: units,
        };
    }
    catch {
        return {
            language,
            supported: false,
            symbols: [],
            errorCount: 1,
            trees: [],
        };
    }
}
function unsupportedParse() {
    return {
        language: "unknown",
        supported: false,
        symbols: [],
        errorCount: 0,
        trees: [],
    };
}
function sourceUnits(path, source) {
    if ([".svelte", ".vue"].includes(extension(path)))
        return componentSourceUnits(source);
    const language = directLanguage(path);
    if (!language)
        return undefined;
    return [parseSourceUnit(language, source, 0, 0)];
}
function componentSourceUnits(source) {
    const units = [
        parseSourceUnit({ lang: Lang.Html, name: "component" }, source, 0, 0),
    ];
    const expression = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/giu;
    for (const match of source.matchAll(expression)) {
        const content = match[2] ?? "";
        const contentIndex = (match.index ?? 0) + (match[0].indexOf(">") + 1);
        const prefix = source.slice(0, contentIndex);
        const language = /\blang\s*=\s*["'](?:ts|tsx)["']/iu.test(match[1] ?? "")
            ? { lang: Lang.TypeScript, name: "vue" }
            : { lang: Lang.JavaScript, name: "vue" };
        units.push(parseSourceUnit(language, content, Buffer.byteLength(prefix), lineCount(prefix) - 1));
    }
    return units;
}
function parseSourceUnit(language, source, byteOffset, lineOffset) {
    ensureDynamicLanguages(language.lang);
    return {
        byteOffset,
        lineOffset,
        root: parse(language.lang, source).root(),
        utf8Offsets: sourceUtf8Offsets(source),
        source,
    };
}
function ensureDynamicLanguages(language) {
    if (dynamicLanguagesRegistered || !dynamicLanguageNames.has(String(language)))
        return;
    registerDynamicLanguage({
        bash: loadableLanguage(bashLanguage),
        c: loadableLanguage(cLanguage),
        cpp: loadableLanguage(cppLanguage),
        csharp: loadableLanguage(csharpLanguage),
        go: loadableLanguage(goLanguage),
        java: loadableLanguage(javaLanguage),
        python: loadableLanguage(pythonLanguage),
        rust: loadableLanguage(rustLanguage),
    });
    dynamicLanguagesRegistered = true;
}
function loadableLanguage(language) {
    return {
        ...language,
        libraryPath: packagedResourcePath(language.libraryPath),
    };
}
function collectSymbols(node, source, tree, containers, output) {
    const symbol = symbolFromNode(node, source, tree, containers);
    const nextContainers = symbol ? [...containers, symbol.name] : containers;
    if (symbol)
        output.push(symbol);
    for (const child of node.children())
        collectSymbols(child, source, tree, nextContainers, output);
}
function symbolFromNode(node, source, tree, containers) {
    const kind = symbolKind(node);
    if (!kind)
        return undefined;
    const name = symbolName(node, kind);
    if (!name)
        return undefined;
    return {
        ...tree,
        node,
        kind,
        name,
        qualified_name: qualifiedName(kind, containers, name),
        signature: signature(node, source, tree),
        ...(visibility(node) ? { visibility: visibility(node) } : {}),
        range_utf8_bytes: byteRange(node, tree),
        line_range: lineRange(node, tree.lineOffset),
    };
}
function symbolKind(node) {
    if (["element", "script_element", "self_closing_tag", "style_element"].includes(String(node.kind())))
        return "element";
    if (node.kind() === "rule_set")
        return "css_rule";
    if (node.kind() === "media_statement")
        return "css_media";
    if (node.kind() === "keyframes_statement")
        return "css_keyframes";
    if (node.kind() === "declaration" &&
        node
            .children()
            .find((child) => child.kind() === "property_name")
            ?.text()
            .startsWith("--"))
        return "css_custom_property";
    if (node.kind() === "variable_declarator")
        return isRelevantVariable(node) ? "variable" : undefined;
    if (node.kind() === "function_definition")
        return hasAnyAncestor(node, ["class_definition", "class_specifier"])
            ? "method"
            : "function";
    if (node.kind() === "function_item")
        return hasAncestor(node, "impl_item") ? "method" : "function";
    if (node.kind() === "type_spec")
        return goTypeKind(node);
    return symbolKindByNode[node.kind()];
}
function goTypeKind(node) {
    const type = fieldNode(node, "type")?.kind();
    if (type === "struct_type")
        return "struct";
    if (type === "interface_type")
        return "interface";
    return "type";
}
function symbolName(node, kind) {
    if (kind === "element")
        return componentElementName(node);
    if (kind.startsWith("css_"))
        return cssSymbolName(node, kind);
    const named = fieldNode(node, "name")?.text().trim();
    if (named)
        return named;
    const declarator = fieldNode(node, "declarator");
    const declared = declaratorName(declarator);
    if (declared)
        return declared;
    if (kind === "variable")
        return node.child(0)?.text().trim();
    return node
        .children()
        .find((child) => /(?:identifier|name)$/u.test(String(child.kind())))
        ?.text()
        .trim();
}
function declaratorName(node) {
    if (!node)
        return undefined;
    if (["identifier", "field_identifier"].includes(String(node.kind())))
        return node.text().trim();
    return declaratorName(fieldNode(node, "declarator"));
}
function isRelevantVariable(node) {
    if (isFunctionVariable(node))
        return true;
    return node
        .ancestors()
        .every((ancestor) => !functionLikeKinds.has(String(ancestor.kind())));
}
function isFunctionVariable(node) {
    const value = fieldNode(node, "value");
    return (value?.kind() === "arrow_function" ||
        value?.kind() === "function_expression");
}
function signature(node, source, tree) {
    const range = byteRange(node, tree);
    const body = bodyNode(node);
    const elementBody = componentElementBodyRange(node, tree);
    const end = elementBody?.[0] ?? (body ? byteRange(body, tree)[0] : range[1]);
    return compact(source.subarray(range[0], end).toString("utf8").trimEnd(), 500);
}
function bodyNode(node) {
    const direct = fieldNode(node, "body");
    if (direct)
        return direct;
    const value = fieldNode(node, "value");
    if (value)
        return fieldNode(value, "body") ?? value;
    return node
        .children()
        .find((child) => ["block", "keyframe_block_list"].includes(String(child.kind())));
}
function qualifiedName(kind, containers, name) {
    const separator = kind.startsWith("css_") ? "::" : ".";
    return [...containers, name].join(separator);
}
function fieldNode(node, name) {
    try {
        return node.field(name) ?? undefined;
    }
    catch {
        return undefined;
    }
}
function visibility(node) {
    const prefix = node.text().slice(0, 100);
    if (/\bprivate\b/u.test(prefix))
        return "private";
    if (/\bprotected\b/u.test(prefix))
        return "protected";
    if (/\bpublic\b/u.test(prefix))
        return "public";
    if (/\bpub(?:\([^)]*\))?\b/u.test(prefix))
        return "exported";
    if (hasAncestor(node, "export_statement"))
        return "exported";
    return undefined;
}
function cssSymbolName(node, kind) {
    if (kind === "css_rule")
        return namedChildText(node, "selectors");
    if (kind === "css_media") {
        const query = namedChildText(node, "feature_query");
        return query ? `@media${query}` : "@media";
    }
    if (kind === "css_keyframes") {
        const name = namedChildText(node, "keyframes_name");
        return name ? `@keyframes(${name})` : "@keyframes";
    }
    return namedChildText(node, "property_name");
}
function namedChildText(node, kind) {
    return node
        .children()
        .find((child) => child.kind() === kind)
        ?.text()
        .trim();
}
function directLanguage(path) {
    const parserId = languageCapability(path).parserId;
    if (!parserId || parserId === "svelte" || parserId === "vue")
        return undefined;
    return languageByParserId[parserId];
}
export function semanticLanguageName(path) {
    const parserId = languageCapability(path).parserId;
    if (!parserId)
        return "unknown";
    if ([".js", ".jsx", ".mjs", ".cjs"].includes(extension(path)))
        return "javascript";
    if ([".ts", ".tsx", ".mts", ".cts"].includes(extension(path)))
        return "typescript";
    return parserId;
}
function languageName(path) {
    return semanticLanguageName(path);
}
function extension(path) {
    return path.toLowerCase().match(/\.[^.]+$/u)?.[0] ?? "";
}
function countErrorNodes(root) {
    return syntaxErrorNodes(root).length;
}
function syntaxErrorNodes(root) {
    const errors = [];
    walk(root, (node) => {
        if (node.kind() === "ERROR" || node.kind() === "MISSING" || missingSyntaxToken(node))
            errors.push(node);
    });
    return errors;
}
function missingSyntaxToken(node) {
    if (!node.isLeaf() || node.isNamed())
        return false;
    const range = node.range();
    return range.start.index === range.end.index;
}
export function parseSyntaxDiagnostics(parsed, content) {
    return parsed.trees.flatMap((tree) => syntaxErrorNodes(tree.root).slice(0, 20).map((node) => {
        const prefix = content.subarray(0, byteRange(node, tree)[0]).toString("utf8");
        const location = `${prefix.split("\n").length}:${prefix.length - prefix.lastIndexOf("\n")}`;
        const detail = node.kind() === "ERROR"
            ? `Unexpected syntax ${JSON.stringify(node.text().slice(0, 120))}`
            : `Expected ${JSON.stringify(node.kind())}`;
        return `${location} ${detail}`;
    })).slice(0, 20);
}
function walk(node, visit) {
    visit(node);
    for (const child of node.children())
        walk(child, visit);
}
function byteRange(node, tree) {
    return [
        tree.byteOffset + tree.utf8Offsets[node.range().start.index],
        tree.byteOffset + tree.utf8Offsets[node.range().end.index],
    ];
}
function sourceUtf8Offsets(source) {
    const offsets = new Uint32Array(source.length + 1);
    let byteOffset = 0;
    for (let index = 0; index < source.length; index += 1) {
        offsets[index] = byteOffset;
        const codePoint = source.codePointAt(index);
        if (codePoint > 0xffff)
            offsets[++index] = byteOffset;
        byteOffset += utf8CodePointWidth(codePoint);
    }
    offsets[source.length] = byteOffset;
    return offsets;
}
function utf8CodePointWidth(codePoint) {
    if (codePoint <= 0x7f)
        return 1;
    if (codePoint <= 0x7ff)
        return 2;
    if (codePoint <= 0xffff)
        return 3;
    return 4;
}
function lineRange(node, lineOffset = 0) {
    return [
        lineOffset + node.range().start.line + 1,
        lineOffset + node.range().end.line + 1,
    ];
}
function hasAncestor(node, kind) {
    return node.ancestors().some((ancestor) => ancestor.kind() === kind);
}
function hasAnyAncestor(node, kinds) {
    return node
        .ancestors()
        .some((ancestor) => kinds.includes(String(ancestor.kind())));
}
function lineCount(value) {
    return value.split("\n").length;
}
function trimParseCache() {
    while (parseCache.size > maximumCachedParses) {
        const oldest = parseCache.keys().next().value;
        if (typeof oldest !== "string")
            return;
        parseCache.delete(oldest);
    }
}
function compact(value, maximum) {
    const normalized = value.replace(/\s+/gu, " ").trim();
    return normalized.length > maximum
        ? `${normalized.slice(0, maximum - 1)}…`
        : normalized;
}
const functionLikeKinds = new Set([
    "arrow_function",
    "function_declaration",
    "function_definition",
    "function_expression",
    "function_item",
    "method_declaration",
    "method_definition",
]);
const symbolKindByNode = {
    abstract_class_declaration: "class",
    abstract_method_signature: "method",
    class_definition: "class",
    class_declaration: "class",
    class_specifier: "class",
    constructor_declaration: "constructor",
    enum_declaration: "enum",
    enum_specifier: "enum",
    enum_item: "enum",
    file_scoped_namespace_declaration: "namespace",
    function_declaration: "function",
    generator_function_declaration: "function",
    interface_declaration: "interface",
    method_declaration: "method",
    method_definition: "method",
    method_signature: "method",
    mod_item: "module",
    module_declaration: "module",
    namespace_declaration: "namespace",
    namespace_definition: "namespace",
    property_declaration: "property",
    record_declaration: "class",
    struct_declaration: "struct",
    struct_specifier: "struct",
    struct_item: "struct",
    trait_item: "trait",
    type_alias_declaration: "type",
};
const languageByParserId = {
    bash: { lang: "bash", name: "bash" },
    c: { lang: "c", name: "c" },
    cpp: { lang: "cpp", name: "cpp" },
    csharp: { lang: "csharp", name: "csharp" },
    css: { lang: Lang.Css, name: "css" },
    go: { lang: "go", name: "go" },
    html: { lang: Lang.Html, name: "html" },
    java: { lang: "java", name: "java" },
    javascript: { lang: Lang.JavaScript, name: "javascript" },
    python: { lang: "python", name: "python" },
    rust: { lang: "rust", name: "rust" },
    tsx: { lang: Lang.Tsx, name: "typescript" },
    typescript: { lang: Lang.TypeScript, name: "typescript" },
};
const dynamicLanguageNames = new Set([
    "bash",
    "c",
    "cpp",
    "csharp",
    "go",
    "java",
    "python",
    "rust",
]);
