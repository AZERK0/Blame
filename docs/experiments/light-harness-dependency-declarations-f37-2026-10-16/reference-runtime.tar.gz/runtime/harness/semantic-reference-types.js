export const semanticReferenceLimits = {
    timeoutMs: 8_000,
    renameTimeoutMs: 12_000,
    workerHeapMb: 512,
    rootFiles: 2_000,
    observedFiles: 6_000,
    observedExistence: 30_000,
    observedBytes: 64 * 1024 * 1024,
    locations: 10_000,
};
