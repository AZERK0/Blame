import { spawn } from "node:child_process";
import { execa } from "execa";
import { StringDecoder } from "node:string_decoder";
import { workspaceCommandEnvironment } from "./workspace-command-environment.js";
export function executeWorkspaceCommand(executable, args, options) {
    return startWorkspaceCommand(executable, args, options).completion;
}
export function startWorkspaceCommand(executable, args, options) {
    options.signal?.throwIfAborted();
    const child = spawnWorkspaceProcess(executable, args, options.cwd);
    const execution = new CommandExecution(child, options);
    return {
        completion: execution.run(),
        inspect: (cursor) => execution.inspect(cursor),
    };
}
function spawnWorkspaceProcess(executable, args, cwd) {
    const options = {
        cwd,
        env: workspaceCommandEnvironment(process.env, executable),
        detached: process.platform !== "win32",
        stdio: ["ignore", "pipe", "pipe"],
        windowsHide: true,
    };
    if (process.platform !== "win32")
        return spawn(executable, args, options);
    const child = execa(executable, args, {
        ...options,
        buffer: false,
        extendEnv: false,
        reject: false,
    });
    void child.catch(() => undefined);
    return child;
}
class CommandExecution {
    child;
    options;
    chunks = [];
    bytes = 0;
    finished = false;
    exitCode;
    interruption;
    error;
    timer;
    drainTimer;
    resolve;
    cancel = () => this.interrupt("cancelled");
    constructor(child, options) {
        this.child = child;
        this.options = options;
    }
    run() {
        const completion = new Promise((resolve) => {
            this.resolve = resolve;
        });
        this.capture(this.child.stdout);
        this.capture(this.child.stderr);
        this.child.once("error", (error) => this.spawnError(error));
        this.child.once("exit", (code, signal) => this.exited(code, signal));
        this.child.once("close", () => this.finish());
        this.timer = setTimeout(() => this.interrupt("timed_out"), this.options.timeoutMs ?? 120_000);
        this.options.signal?.addEventListener("abort", this.cancel, { once: true });
        if (this.options.signal?.aborted)
            this.cancel();
        return completion;
    }
    inspect(cursor) {
        const offset = cursor === undefined ? 0 : Number(cursor);
        if (!Number.isSafeInteger(offset) || offset < 0 || offset > this.bytes)
            throw new Error(`Invalid run cursor ${cursor}.`);
        const content = Buffer.concat(this.chunks);
        return {
            cursor: String(this.bytes),
            output: content.subarray(offset).toString("utf8"),
            process: this.interruption === "cancelled"
                ? "cancelled"
                : this.interruption === "timed_out"
                    ? "timed_out"
                    : this.finished
                        ? "exited"
                        : "running",
        };
    }
    capture(stream) {
        if (!stream)
            return;
        const decoder = new StringDecoder("utf8");
        stream.on("data", (chunk) => this.append(Buffer.from(decoder.write(chunk))));
        stream.once("end", () => this.append(Buffer.from(decoder.end())));
        stream.once("error", (error) => {
            terminateCommand(this.child);
            this.spawnError(error);
        });
    }
    append(chunk) {
        if (this.finished || this.interruption)
            return;
        const limit = this.options.maximumOutputBytes ?? 512 * 1024;
        const remaining = limit - this.bytes;
        const retained = chunk.subarray(0, remaining);
        this.chunks.push(retained);
        this.bytes += retained.length;
        if (chunk.length > remaining)
            this.interrupt("output_limit");
    }
    exited(code, signal) {
        if (this.finished)
            return;
        this.exitCode = code ?? undefined;
        if (signal)
            this.error = `Command terminated by ${signal}.`;
        this.scheduleDrain();
    }
    spawnError(error) {
        this.error = error.message;
        this.finish();
    }
    interrupt(reason) {
        if (this.finished || this.interruption)
            return;
        this.interruption = reason;
        terminateCommand(this.child);
        this.scheduleDrain();
    }
    scheduleDrain() {
        if (!this.drainTimer)
            this.drainTimer = setTimeout(() => this.finish(), 100);
    }
    finish() {
        if (this.finished)
            return;
        this.finished = true;
        clearTimeout(this.timer);
        clearTimeout(this.drainTimer);
        this.options.signal?.removeEventListener("abort", this.cancel);
        this.child.stdout?.destroy();
        this.child.stderr?.destroy();
        this.child.unref();
        this.resolve({
            all: this.output(),
            exitCode: this.exitCode,
            failed: this.exitCode !== 0 || !!this.interruption || !!this.error,
            ...(this.interruption ? { interruption: this.interruption } : {}),
        });
    }
    output() {
        const diagnostic = this.interruption
            ? interruptionDiagnostic(this.interruption, this.options.timeoutMs)
            : this.error;
        return [Buffer.concat(this.chunks).toString("utf8"), diagnostic]
            .filter(Boolean)
            .join("\n");
    }
}
function terminateCommand(child) {
    if (!child.pid)
        return;
    if (process.platform === "win32") {
        const cleanup = spawn("taskkill", ["/pid", String(child.pid), "/T", "/F"], {
            stdio: "ignore",
            windowsHide: true,
        });
        cleanup.once("error", () => child.kill());
        cleanup.unref();
        return;
    }
    try {
        process.kill(-child.pid, "SIGKILL");
    }
    catch (error) {
        if (error.code !== "ESRCH")
            child.kill("SIGKILL");
    }
}
function interruptionDiagnostic(reason, timeoutMs = 120_000) {
    if (reason === "cancelled")
        return "Command cancelled before completion.";
    if (reason === "timed_out")
        return `Command timed out after ${timeoutMs} ms.`;
    return "Command exceeded the captured output limit.";
}
