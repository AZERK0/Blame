import { resolve } from "node:path";
export class EnvironmentAdapter {
    files;
    platform;
    constructor(files, platform = process.platform) {
        this.files = files;
        this.platform = platform;
    }
    command(command) {
        if (this.platform === "win32")
            return { executable: "cmd.exe", args: ["/d", "/s", "/c", command] };
        return {
            executable: "/bin/bash",
            args: ["-o", "pipefail", "-lc", command],
        };
    }
    async cwd(path = ".") {
        const normalized = this.files.normalizePath(path);
        const profile = await this.files.pathProfile(normalized);
        if (!profile.directory)
            throw new Error(`${normalized} is not a directory.`);
        return resolve(this.files.root, normalized);
    }
    target() {
        if (this.platform === "darwin")
            return "macos-native";
        if (this.platform === "win32")
            return "windows-native";
        return "linux-native";
    }
}
