import { ExecutionLifecycle, completionLifecycleTerminal, } from "@blame/harness-core";
export function completionAwareTerminalState(requested, completion) {
    if (requested !== "succeeded" || !completion)
        return requested;
    if (completion.delivery === "satisfied" &&
        completion.verification === "unverified" &&
        completion.reservations.some(({ code }) => code === "VALIDATION_UNAVAILABLE"))
        return "succeeded";
    return completionLifecycleTerminal(completion);
}
export class RunLifecycleRegistry {
    runs = new Map();
    begin(sessionId, executionId) {
        const current = this.runs.get(sessionId);
        if (current?.lifecycle.executionId === executionId)
            return snapshot(current);
        if (current && !terminalState(current.lifecycle.snapshot().state))
            return snapshot(current);
        const lifecycle = new ExecutionLifecycle(executionId);
        const run = { lifecycle, postStopEvents: 0, postStopTokens: 0, sessionId };
        this.runs.set(sessionId, run);
        return snapshot(run);
    }
    stopping(sessionId, executionId) {
        return (this.current(sessionId, executionId)?.lifecycle.requestStop() ?? false);
    }
    terminationPending(sessionId, executionId) {
        return (this.current(sessionId, executionId)?.lifecycle.terminationPending() ??
            false);
    }
    finish(sessionId, executionId, state, completion, reason = terminalReason(state)) {
        const run = this.current(sessionId, executionId);
        if (!run)
            return false;
        return run.lifecycle.finish(state, reason, completion);
    }
    accepts(sessionId, executionId, tokens = 0) {
        const run = this.current(sessionId, executionId);
        if (!run)
            return false;
        if (run.lifecycle.snapshot().state === "running")
            return true;
        run.postStopEvents += 1;
        run.postStopTokens += Math.max(0, tokens);
        return false;
    }
    canInvoke(sessionId, executionId) {
        return (this.current(sessionId, executionId)?.lifecycle.snapshot().state ===
            "running");
    }
    state(sessionId) {
        const run = this.runs.get(sessionId);
        return run ? snapshot(run) : undefined;
    }
    remove(sessionId) {
        this.runs.delete(sessionId);
    }
    current(sessionId, executionId) {
        const run = this.runs.get(sessionId);
        return run?.lifecycle.executionId === executionId ? run : undefined;
    }
}
function terminalReason(state) {
    if (state === "cancelled")
        return "user";
    if (state === "failed")
        return "code_failure";
    return "completed";
}
function terminalState(value) {
    return ["cancelled", "failed", "succeeded"].includes(value);
}
function snapshot(run) {
    const value = run.lifecycle.snapshot();
    return {
        execution_id: value.execution_id,
        post_stop_events: run.postStopEvents,
        post_stop_tokens: run.postStopTokens,
        session_id: run.sessionId,
        state: value.state,
        sequence: value.sequence,
        ...(value.stop_requested_at
            ? { stop_requested_at: value.stop_requested_at }
            : {}),
        ...(value.terminal_at ? { terminal_at: value.terminal_at } : {}),
        ...(value.terminal_reason
            ? { terminal_reason: value.terminal_reason }
            : {}),
        ...(value.completion ? { completion: value.completion } : {}),
    };
}
