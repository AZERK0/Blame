import { createInitialTaskBriefing } from "./initial-task-briefing.js";
import { executeLocalFinishTask } from "./light-finish-service.js";
import { contextGeneration, LightWorkspace } from "./light-workspace.js";
import { SessionJournal } from "./session-journal.js";
import { storeWorkspaceAttachment } from "../development-attachments.js";
export const lightWorkspaceToolNames = [
    "search_code",
    "read_code",
    "edit_code",
    "run_task",
    "finish_task",
    "initial_task_briefing",
    "session_journal",
    "store_attachment",
];
export function lightToolContext(context) {
    if (!context)
        return {};
    return {
        ...(context.agentId ? { agentId: context.agentId } : {}),
        ...(context.conversationId
            ? { conversationId: context.conversationId }
            : {}),
        metadata: {
            ...context.metadata,
            contextGeneration: contextGeneration(context),
        },
        ...(context.sessionId ? { sessionId: context.sessionId } : {}),
        ...(context.toolCallId ? { toolCallId: context.toolCallId } : {}),
    };
}
export function managedLightWorkspaceExecutor(executor, execution) {
    if (!executor ||
        execution?.workspaceMode !== "local-container" ||
        execution.backendMode !== "remote")
        return undefined;
    return (request, signal) => executor({ ...request, execution }, signal);
}
export function localLightWorkspaceExecutor(workspaceRoot, taskContract) {
    const workspace = new LightWorkspace(workspaceRoot, {
        sessionId: taskContract?.session_id ?? "unscoped-session",
        taskContract,
    });
    return (request, signal) => executeWithWorkspace(workspace, request, signal);
}
export function executeLightWorkspaceRequest(request, signal) {
    return localLightWorkspaceExecutor(request.workspaceRoot, request.taskContract)(request, signal);
}
async function executeWithWorkspace(workspace, request, signal) {
    const context = agentContext(request.toolContext, signal);
    switch (request.tool) {
        case "search_code":
            return workspace.searchCode(request.input, signal);
        case "read_code":
            return workspace.readCode(request.input, context);
        case "edit_code":
            return workspace.editCode(request.input, context);
        case "run_task":
            return workspace.runTask(request.input, context);
        case "finish_task":
            return finishRequest(request, context);
        case "initial_task_briefing":
            return briefingRequest(request);
        case "store_attachment":
            return {
                status: "ok",
                data: {
                    path: await storeWorkspaceAttachment(request.workspaceRoot, request.input),
                },
            };
        case "session_journal": {
            const sessionId = request.toolContext?.sessionId;
            if (!sessionId)
                throw new Error("Session journal requires a session ID");
            await writeSessionJournal({
                workspaceRoot: request.workspaceRoot,
                sessionId,
                input: request.input,
            });
            return { status: "ok", data: {} };
        }
    }
}
export async function writeSessionJournal(options) {
    if (options.executor) {
        const result = await options.executor({
            tool: "session_journal",
            workspaceRoot: options.workspaceRoot,
            toolContext: { sessionId: options.sessionId },
            input: options.input,
        });
        if (result?.status !== "ok")
            throw new Error("Unable to write the remote session journal");
        return;
    }
    const journal = new SessionJournal(options.workspaceRoot, options.sessionId);
    await journal.hydrate();
    if (options.input.kind === "request")
        await journal.ingestUserRequest(options.input.id, options.input.text);
    else if (options.input.kind === "terminal")
        await journal.recordTerminal(options.input.state);
    else
        throw new Error("Unsupported session journal operation");
}
function finishRequest(request, context) {
    return executeLocalFinishTask({
        context,
        input: request.input,
        taskContract: request.taskContract,
        workspaceRoot: request.workspaceRoot,
    });
}
async function briefingRequest(request) {
    const briefing = await createInitialTaskBriefing({
        taskContract: request.taskContract,
        workspaceRoot: request.workspaceRoot,
    });
    return { status: "ok", data: { briefing } };
}
function agentContext(context, signal) {
    return { ...context, signal };
}
