import assert from "node:assert/strict";
import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
// The same controls can run against an immutable pre-change runtime.
const runtime = process.env.BLAME_GUIDANCE_RUNTIME;
export const { LightWorkspace } = await import(runtime ? `${runtime}/light-workspace.js` : "./light-workspace.js");
export const { LightFinishService } = await import(runtime ? `${runtime}/light-finish-service.js` : "./light-finish-service.js");
export const { observeCheck } = await import(runtime ? `${runtime}/check-observation.js` : "./check-observation.js");
export const { localLightWorkspaceExecutor } = await import(runtime ? `${runtime}/light-executor.js` : "./light-executor.js");
export async function fixture(files, run) {
    const root = await mkdtemp(join(tmpdir(), "light-agent-guidance-"));
    try {
        for (const [path, content] of Object.entries(files)) {
            await mkdir(join(root, path, ".."), { recursive: true });
            await writeFile(join(root, path), content);
        }
        await run(new LightWorkspace(root, { sessionId: "guidance" }), root);
    }
    finally {
        await rm(root, { recursive: true, force: true });
    }
}
export function data(result) {
    assert.equal(result.status, "ok", JSON.stringify(result));
    return result.data;
}
export const source = "export function calculate(n: number) { return n + 1; }\n";
export const project = {
    "original.ts": source,
    "consumer.ts": 'import { calculate as compute } from "./original.js";\nexport { calculate as publicName } from "./original.js";\nexport const value = compute(1);\n',
    "package.json": '{"type":"module"}',
    "tsconfig.json": JSON.stringify({ compilerOptions: { strict: true, noEmit: true, target: "ES2022", module: "NodeNext", moduleResolution: "NodeNext", types: [] }, include: ["*.ts"] }),
};
