import { dirname } from "node:path";
import { execa } from "execa";
import { redactSecuritySecrets } from "../security-secret-redaction.js";
import { resolvePackageManager, } from "./package-manager-runtime.js";
import { LightCommitService } from "./light-commit.js";
import { boundedDiagnostic } from "./light-diagnostic.js";
import { readTaskCatalog } from "./task-catalog.js";
import { workspaceCommandEnvironment } from "./workspace-command-environment.js";
export class LightDependencyService {
    commits;
    files;
    constructor(files) {
        this.files = files;
        this.commits = new LightCommitService(files);
    }
    mutate(input, signal) {
        return this.commits.exclusive(() => this.mutateLocked(input, signal));
    }
    async mutateLocked(input, signal) {
        const snapshot = await this.files.snapshot(signal);
        const manifest = manifestPath(this.files, input.packagePath);
        const file = await optionalFile(this.files, manifest);
        if (!file)
            return {
                status: "blocked",
                category: "input",
                message: `No Node manifest at ${manifest}. Use run_task with the native package manager for other ecosystems.`,
            };
        const manifestContent = file.content;
        const before = await snapshotDependencyFiles(this.files, snapshot);
        try {
            const effectiveInput = alignedDependencyInput(input, manifestContent);
            const execution = await this.execute(effectiveInput, manifest, snapshot, signal);
            if (execution.exitCode !== 0)
                return await this.rollbackFailure(before, execution.output);
            const changedPaths = await changedDependencyPaths(this.files, before);
            return { status: "applied", changedPaths, output: execution.output };
        }
        catch (error) {
            return this.rollbackFailure(before, errorMessage(error));
        }
    }
    async execute(input, manifest, snapshot, signal) {
        const manager = await projectPackageManager(this.files, snapshot);
        const resolved = await resolvePackageManager({
            name: manager.name,
            version: manager.version,
            compatibility: manager.name === "pnpm" ? "pnpm_same_major" : undefined,
        });
        const args = [
            ...resolved.argsPrefix,
            ...dependencyArguments(manager.name, input),
        ];
        const result = await execa(resolved.executable, args, {
            all: true,
            cancelSignal: signal,
            cwd: dirname(this.files.resolveForWrite(manifest).absolute),
            env: workspaceCommandEnvironment(),
            extendEnv: false,
            maxBuffer: 512 * 1024,
            reject: false,
            stdin: "ignore",
            timeout: 120_000,
        });
        return { exitCode: result.exitCode, output: processOutput(result) };
    }
    async rollbackFailure(before, diagnostic) {
        await this.commits.restoreFiles(before);
        return {
            status: "blocked",
            category: dependencyFailureCategory(diagnostic),
            message: boundedDiagnostic(diagnostic, "Dependency mutation failed."),
        };
    }
}
async function projectPackageManager(files, snapshot) {
    const task = (await readTaskCatalog(files.root, snapshot.files)).find(({ kind }) => kind === "dependencies");
    if (!task)
        throw new Error("No package manager was detected.");
    return {
        name: task.package_manager,
        version: task.package_manager_version,
    };
}
function dependencyArguments(manager, input) {
    const packages = input.action === "remove"
        ? input.packages.map(packageName)
        : input.packages;
    if (manager === "npm")
        return [input.action === "add" ? "install" : "uninstall", ...packages];
    return [input.action, ...packages];
}
function alignedDependencyInput(input, manifest) {
    if (input.action !== "add")
        return input;
    try {
        const value = JSON.parse(manifest.toString("utf8"));
        return {
            ...input,
            packages: alignDependencyPackages(input.packages, value),
        };
    }
    catch {
        return input;
    }
}
export function alignDependencyPackages(packages, manifest) {
    const version = prismaFamilyVersion(manifest);
    if (!version)
        return packages;
    return packages.map((value) => prismaFamilyPackage(value) && !explicitPackageVersion(value)
        ? `${value}@${version}`
        : value);
}
function prismaFamilyVersion(manifest) {
    const value = record(manifest);
    for (const packageName of ["@prisma/client", "prisma"])
        for (const section of dependencyManifestSections) {
            const declared = record(value[section])[packageName];
            const version = semanticVersion(declared);
            if (version)
                return version;
        }
    return undefined;
}
function semanticVersion(value) {
    return typeof value === "string"
        ? value.match(/\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?/u)?.[0]
        : undefined;
}
function prismaFamilyPackage(value) {
    return value === "prisma" || value.startsWith("@prisma/");
}
function explicitPackageVersion(value) {
    return value.lastIndexOf("@") > 0;
}
export const dependencyManifestSections = [
    "dependencies",
    "devDependencies",
    "optionalDependencies",
    "peerDependencies",
];
function packageName(value) {
    const separator = value.lastIndexOf("@");
    return separator > 0 ? value.slice(0, separator) : value;
}
async function snapshotDependencyFiles(files, snapshot) {
    return Promise.all(dependencyPaths(snapshot.files).map(async (path) => {
        const file = await optionalFile(files, path);
        return {
            after: null,
            before: file?.content ?? null,
            mode: file?.mode,
            path,
        };
    }));
}
function dependencyPaths(paths) {
    const manifests = paths.filter((path) => path.endsWith("package.json"));
    const directories = new Set(manifests.map((path) => dirname(path)));
    const lockfiles = [
        "bun.lock",
        "bun.lockb",
        "package-lock.json",
        "pnpm-lock.yaml",
        "yarn.lock",
    ];
    return [
        ...new Set([
            ...manifests,
            ...[...directories].flatMap((directory) => lockfiles.map((file) => directory === "." ? file : `${directory}/${file}`)),
        ]),
    ].sort();
}
async function changedDependencyPaths(files, before) {
    const changed = [];
    for (const mutation of before) {
        const current = await optionalFile(files, mutation.path);
        if (!sameContent(mutation.before, current?.content ?? null))
            changed.push(mutation.path);
    }
    return changed;
}
function manifestPath(files, packagePath) {
    if (!packagePath)
        return "package.json";
    const normalized = files.normalizePath(packagePath);
    return normalized.endsWith("package.json")
        ? normalized
        : `${normalized.replace(/\/$/u, "")}/package.json`;
}
async function optionalFile(files, path) {
    try {
        return await files.read(path);
    }
    catch (error) {
        if (errorCode(error) === "ENOENT")
            return undefined;
        throw error;
    }
}
function sameContent(left, right) {
    if (left === null || right === null)
        return left === right;
    return left.equals(right);
}
function processOutput(result) {
    return redactSecuritySecrets((result.all ?? `${result.stdout}\n${result.stderr}`).trim());
}
function dependencyFailureCategory(diagnostic) {
    return /(?:EAI_AGAIN|ECONN|ENET|ENOENT|EACCES|permission|network|PACKAGE_MANAGER_UNAVAILABLE)/iu.test(diagnostic)
        ? "environment"
        : "code";
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
function errorCode(error) {
    return error && typeof error === "object" && "code" in error
        ? String(error.code)
        : undefined;
}
function record(value) {
    return value && typeof value === "object" && !Array.isArray(value)
        ? value
        : {};
}
