import { parseCode, symbolEditRange, syntaxBoundaryRange, } from "./code-intelligence.js";
import { validateContent, } from "./content-validation.js";
import { capabilityForPath, parseAvailability } from "./light-capabilities.js";
import { SymbolResolutionError, } from "./light-aliases.js";
import { planLightPatch, planScopedLightPatch, splitLightPatch } from "./light-patch.js";
import { LightCommitConflict, LightCommitService, } from "./light-commit.js";
import { symbolsTouchedByPatch } from "./patch-symbol-attribution.js";
import { sha256 } from "./light-identity.js";
import { planSemanticRename } from "./light-semantic-rename.js";
import { referenceFootprintIsCurrent } from "./semantic-reference-client.js";
import { pythonBodyRange, pythonBodyReplacement } from "./python-body.js";
export class LightEditService {
    aliases;
    commits;
    files;
    journal;
    receiptSequence = 0;
    constructor(aliases, options) {
        this.aliases = aliases;
        this.files = options.files;
        this.journal = options.journal;
        this.commits = new LightCommitService(options.files);
    }
    async edit(input, context = {}) {
        try {
            const snapshot = await this.files.snapshot(context.signal);
            const plans = await this.plan(input, snapshot, context.signal);
            return await this.applyPlans(plans, snapshot, context.signal);
        }
        catch (error) {
            return editFailure(error);
        }
    }
    async replaceFiles(replacements, context = {}) {
        try {
            if (!replacements.length || replacements.length > 50)
                throw new Error("Formatter batch must contain between 1 and 50 files.");
            const snapshot = await this.files.snapshot(context.signal);
            const plans = await this.replacementPlans(replacements);
            return await this.applyPlans(plans, snapshot, context.signal);
        }
        catch (error) {
            return editFailure(error);
        }
    }
    async replacementPlans(replacements) {
        const plans = [];
        for (const replacement of replacements) {
            const path = this.files.normalizePath(replacement.path);
            const plan = await this.filePlan(new Map(), path);
            if (!plan.initial)
                throw new Error(`${path} does not exist.`);
            if (!plan.initial.equals(replacement.before))
                throw new LightCommitConflict(`File changed before commit: ${path}.`);
            plan.replacements.push({
                start: 0,
                end: plan.initial.byteLength,
                replacement: replacement.content,
                source: `formatter ${path}`,
            });
            plans.push(plan);
        }
        return plans;
    }
    async applyPlans(plans, snapshot, signal) {
        const finalFiles = await this.finalize(plans);
        const footprint = plans.find((plan) => plan.footprint)?.footprint;
        if (footprint && !(await referenceFootprintIsCurrent(footprint, signal)))
            throw new LightCommitConflict("Semantic rename source or dependency changed before commit.");
        const invalid = finalFiles.find(({ parse }) => parse.status === "failed");
        if (invalid)
            return invalidParseResult(invalid);
        const result = await this.commit(finalFiles, snapshot, signal).catch(commitFailure);
        if (isLightFailure(result))
            return result;
        try {
            const mapped = await this.mapResult(result, finalFiles, snapshot);
            const rename = plans.find((plan) => plan.semanticRename)?.semanticRename;
            return rename && mapped.status === "ok" ? { ...mapped, data: {
                    ...mapped.data, semanticRename: {
                        ...rename, engine: "typescript_language_service", scope: "configured_project",
                        staticGuard: "no_new_diagnostics_in_changed_files",
                        guidance: "Applied the listed compiler-derived binding edits. An import/export's source-side name and namespace property follow the renamed declaration; explicit local/public alias spellings stay unchanged. Examples show individual identifier edits, not a complete diff. Inspect read_code @changes or the final diff before further edits; remaining textual homonyms/comments/literals need not be renamed. Static checks do not establish behavioral equivalence or satisfy required test/validation criteria; run required checks after editing.",
                    },
                } } : mapped;
        }
        catch (error) {
            return { status: "failed", category: "harness", applied: true,
                recovery: "recovery_required", paths: result.changedPaths,
                message: `Files were committed but the receipt could not be persisted. Do not replay this batch. ${errorMessage(error)}`,
                diagnosticId: `edit-${Date.now().toString(36)}` };
        }
    }
    async plan(input, snapshot, signal) {
        const rename = input.operations.find((operation) => operation.kind === "symbol" && operation.action === "rename");
        if (rename?.kind === "symbol") {
            if (input.operations.length !== 1)
                throw new Error("Semantic rename must be the only operation in a batch.");
            const derived = await planSemanticRename(this.aliases, this.files, snapshot, rename.target, rename.content, signal);
            const plans = new Map();
            for (const location of derived.reply.locations) {
                const file = await this.filePlan(plans, location.path, derived.sources.get(location.path));
                file.footprint = derived.reply.footprint;
                file.semanticRename = derived.receipt;
                if (file.path === derived.targetPath)
                    file.symbols.push(derived.oldQualifiedName, derived.newQualifiedName);
                file.replacements.push({ start: location.range[0], end: location.range[1],
                    replacement: location.replacement, source: `semantic rename ${rename.target}` });
            }
            for (const file of plans.values())
                file.symbols.push(...symbolsTouchedByPatch(file.path, file.initial, { mode: "update", replacements: file.replacements }));
            return [...plans.values()];
        }
        const files = new Map();
        let operationCount = 0;
        for (const operation of input.operations) {
            if (operation.kind === "patch") {
                if (operation.target) {
                    if (++operationCount > 50)
                        throw new Error("Edit batch contains too many operations.");
                    await this.planScopedPatch(files, operation, snapshot);
                    continue;
                }
                operationCount += await this.planPatch(files, operation.path, operation.patch, 50 - operationCount);
            }
            else {
                if (operationCount >= 50)
                    throw new Error("Edit batch contains too many operations.");
                operationCount += 1;
                await this.planSymbol(files, operation, snapshot);
            }
        }
        for (const file of files.values())
            assertCompatibleMutations(file);
        return [...files.values()];
    }
    async planPatch(plans, requestedPath, patch, remainingOperations) {
        const normalizedPatch = await this.normalizeNewFilePatch(plans, requestedPath, patch);
        const operations = splitLightPatch(normalizedPatch, requestedPath);
        if (operations.length > remainingOperations)
            throw new Error("Edit batch contains too many operations.");
        for (const operation of operations)
            await this.planPatchFile(plans, operation.path, operation.patch);
        return operations.length;
    }
    async planScopedPatch(plans, operation, snapshot) {
        if (!this.aliases.get(operation.target))
            throw new SymbolResolutionError("A scoped patch requires an observed symbol alias.");
        const resolved = await this.aliases.resolveSymbol(operation.target, this.files, snapshot.revision.source_revision_id, true);
        try {
            await this.planResolvedScopedPatch(plans, operation, resolved);
        }
        catch (error) {
            throw new ScopedEditRecovery(errorMessage(error), resolved, error instanceof ScopedPatchShapeError ? error.correction : undefined);
        }
    }
    async planResolvedScopedPatch(plans, operation, resolved) {
        const sections = splitLightPatch(operation.patch);
        if (sections.length !== 1 || this.files.normalizePath(sections[0].path) !== resolved.path ||
            (operation.path && this.files.normalizePath(operation.path) !== resolved.path))
            throw new ScopedPatchShapeError(resolved.path, sections.map(({ path }) => path), operation.path);
        const [start, end] = resolved.symbol.range_utf8_bytes;
        const source = resolved.content.subarray(start, end).toString("utf8");
        const replacements = planScopedLightPatch(source, sections[0].patch, resolved.path);
        const file = await this.filePlan(plans, resolved.path, resolved.content);
        file.symbols.push(resolved.symbol.qualified_name);
        for (const replacement of replacements) {
            this.aliases.assertObserved(resolved.alias, [replacement.start, replacement.end]);
            if (replacement.start === replacement.end &&
                (replacement.start === 0 || replacement.end === end - start))
                throw new Error("Use insert_before or insert_after for a symbol boundary insertion.");
            file.replacements.push({ ...replacement, start: start + replacement.start,
                end: start + replacement.end, source: `patch ${resolved.alias}` });
        }
        let scoped = resolved.content.subarray(start, end);
        for (const replacement of [...replacements].reverse())
            scoped = Buffer.concat([scoped.subarray(0, replacement.start), Buffer.from(replacement.replacement), scoped.subarray(replacement.end)]);
        const candidate = Buffer.concat([resolved.content.subarray(0, start), scoped, resolved.content.subarray(end)]);
        const boundary = parseCode(resolved.path, candidate).symbols.filter((symbol) => symbol.kind === resolved.symbol.kind && symbol.range_utf8_bytes[0] === start &&
            symbol.range_utf8_bytes[1] === start + scoped.length);
        if (boundary.length !== 1)
            throw new SymbolResolutionError("Scoped patch changes a declaration boundary; use an explicit symbol action.");
    }
    async normalizeNewFilePatch(plans, requestedPath, patch) {
        if (!requestedPath || hasClinePatchEnvelope(patch))
            return patch;
        const path = this.files.normalizePath(requestedPath);
        if (plans.has(path) || (await optionalFile(this.files, path)))
            return patch;
        return completeNewFilePatch(path, patch);
    }
    async planPatchFile(plans, requestedPath, patch) {
        const path = this.files.normalizePath(requestedPath);
        const file = await this.filePlan(plans, path);
        const source = file.initial?.toString("utf8");
        const patchPlan = await planLightPatch(this.files.root, path, source, patch);
        file.symbols.push(...symbolsTouchedByPatch(path, file.initial, patchPlan));
        applyPatchPlan(file, path, patchPlan);
    }
    async planSymbol(plans, operation, snapshot) {
        const resolved = await this.aliases.resolveSymbol(operation.target, this.files, snapshot.revision.source_revision_id, true);
        assertSymbolEditAvailable(resolved.path);
        if (["replace", "replace_body", "delete"].includes(operation.action)) {
            const range = operation.action === "replace_body"
                ? symbolEditRange(resolved.symbol, "body") : resolved.symbol.range_utf8_bytes;
            this.aliases.assertObserved(resolved.alias, [range[0] - resolved.symbol.range_utf8_bytes[0],
                range[1] - resolved.symbol.range_utf8_bytes[0]]);
        }
        const file = await this.filePlan(plans, resolved.path, resolved.content);
        file.symbols.push(resolved.symbol.qualified_name);
        file.replacements.push(symbolReplacement(resolved, operation));
    }
    async filePlan(plans, path, knownContent) {
        const existing = plans.get(path);
        if (existing)
            return existing;
        const file = await optionalFile(this.files, path);
        const initial = knownContent ?? file?.content ?? null;
        const plan = {
            initial,
            path,
            replacements: [],
            symbols: [],
            ...(file ? { fileMode: file.mode } : {}),
        };
        plans.set(path, plan);
        return plan;
    }
    async finalize(plans) {
        return Promise.all(plans.map(async (plan) => {
            const content = applyPlan(plan);
            const parse = await finalParseStatus(this.files.root, plan.path, plan.initial, content);
            return { ...plan, content, parse };
        }));
    }
    commit(files, snapshot, signal) {
        return this.commits.commit(files.map((file) => ({
            after: file.content,
            before: file.initial,
            mode: file.fileMode,
            path: file.path,
        })), snapshot.revision.source_revision_id, signal);
    }
    async mapResult(result, files, snapshot) {
        if (!result.changedPaths.length)
            return {
                status: "ok",
                data: { changed: false, parse: parseSummary(files) },
            };
        return this.appliedResult(files, snapshot, result);
    }
    async appliedResult(files, snapshot, result) {
        const receipt = `c${++this.receiptSequence}`;
        const paths = result.changedPaths;
        const parse = parseSummary(files);
        await this.journal.recordChange({
            beforeFiles: files.map((file) => ({
                path: file.path,
                hash: file.initial ? sha256(file.initial) : "absent",
            })),
            paths,
            receipt,
            sourceRevisionId: result.sourceRevisionId,
            symbols: [...new Set(files.flatMap(({ symbols }) => symbols))],
            parse: parse.status === "passed" ? "passed" : "not_supported",
        });
        const aliases = await this.refreshAliases(paths, new Set(files.flatMap(({ symbols }) => symbols)));
        await this.journal.recordAliases(this.aliases.entries());
        return appliedEditResult(receipt, result.sourceRevisionId, files, aliases, parse, snapshot);
    }
    async refreshAliases(paths, touched) {
        const snapshot = await this.files.snapshot();
        const existing = this.aliases.entries();
        const output = [];
        for (const path of paths) {
            const content = (await optionalFile(this.files, path))?.content;
            if (!content)
                continue;
            const symbols = parseCode(path, content).symbols;
            for (const symbol of symbols) {
                const aliases = matchingAliases(existing, path, symbol);
                if (!aliases.length && !touched.has(symbol.qualified_name))
                    continue;
                const previouslyComplete = aliases.some((entry) => {
                    if (entry.kind !== "symbol")
                        return false;
                    try {
                        this.aliases.assertObserved(entry.alias, [0, entry.end - entry.start]);
                        return true;
                    }
                    catch {
                        return false;
                    }
                });
                const { alias } = this.aliases.registerSymbol(path, content, symbol, snapshot.revision.source_revision_id);
                if (previouslyComplete && touched.has(symbol.qualified_name))
                    this.aliases.observe(path, content, [symbol.range_utf8_bytes]);
                if (touched.has(symbol.qualified_name))
                    output.push({ alias, path, qualifiedName: symbol.qualified_name });
            }
        }
        return uniqueAliasReceipts(output);
    }
}
function matchingAliases(aliases, path, symbol) {
    return aliases.filter((entry) => entry.kind === "symbol" &&
        entry.path === path &&
        entry.qualifiedName === symbol.qualified_name &&
        entry.symbolKind === symbol.kind);
}
function uniqueAliasReceipts(aliases) {
    const seen = new Set();
    return aliases.filter(({ alias }) => {
        if (seen.has(alias))
            return false;
        seen.add(alias);
        return true;
    });
}
function applyPatchPlan(file, path, patch) {
    if (patch.mode === "add") {
        if (file.initial && file.mutation === "delete")
            return replaceDeletedFile(file, path, patch.content);
        if (file.initial)
            throw new Error(`${path} already exists.`);
        file.mutation = "add";
        file.replacements.push({
            start: 0,
            end: 0,
            replacement: patch.content,
            source: `add ${path}`,
        });
        return;
    }
    if (patch.mode === "delete") {
        if (!file.initial)
            throw new Error(`${path} does not exist.`);
        file.mutation = "delete";
        return;
    }
    file.replacements.push(...patch.replacements.map((replacement) => ({
        ...replacement,
        source: `patch ${path}`,
    })));
}
function replaceDeletedFile(file, path, content) {
    if (file.replacements.length)
        throw new Error(`File replacement cannot overlap another edit in ${path}.`);
    file.mutation = undefined;
    file.replacements.push({
        start: 0,
        end: file.initial.length,
        replacement: content,
        source: `replace ${path}`,
    });
}
function appliedEditResult(receipt, sourceRevisionId, files, aliases, parse, snapshot) {
    return {
        status: "ok",
        receipt,
        data: {
            changed: true,
            changes: files.map(fileChange),
            ...(aliases.length ? { aliases } : {}),
            parse,
            basedOn: snapshot.git ? "worktree" : "filesystem",
            sourceRevisionId,
        },
    };
}
function symbolReplacement(resolved, operation) {
    if (operation.action === "rename")
        throw new Error("Semantic rename requires the compiler planner.");
    const replacement = operation.content ?? "";
    const source = `${operation.action} ${operation.target}`;
    if (operation.action === "replace_body")
        return symbolBodyReplacement(resolved, replacement, source);
    const range = syntaxBoundaryRange(resolved.path, resolved.content, resolved.symbol.range_utf8_bytes);
    if (operation.action === "insert_before")
        return insertionReplacement(range[0], replacement, source);
    if (operation.action === "insert_after")
        return insertionReplacement(range[1], replacement, source);
    return wholeSymbolReplacement(operation, range, source, resolved);
}
function symbolBodyReplacement(resolved, replacement, source) {
    const range = symbolEditRange(resolved.symbol, "body");
    if (capabilityForPath(resolved.path)?.language === "python") {
        const [start, end] = pythonBodyRange(resolved.content, range);
        return {
            start, end, source,
            replacement: pythonBodyReplacement(resolved.content, [start, end], replacement),
        };
    }
    const [start, end] = range;
    const current = resolved.content.subarray(start, end).toString("utf8");
    const baseIndent = lineIndentBefore(resolved.content, start);
    return {
        start,
        end,
        replacement: normalizedSymbolBody(current, replacement, baseIndent),
        source,
    };
}
function normalizedSymbolBody(current, replacement, baseIndent) {
    const currentBody = current.trim();
    const proposedBody = replacement.trim();
    if (!isDelimitedBody(currentBody) || isDelimitedBody(proposedBody))
        return replacement;
    if (!proposedBody.includes("\n"))
        return `{ ${proposedBody} }`;
    const indent = existingBodyIndent(current) ?? `${baseIndent}  `;
    return `{\n${indentedStatements(replacement, indent)}\n${baseIndent}}`;
}
function isDelimitedBody(value) {
    return value.startsWith("{") && value.endsWith("}");
}
function lineIndentBefore(content, offset) {
    const prefix = content.subarray(0, offset).toString("utf8");
    return prefix.match(/(?:^|\n)([\t ]*)[^\n]*$/u)?.[1] ?? "";
}
function existingBodyIndent(body) {
    return body.match(/\n([\t ]+)\S/u)?.[1];
}
function indentedStatements(value, indent) {
    const allLines = value.split(/\r?\n/u);
    const start = allLines.findIndex((line) => line.trim());
    const trailing = [...allLines].reverse().findIndex((line) => line.trim());
    const end = allLines.length - trailing - 1;
    const lines = allLines.slice(start, end + 1);
    const widths = lines
        .filter((line) => line.trim())
        .map((line) => line.match(/^[\t ]*/u)?.[0].length ?? 0);
    const width = Math.min(...widths);
    return lines
        .map((line) => (line.trim() ? `${indent}${line.slice(width)}` : ""))
        .join("\n");
}
function insertionReplacement(offset, replacement, source) {
    return { start: offset, end: offset, replacement, source };
}
function wholeSymbolReplacement(operation, range, source, resolved) {
    return {
        start: range[0],
        end: range[1],
        replacement: operation.action === "delete" ? "" :
            withoutRepeatedFirstLineIndent(resolved, range[0], operation.content ?? ""),
        source,
    };
}
function withoutRepeatedFirstLineIndent(resolved, start, replacement) {
    const language = capabilityForPath(resolved.path)?.language;
    if (!["javascript", "typescript", "jsx", "tsx"].includes(language ?? ""))
        return replacement;
    if (start === 0)
        return replacement;
    const lineStart = resolved.content.lastIndexOf(10, start - 1) + 1;
    const prefix = resolved.content.subarray(lineStart, start).toString("utf8");
    // The AST span starts after this whitespace, which remains in the file.
    // Accept the same absolute first-line indent once. Never reindent later
    // lines: they may contain template literals or explicitly chosen layout.
    return /^[\t ]+$/u.test(prefix) && replacement.startsWith(prefix)
        ? replacement.slice(prefix.length) : replacement;
}
function assertSymbolEditAvailable(path) {
    const capability = capabilityForPath(path);
    if (capability?.loaded && capability.level !== "raw")
        return;
    throw new SymbolResolutionError(`Symbol editing is unavailable for ${path}.`);
}
function hasClinePatchEnvelope(patch) {
    return /^\s*\*\*\* (?:Begin Patch|Add File:|Delete File:|Update File:)/u.test(patch);
}
function completeNewFilePatch(path, content) {
    const addedLines = content
        .replaceAll("\r\n", "\n")
        .split("\n")
        .map((line) => `+${line}`);
    return [
        "*** Begin Patch",
        `*** Add File: ${path}`,
        ...addedLines,
        "*** End Patch",
    ].join("\n");
}
async function optionalFile(files, path) {
    try {
        return await files.read(path);
    }
    catch (error) {
        if (errorCode(error) === "ENOENT")
            return null;
        throw error;
    }
}
function assertCompatibleMutations(file) {
    if (file.mutation && file.replacements.length > 1)
        throw new Error(`File creation or deletion cannot overlap another edit in ${file.path}.`);
    const ordered = [...file.replacements].sort((left, right) => left.start - right.start || right.end - left.end);
    for (let index = 1; index < ordered.length; index += 1) {
        const previous = ordered[index - 1];
        const current = ordered[index];
        if (replacementsOverlap(previous, current))
            throw new Error(`Edit operations overlap in ${file.path}: ${previous.source} conflicts with ${current.source}. Replace their common parent once, or split the edits and re-read after the first commit.`);
    }
}
function replacementsOverlap(left, right) {
    if (isInsertion(left) && isInsertion(right))
        return left.start === right.start;
    if (isInsertion(left))
        return insertionInside(left.start, right);
    if (isInsertion(right))
        return insertionInside(right.start, left);
    return left.start < right.end && right.start < left.end;
}
function isInsertion(replacement) {
    return replacement.start === replacement.end;
}
function insertionInside(offset, replacement) {
    return offset > replacement.start && offset < replacement.end;
}
function applyPlan(plan) {
    if (plan.mutation === "delete")
        return null;
    let content = plan.initial ?? Buffer.alloc(0);
    const descending = [...plan.replacements].sort((left, right) => right.start - left.start || right.end - left.end);
    for (const replacement of descending)
        content = Buffer.concat([
            content.subarray(0, replacement.start),
            Buffer.from(replacement.replacement),
            content.subarray(replacement.end),
        ]);
    return content;
}
async function finalParseStatus(workspaceRoot, path, before, after) {
    if (!after)
        return { diagnostics: [], status: "unsupported" };
    const validation = await validateFinalContent(workspaceRoot, path, after);
    if (validation.status === "passed")
        return { diagnostics: [], status: "passed" };
    if (validation.status === "unsupported")
        return {
            diagnostics: validation.diagnostics,
            status: unsupportedStatus(path),
        };
    return {
        diagnostics: validation.diagnostics,
        status: await failedOrDegraded(workspaceRoot, path, before, after, validation),
    };
}
function unsupportedStatus(path) {
    return parseAvailability(path) === "unavailable"
        ? "unavailable"
        : "unsupported";
}
async function failedOrDegraded(workspaceRoot, path, before, after, validation) {
    if (!before || validation.status !== "failed")
        return "failed";
    const previousValidation = await validateFinalContent(workspaceRoot, path, before);
    if (previousValidation.status !== "failed")
        return "failed";
    const previous = parseCode(path, before);
    const current = parseCode(path, after);
    const errorsDidNotIncrease = current.errorCount <= previous.errorCount &&
        validation.diagnostics.length <= previousValidation.diagnostics.length;
    return previous.supported && errorsDidNotIncrease
        ? "degraded_preexisting_errors"
        : "failed";
}
function validateFinalContent(workspaceRoot, path, content) {
    return validateContent({
        content,
        externalValidation: path.endsWith(".prisma") ? "unsupported" : "enabled",
        path,
        workspaceRoot,
    });
}
function invalidParseResult(file) {
    const diagnostic = file.parse.diagnostics[0];
    return {
        status: "blocked",
        category: "code",
        message: `Final parse failed for ${file.path}; no files were written.${diagnostic ? ` ${diagnostic}` : ""}`,
        recovery: "Correct the final syntax and submit one new atomic batch.",
    };
}
function editFailure(error) {
    const diagnosticId = `edit-${Date.now().toString(36)}`;
    if (error instanceof ScopedEditRecovery)
        return { status: "blocked", category: "input", message: error.message,
            recovery: error.recovery, diagnosticId };
    if (error instanceof SymbolResolutionError) {
        const recovery = error.candidates.length
            ? JSON.stringify(error.candidates)
            : patchFailureRecovery(error.message);
        return {
            status: "blocked",
            category: "input",
            message: error.message,
            ...(recovery ? { recovery } : {}),
            diagnosticId,
        };
    }
    const message = errorMessage(error);
    const recovery = patchFailureRecovery(message);
    return {
        status: "blocked",
        category: "input",
        message,
        ...(recovery ? { recovery } : {}),
        diagnosticId,
    };
}
class ScopedPatchShapeError extends Error {
    correction;
    constructor(expectedPath, patchPaths, suppliedPath) {
        super("Scoped patch header must match the symbol's file and contain one Update File.");
        const repeatedHeaders = patchPaths.length > 1 && new Set(patchPaths).size === 1;
        this.correction = {
            reason: repeatedHeaders ? "multiple_headers_for_symbol"
                : patchPaths.length !== 1 ? "multiple_files_for_symbol" : "wrong_file_for_symbol",
            expectedPath, patchPaths: patchPaths.slice(0, 8), patchPathCount: patchPaths.length,
            ...(suppliedPath ? { suppliedPath } : {}),
            symbolRoute: "Keep target and use one operation per observed symbol, each with one matching Update File. Split unrelated file changes into separate operations in the same atomic batch.",
            fileRoute: "Review and read all intended file changes first. For a deliberate file patch, omit target; explicit file headers select the files. This changes the scope of your request and is never done automatically. Exact preimages and atomic batch guards still apply.",
        };
    }
}
class ScopedEditRecovery extends Error {
    recovery;
    constructor(message, resolved, patchCorrection) {
        super(message);
        const [startLine, endLine] = resolved.symbol.line_range;
        this.recovery = "No operations in this batch were applied. Every operation uses the original source, not earlier operations in the same batch. " +
            (patchFailureRecovery(message) ? `${patchFailureRecovery(message)} ` : "") +
            JSON.stringify({ target: resolved.alias, path: resolved.path,
                ...(patchCorrection ? { patchCorrection } : {}),
                declarationLines: [startLine, endLine],
                nextRead: { target: resolved.path, view: "range",
                    range: { startLine: Math.max(1, startLine - 3), endLine: Math.min(endLine + 2, startLine + 24) } },
                routes: "Read the current text before retrying. For changes inside the declaration, read the symbol then use a symbol action or a focused alias patch. For JSDoc, export wrappers or context outside it, read those lines and use a file patch. For dependent edits, commit separately and read again. These locations are hints, not observed edit coverage; refresh after source changes." });
    }
}
function patchFailureRecovery(message) {
    if (/context is ambiguous/iu.test(message))
        return "Do not resend the same patch. Read the affected outline and target its symbol or selector alias, or add one short unique context line.";
    if (/context does not match/iu.test(message))
        return "Read only the affected symbol or short range, then submit a focused patch against the current text.";
    if (/too many (?:files|operations)/iu.test(message))
        return "Split the change into smaller atomic batches without repeating completed files.";
    return undefined;
}
function commitFailure(error) {
    if (error instanceof LightCommitConflict)
        return {
            status: "blocked",
            category: "input",
            message: error.message,
            diagnosticId: `edit-${Date.now().toString(36)}`,
        };
    return {
        status: "failed",
        category: "harness",
        recovery: "recovery_required",
        message: errorMessage(error),
        diagnosticId: `edit-${Date.now().toString(36)}`,
    };
}
function isLightFailure(value) {
    return "status" in value;
}
function parseSummary(files) {
    const statuses = files.map(({ parse }) => parse.status);
    const priority = [
        "failed",
        "unavailable",
        "degraded_preexisting_errors",
        "unsupported",
        "passed",
    ];
    return {
        status: priority.find((status) => statuses.includes(status)) ?? "unsupported",
        files: files.map(({ path, parse }) => ({
            path,
            status: parse.status,
            ...(parse.diagnostics.length ? { diagnostics: parse.diagnostics } : {}),
        })),
    };
}
function fileChange(file) {
    const before = sourceLines(file.initial?.toString("utf8") ?? "");
    const after = sourceLines(file.content?.toString("utf8") ?? "");
    const common = commonLineCount(before, after);
    return {
        path: file.path,
        additions: after.length - common,
        deletions: before.length - common,
        ...(file.symbols.length ? { symbols: [...new Set(file.symbols)] } : {}),
    };
}
function commonLineCount(left, right) {
    const rightCounts = new Map();
    for (const line of right)
        rightCounts.set(line, (rightCounts.get(line) ?? 0) + 1);
    let count = 0;
    for (const line of left) {
        const available = rightCounts.get(line) ?? 0;
        if (!available)
            continue;
        count += 1;
        rightCounts.set(line, available - 1);
    }
    return count;
}
function sourceLines(value) {
    if (!value)
        return [];
    const lines = value.split("\n");
    if (lines.at(-1) === "")
        lines.pop();
    return lines;
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
function errorCode(error) {
    return error && typeof error === "object" && "code" in error
        ? String(error.code)
        : undefined;
}
