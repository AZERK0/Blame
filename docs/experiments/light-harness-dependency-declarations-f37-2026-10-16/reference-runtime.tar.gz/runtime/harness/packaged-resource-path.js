export function packagedResourcePath(path) {
    return path.replace(/([\\/])app\.asar([\\/])/u, "$1app.asar.unpacked$2");
}
