import { createTool } from "@cline/sdk";
import { finishTaskInputSchema } from "./light-contracts.js";
export const lightCompletionToolName = "finish_task";
export function createLightCompletionTool(submit) {
    return createTool({
        name: lightCompletionToolName,
        description: "Finish with a concise factual summary. Use run_task reporting or read_code @checks for test counts: null is unknown, pending is distinct from skipped, and unreported categories must not become zero. Separate commands run, passing tests, admitted verification and user criteria. Mention a non-obvious durable implementation decision only when it helps future work. The runtime checks known changes, reuses current checks, and refreshes relevant checks already requested in this session. Work without a current check is reported as unverified. Do not provide receipts or internal state.",
        inputSchema: finishTaskInputSchema,
        lifecycle: { completesRun: true },
        retryable: false,
        maxRetries: 0,
        execute(input, context) {
            const parsed = finishTaskInputSchema.parse(input);
            return submit(parsed.summary, context);
        },
    });
}
