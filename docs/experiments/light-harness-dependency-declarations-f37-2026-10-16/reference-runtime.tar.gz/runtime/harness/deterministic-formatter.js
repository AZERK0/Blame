import { relative, sep } from "node:path";
import { execa } from "execa";
import { redactSecuritySecrets } from "../security-secret-redaction.js";
import { boundedDiagnostic } from "./light-diagnostic.js";
import { workspaceCommandEnvironment } from "./workspace-command-environment.js";
export class DeterministicFormatterError extends Error {
    category;
    constructor(category, message) {
        super(message);
        this.category = category;
    }
}
export class DeterministicFormatter {
    files;
    constructor(files) {
        this.files = files;
    }
    request(command) {
        return formatterCommand(command);
    }
    recovery(command) {
        if (!/\bprettier\b[^\n]*\s--write(?:\s|$)/u.test(command))
            return undefined;
        return "This request combines or ambiguously scopes Prettier. Submit `pnpm exec prettier --write <explicit existing files>` alone; for npm projects use `npx --no-install prettier --write <explicit existing files>` or `npm exec --no -- prettier --write <explicit existing files>`. It will be applied as one atomic journaled edit.";
    }
    async format(request, cwd, signal) {
        const paths = await this.resolvePaths(request.paths, cwd);
        const replacements = [];
        for (const path of paths)
            replacements.push(await this.formatFile(request, path, cwd, signal));
        return replacements;
    }
    async resolvePaths(paths, cwd) {
        const localCwd = relative(this.files.root, cwd).split(sep).join("/");
        const normalized = paths.map((path) => this.files.normalizePath(localCwd ? `${localCwd}/${path}` : path));
        const unique = [...new Set(normalized)];
        if (unique.length !== paths.length)
            throw new DeterministicFormatterError("input", "Formatter file paths must be unique.");
        for (const path of unique) {
            const profile = await this.files.pathProfile(path).catch(() => undefined);
            if (!profile || profile.directory)
                throw new DeterministicFormatterError("input", `Formatter target ${path} must be an existing regular file.`);
            if (profile.size > 2_097_152)
                throw new DeterministicFormatterError("input", `Formatter target ${path} exceeds the 2 MiB atomic edit limit.`);
        }
        return unique;
    }
    async formatFile(request, path, cwd, signal) {
        const absolute = this.files.resolveForWrite(path).absolute;
        const before = (await this.files.read(path)).content;
        const result = await runFormatter(request, absolute, before, cwd, signal);
        if (result.exitCode !== 0)
            throw new DeterministicFormatterError("code", formatterFailure(result));
        if (Buffer.byteLength(result.stdout) > 2_097_152)
            throw new DeterministicFormatterError("code", `Formatted output for ${path} exceeds the 2 MiB atomic edit limit.`);
        return { path, before, content: result.stdout };
    }
}
async function runFormatter(request, path, input, cwd, signal) {
    // stdout becomes source text; package-manager progress must stay out of it.
    const args = request.executable === "pnpm"
        ? ["--reporter=silent", ...request.args]
        : request.args;
    return execa(request.executable, [...args, "--stdin-filepath", path], {
        cancelSignal: signal,
        cwd,
        env: workspaceCommandEnvironment(),
        extendEnv: false,
        input,
        reject: false,
        stripFinalNewline: false,
        timeout: 30_000,
        maxBuffer: 4 * 1024 * 1024,
    }).catch((error) => {
        throw new DeterministicFormatterError("environment", errorMessage(error));
    });
}
function formatterFailure(result) {
    return (boundedDiagnostic(redactSecuritySecrets(`${result.stdout}\n${result.stderr}`)).trim() || `Formatter exited with code ${result.exitCode}.`);
}
function formatterCommand(command) {
    if (/[;&|<>\n\r'"`]/u.test(command))
        return undefined;
    const tokens = command.trim().split(/\s+/u);
    const prefix = formatterPrefix(tokens);
    if (!prefix)
        return undefined;
    const values = tokens.slice(prefix.length);
    if (values.filter((value) => value === "--write").length !== 1)
        return undefined;
    const paths = values.filter((value) => value !== "--write");
    if (!paths.length || paths.length > 50 || paths.some(invalidPathToken))
        return undefined;
    return {
        executable: prefix[0],
        args: prefix.slice(1),
        paths,
    };
}
function formatterPrefix(tokens) {
    return formatterPrefixes.find((prefix) => tokens.length > prefix.length &&
        prefix.every((value, index) => tokens[index] === value));
}
function invalidPathToken(value) {
    return value.startsWith("-") || /[*?{}[\]]/u.test(value);
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
const formatterPrefixes = [
    ["npx", "--no-install", "prettier"],
    ["npm", "exec", "--no", "--", "prettier"],
    ["pnpm", "exec", "prettier"],
    ["pnpm", "prettier"],
    ["yarn", "prettier"],
    ["prettier"],
];
