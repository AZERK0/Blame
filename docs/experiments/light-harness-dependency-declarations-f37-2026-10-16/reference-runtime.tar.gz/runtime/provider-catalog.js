import { getAllProviders, getModelsForProvider } from "@cline/llms";
import { withSupplementalModels } from "@blame/model-catalog";
const externalCliProviderIds = new Set(["claude-code", "openai-codex-cli"]);
export async function listClineProviders() {
    const providers = await getAllProviders();
    const withModels = await Promise.all(providers
        .filter((provider) => isBaseRuntimeProvider(provider.id))
        .map((provider) => toBlameProvider(provider)));
    return withModels.filter((provider) => Object.keys(provider.models).length > 0);
}
export function isBaseRuntimeProvider(providerId) {
    return !externalCliProviderIds.has(providerId);
}
async function toBlameProvider(provider) {
    const models = await clineModels(provider.id);
    return {
        id: provider.id,
        name: provider.name,
        description: provider.description,
        baseUrl: provider.baseUrl,
        defaultModelId: provider.defaultModelId,
        capabilities: provider.capabilities,
        models: Object.fromEntries(Object.entries(models).map(([modelId, model]) => [
            modelId,
            toBlameModel(modelId, model),
        ])),
    };
}
function toBlameModel(modelId, model) {
    return {
        id: model.id ?? modelId,
        name: model.name ?? modelId,
        status: model.status,
        description: model.description,
        contextWindow: model.contextWindow,
        maxTokens: model.maxTokens,
        capabilities: model.capabilities,
        releaseDate: model.releaseDate,
        cost: {
            input: model.pricing?.input ?? null,
            output: model.pricing?.output ?? null,
            cacheRead: model.pricing?.cacheRead ?? null,
            cacheWrite: model.pricing?.cacheWrite ?? null,
        },
        variants: reasoningVariants(model),
    };
}
export async function clineModels(providerId) {
    return withSupplementalModels(providerId, await getModelsForProvider(providerId));
}
function reasoningVariants(model) {
    const effortOption = reasoningOptions(model).find((option) => option.type === "effort");
    if (effortOption?.values) {
        const variants = Object.fromEntries(effortOption.values.flatMap((value) => isSelectableReasoningEffort(value)
            ? [
                [
                    value,
                    value === "none"
                        ? { thinking: false }
                        : { reasoningEffort: value, thinking: true },
                ],
            ]
            : []));
        if (Object.keys(variants).length)
            return variants;
    }
    if (reasoningOptions(model).some((option) => option.type === "toggle" || option.type === "budget_tokens")) {
        return { enabled: { thinking: true } };
    }
    if (!model.capabilities?.includes("reasoning"))
        return undefined;
    return fallbackReasoningVariants;
}
function reasoningOptions(model) {
    return (model.reasoningOptions ?? []);
}
const fallbackReasoningVariants = {
    low: { reasoningEffort: "low", thinking: true },
    medium: { reasoningEffort: "medium", thinking: true },
    high: { reasoningEffort: "high", thinking: true },
    xhigh: { reasoningEffort: "xhigh", thinking: true },
};
function isSelectableReasoningEffort(value) {
    return (value === "none" ||
        value === "minimal" ||
        value === "low" ||
        value === "medium" ||
        value === "high" ||
        value === "xhigh" ||
        value === "max");
}
