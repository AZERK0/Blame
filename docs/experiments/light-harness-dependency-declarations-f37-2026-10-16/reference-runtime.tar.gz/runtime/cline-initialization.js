import { asRecord, errorMessage, stringValue } from "./cline-runtime-events.js";
import { appendProductionConfig } from "./production.js";
import { projectCodePracticesCorrectionPrompt, projectCodePracticesPrompt, projectCodePracticesResultSchema, resolveProjectCodePracticesResult, } from "./project-code-practices.js";
import { parseProjectInitializationRepairPayload, parseProjectInitializationRepairResult, projectInitializationRepairResultSchema, } from "./project-initialization-repair.js";
import { parseProjectInitializationPayload, parseProjectInitializationResult, projectInitializationCorrectionPrompt, projectInitializationPrompt, projectInitializationResultSchema, } from "./project-initialization.js";
import { loadPrompt } from "./prompt-loader.js";
import { reasoningConfig } from "./reasoning.js";
export function initializationConfig(input, credential, submitTool) {
    return appendProductionConfig({
        providerId: input.providerId,
        modelId: input.modelId,
        apiKey: credential.apiKey,
        baseUrl: credential.baseUrl ?? undefined,
        ...reasoningConfig(input.reasoningEffort),
        systemPrompt: loadPrompt("project-initialization-system"),
        cwd: input.cwd,
        workspaceRoot: input.workspaceRoot,
        enableTools: true,
        enableSpawnAgent: false,
        enableAgentTeams: false,
        extraTools: submitTool ? [submitTool] : undefined,
        maxIterations: 8,
    });
}
export function codePracticesConfig(input, credential, submitTool) {
    return appendProductionConfig({
        providerId: input.providerId,
        modelId: input.modelId,
        apiKey: credential.apiKey,
        baseUrl: credential.baseUrl ?? undefined,
        ...reasoningConfig(input.reasoningEffort),
        systemPrompt: loadPrompt("project-code-practices-system"),
        cwd: input.cwd,
        workspaceRoot: input.workspaceRoot,
        enableTools: true,
        enableSpawnAgent: false,
        enableAgentTeams: false,
        extraTools: [submitTool],
        maxIterations: 4,
    });
}
export function projectCodePracticesSubmitTool() {
    const submit = {
        input: undefined,
        tool: {
            name: "submit_project_code_practices",
            description: "Submit the complete project code practice analysis.",
            inputSchema: projectCodePracticesResultSchema,
            lifecycle: { completesRun: true },
            execute(input) {
                submit.input = input;
                return { accepted: true };
            },
        },
    };
    return submit;
}
export function projectInitializationSubmitTool() {
    const submit = {
        input: undefined,
        tool: {
            name: "submit_project_initialization",
            description: "Submit the complete Blame project initialization result for validation.",
            inputSchema: projectInitializationResultSchema,
            lifecycle: { completesRun: true },
            execute(input) {
                submit.input = input;
                return { accepted: true };
            },
        },
    };
    return submit;
}
export function projectInitializationRepairSubmitTool() {
    const submit = {
        input: undefined,
        tool: {
            name: "submit_project_initialization_repair",
            description: "Submit the complete project initialization diagnosis.",
            inputSchema: projectInitializationRepairResultSchema,
            lifecycle: { completesRun: true },
            execute(input) {
                submit.input = input;
                return { accepted: true };
            },
        },
    };
    return submit;
}
export function collectProjectInitializationRepairAttempt(session, submitTool) {
    const result = submitTool.input ??
        structuredResultInputFromResult(session.result, "submit_project_initialization_repair") ??
        session.result?.text;
    if (!result)
        throw new Error("Project initialization repair agent did not return a result");
    return { result, sessionId: session.sessionId };
}
export async function collectProjectInitializationAttempt(cline, session, submitTool) {
    const submittedInput = submitTool.input ??
        projectInitializationInputFromResult(session.result) ??
        (await projectInitializationInputFromMessages(cline, session.sessionId));
    const result = submittedInput ?? session.result?.text;
    if (!result)
        throw new Error("Project initialization agent did not return a result");
    return { result, sessionId: session.sessionId, submittedInput };
}
export function parseProjectInitializationAttempt(attempt, scan, input) {
    const initialization = attempt.submittedInput
        ? parseProjectInitializationPayload(attempt.submittedInput, scan, input.preferences)
        : parseProjectInitializationResult(String(attempt.result), scan, input.preferences);
    return {
        sessionId: attempt.sessionId,
        previewManifest: initialization.previewManifest,
        setupScript: initialization.setupScript,
        dockerCompose: initialization.dockerCompose,
        runConfigurations: initialization.runConfigurations,
    };
}
export function parsedCodePracticesAttempt(attempt, scan) {
    return {
        sessionId: attempt.sessionId,
        practices: resolveProjectCodePracticesResult(attempt.input, scan.commits),
    };
}
export function parseProjectInitializationRepairAttempt(attempt, scan, input) {
    const repair = typeof attempt.result === "string"
        ? parseProjectInitializationRepairResult(attempt.result, scan, input.preferences)
        : parseProjectInitializationRepairPayload(attempt.result, scan, input.preferences);
    return {
        sessionId: attempt.sessionId,
        ...repair,
    };
}
export function initializationCorrection(previousResult, error) {
    const serializedResult = typeof previousResult === "string"
        ? previousResult
        : JSON.stringify(previousResult);
    return {
        previousResult: serializedResult ?? String(previousResult),
        validationError: errorMessage(error),
    };
}
export function combinedTaskBriefing(initialTaskBriefing, projectMemoryBriefing) {
    const briefing = [initialTaskBriefing, projectMemoryBriefing]
        .filter((value) => Boolean(value))
        .join("\n");
    return briefing || undefined;
}
async function projectInitializationInputFromMessages(cline, sessionId) {
    try {
        return projectInitializationInputFromMessageList(await cline.readLiveMessages(sessionId));
    }
    catch {
        return undefined;
    }
}
function projectInitializationInputFromResult(result) {
    return structuredResultInputFromResult(result, "submit_project_initialization");
}
function structuredResultInputFromResult(result, toolName) {
    const payload = asRecord(result);
    const toolCalls = Array.isArray(payload.toolCalls) ? payload.toolCalls : [];
    for (const call of toolCalls) {
        const record = asRecord(call);
        if (record.name === toolName) {
            return record.input;
        }
    }
    return structuredResultInputFromMessageList(payload.messages, toolName);
}
function projectInitializationInputFromMessageList(value) {
    return structuredResultInputFromMessageList(value, "submit_project_initialization");
}
function structuredResultInputFromMessageList(value, toolName) {
    const messages = Array.isArray(value) ? value : asRecord(value).messages;
    if (!Array.isArray(messages))
        return undefined;
    for (const message of messages) {
        const content = asRecord(message).content;
        if (!Array.isArray(content))
            continue;
        for (const part of content) {
            const input = structuredResultInputFromMessagePart(part, toolName);
            if (input)
                return input;
        }
    }
    return undefined;
}
function structuredResultInputFromMessagePart(value, toolName) {
    const part = asRecord(value);
    const name = stringValue(part.name) ??
        stringValue(part.toolName) ??
        stringValue(asRecord(part.toolCall).name) ??
        stringValue(asRecord(part.toolCall).toolName);
    if (name !== toolName)
        return undefined;
    return part.input ?? asRecord(part.toolCall).input;
}
export function initializationPrompt(scan, correction, preferences) {
    if (!correction)
        return projectInitializationPrompt(scan, preferences);
    return projectInitializationCorrectionPrompt(scan, correction, preferences);
}
export function codePracticesPrompt(scan, correction) {
    if (!correction)
        return projectCodePracticesPrompt(scan);
    return projectCodePracticesCorrectionPrompt(scan, correction);
}
