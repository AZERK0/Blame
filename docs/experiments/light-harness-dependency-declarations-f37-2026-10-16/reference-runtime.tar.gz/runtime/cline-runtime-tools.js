import { randomUUID } from "node:crypto";
import { createDelegatedAgentConfigProvider, createSpawnAgentTool, } from "@cline/sdk";
import { productionLogger } from "./cline-runtime-configuration.js";
import { asRecord, stringValue } from "./cline-runtime-events.js";
import { blockedCommandParts } from "./cline-tool-policy.js";
import { createFinishTaskTool } from "./harness/finish-task.js";
import { lightReadToolNames, lightSemanticHarnessTools, } from "./harness/light-tools.js";
import { previewContainerLogsTool, previewDevtoolsTool, previewInitializationRepairTool, } from "./preview-harness-tools.js";
import { reasoningConfig } from "./reasoning.js";
import { createConsultSpecialistTool } from "./specialist-consult-tool.js";
import { supplementalModelConfig } from "./supplemental-model-config.js";
export function runtimeTools(options, worktree, previewContext, taskContract, executor, completion, previewMcpTools = [], initialTaskBriefing) {
    void initialTaskBriefing;
    const tools = [
        ...lightSemanticHarnessTools(worktree, {
            executor,
            taskContract,
            ...(options.refreshPreviewDependencies && previewContext
                ? {
                    refreshPreviewDependencies: () => Promise.resolve(options.refreshPreviewDependencies(previewContext)),
                }
                : {}),
        }),
        ...(completion
            ? [
                createFinishTaskTool({
                    conversationId: completion.conversationId,
                    executor,
                    taskContract,
                    workspaceRoot: worktree ?? "",
                    onComplete: completion.onComplete,
                    onValidationActivity: completion.onValidationActivity,
                }),
            ]
            : []),
        previewDevtoolsTool(options, previewContext),
        previewInitializationRepairTool(options, previewContext),
        previewContainerLogsTool(options, previewContext),
        ...previewMcpTools,
    ].filter((tool) => Boolean(tool));
    return tools.length ? tools : undefined;
}
export function readOnlyRuntimeTools(options, worktree, previewContext, taskContract, executor, initialTaskBriefing) {
    const allowedTools = new Set([
        ...lightReadToolNames,
        "get_preview_devtools",
        "get_preview_container_logs",
    ]);
    return (runtimeTools(options, worktree, previewContext, taskContract, executor, undefined, [], initialTaskBriefing) ?? []).filter((tool) => allowedTools.has(tool.name));
}
export function runtimeConsultSpecialistTool(options) {
    return createConsultSpecialistTool({
        capsule: specialistCapsuleProvider(options),
        objective: options.objective,
        spawnTool: specialistSpawnTool(options),
        storyId: options.input.storyId,
        timeoutMs: adaptiveSpecialistTimeoutMs(specialistReasoningEffort(options.input.reasoningEffort)),
    });
}
function specialistSpawnTool(options) {
    const configProvider = createDelegatedAgentConfigProvider(supplementalModelConfig({
        providerId: options.input.providerId,
        modelId: options.input.modelId,
        apiKey: options.credential.apiKey,
        baseUrl: options.credential.baseUrl ?? undefined,
        ...reasoningConfig(specialistReasoningEffort(options.input.reasoningEffort)),
        cwd: options.input.cwd,
        maxIterations: 16,
    }));
    const spawnTool = createSpawnAgentTool({
        configProvider,
        defaultMaxIterations: 16,
        subAgentTools: options.readOnlyTools,
        toolPolicies: Object.fromEntries(options.readOnlyTools.map((tool) => [
            tool.name,
            { enabled: true, autoApprove: true },
        ])),
        logger: productionLogger,
    });
    return spawnTool;
}
function specialistCapsuleProvider(options) {
    return async (consultation) => {
        const briefing = options.initialTaskBriefing
            ? `<runtime_task_briefing>\n${options.initialTaskBriefing}\n</runtime_task_briefing>`
            : undefined;
        const request = JSON.stringify({
            objective: options.objective,
            specialistTask: consultation.task,
        });
        return [`<specialist_request>${request}</specialist_request>`, briefing]
            .filter(Boolean)
            .join("\n\n");
    };
}
function specialistReasoningEffort(effort) {
    return effort === "xhigh" || effort === "max" ? "high" : effort;
}
function adaptiveSpecialistTimeoutMs(reasoningEffort) {
    const effort = String(reasoningEffort ?? "").toLowerCase();
    if (effort === "ultra")
        return 360_000;
    if (effort === "max")
        return 300_000;
    if (effort === "xhigh")
        return 240_000;
    if (effort === "high")
        return 180_000;
    if (effort === "medium")
        return 120_000;
    return 90_000;
}
export function toApprovalRequest(request, toolName) {
    return {
        id: randomUUID(),
        sessionId: request.sessionId,
        toolName,
        reason: request.reason,
        input: request.input,
    };
}
export function blockedToolReason(toolName, input) {
    if (toolName !== "run_commands")
        return undefined;
    const command = stringValue(asRecord(input).command);
    if (!command)
        return undefined;
    return blockedCommandParts.some((part) => command.includes(part))
        ? "Command blocked by security policy"
        : undefined;
}
