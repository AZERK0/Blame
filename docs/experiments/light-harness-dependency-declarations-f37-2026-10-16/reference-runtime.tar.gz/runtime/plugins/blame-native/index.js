const blameNativePlugin = {
    name: "blame-native",
    manifest: {
        capabilities: ["skills"],
    },
};
export default blameNativePlugin;
