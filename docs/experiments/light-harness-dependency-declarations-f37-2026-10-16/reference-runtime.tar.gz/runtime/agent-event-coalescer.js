const defaultDelayMs = 50;
export function createAgentEventCoalescer(callback, delayMs = defaultDelayMs) {
    let pending;
    let timer;
    const flush = () => {
        if (timer)
            clearTimeout(timer);
        timer = undefined;
        if (!pending)
            return;
        const event = pending;
        pending = undefined;
        callback(event);
    };
    return {
        push(event) {
            if (!coalescibleAgentEvent(event)) {
                flush();
                callback(event);
                return;
            }
            if (pending && !mergeableAgentEvents(pending, event))
                flush();
            pending = pending ? mergeAgentEvents(pending, event) : event;
            timer ??= setTimeout(flush, delayMs);
        },
        flush,
        close() {
            flush();
        },
    };
}
function mergeableAgentEvents(current, next) {
    const currentPayload = recordValue(current.payload);
    const nextPayload = recordValue(next.payload);
    return (current.type === next.type &&
        current.sessionId === next.sessionId &&
        current.executionId === next.executionId &&
        currentPayload.iteration === nextPayload.iteration);
}
function coalescibleAgentEvent(event) {
    return event.type === "text" || event.type === "reasoning";
}
function mergeAgentEvents(current, next) {
    const currentPayload = recordValue(current.payload);
    const nextPayload = recordValue(next.payload);
    if (currentPayload.iteration !== nextPayload.iteration)
        return next;
    const accumulatedText = stringValue(nextPayload.accumulatedText);
    const currentText = stringValue(currentPayload.accumulatedText) ??
        stringValue(currentPayload.text) ??
        "";
    const nextText = stringValue(nextPayload.text) ?? "";
    return {
        ...next,
        payload: {
            ...nextPayload,
            text: accumulatedText
                ? undefined
                : appendStreamingText(currentText, nextText),
            ...(accumulatedText ? { accumulatedText } : {}),
        },
    };
}
function appendStreamingText(current, next) {
    if (!current || next.startsWith(current))
        return next || current;
    return `${current}${next}`;
}
function recordValue(value) {
    return value && typeof value === "object"
        ? value
        : {};
}
function stringValue(value) {
    return typeof value === "string" ? value : undefined;
}
