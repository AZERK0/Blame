import { basename } from "node:path";
import { balancedGitMessages, discoverProjectFiles, isDatabaseEvidencePath, isMigrationEvidencePath, isProjectDocumentationPath, isProjectEntrypointPath, isProjectLockFilePath, isProjectManifestPath, isRuntimeEvidencePath, isSourceCodePath, isTestCodePath, preferNonGeneratedProjectPaths, readBoundedProjectFiles, recentProjectGitLogs, selectBalancedProjectPaths, topLevelProjectEntries, } from "./project-discovery.js";
export async function scanProjectForInitialization(root) {
    const discovery = await discoverProjectFiles(root);
    const candidates = initializationCandidates(discovery);
    const [files, gitLog] = await Promise.all([
        initializationEvidence(root, candidates),
        initializationGitLog(root, discovery.repositoryRoots),
    ]);
    return {
        rootName: basename(root),
        topLevelEntries: topLevelProjectEntries(discovery),
        files,
        gitLog,
        discovery: initializationDiscovery(discovery),
    };
}
function initializationCandidates(discovery) {
    const { files, projectRoots } = discovery;
    const entrypointPaths = balanced(files, projectRoots, isProjectEntrypointPath, 16);
    return {
        manifestPaths: balanced(files, projectRoots, isProjectManifestPath, 32),
        runtimePaths: balanced(files, projectRoots, isRuntimeEvidencePath, 24),
        entrypointPaths,
        documentationPaths: balanced(files, projectRoots, isProjectDocumentationPath, 4),
        sourcePaths: initializationSourcePaths(discovery, entrypointPaths),
        databaseConfigurationPaths: databaseConfigurationPaths(discovery),
    };
}
function balanced(files, roots, predicate, limit) {
    const matchingPaths = files.filter(predicate);
    const preferredPaths = preferNonGeneratedProjectPaths(matchingPaths, roots);
    return selectBalancedProjectPaths(preferredPaths, roots, limit);
}
function initializationSourcePaths(discovery, entrypointPaths) {
    const entrypoints = new Set(entrypointPaths);
    const paths = discovery.files.filter((path) => isSourceCodePath(path) && !isTestCodePath(path) && !entrypoints.has(path));
    const preferredPaths = preferNonGeneratedProjectPaths(paths, discovery.projectRoots);
    return selectBalancedProjectPaths(preferredPaths, discovery.projectRoots, 10);
}
function databaseConfigurationPaths(discovery) {
    const paths = discovery.files.filter((path) => isDatabaseEvidencePath(path) && isReadableDatabaseConfiguration(path));
    const preferredPaths = preferNonGeneratedProjectPaths(paths, discovery.projectRoots);
    return selectBalancedProjectPaths(preferredPaths, discovery.projectRoots, 6);
}
function isReadableDatabaseConfiguration(path) {
    const name = path.split("/").at(-1)?.toLowerCase() ?? "";
    return (name === "alembic.ini" ||
        name === "schema.prisma" ||
        /^(drizzle|prisma)\.config\.[a-z0-9]+$/.test(name));
}
async function initializationEvidence(root, candidates) {
    const evidence = await Promise.all([
        readBoundedProjectFiles(root, candidates.manifestPaths, 30_000, 5_000),
        readBoundedProjectFiles(root, candidates.runtimePaths, 14_000, 3_000),
        readBoundedProjectFiles(root, candidates.entrypointPaths, 8_000, 2_000),
        readBoundedProjectFiles(root, candidates.documentationPaths, 3_000, 2_000),
        readBoundedProjectFiles(root, candidates.sourcePaths, 8_000, 2_000),
        readBoundedProjectFiles(root, candidates.databaseConfigurationPaths, 3_000, 1_500),
    ]);
    return Object.assign({}, ...evidence);
}
async function initializationGitLog(root, repositories) {
    const logs = await recentProjectGitLogs(root, repositories, 12);
    return balancedGitMessages(logs, 12);
}
function initializationDiscovery(discovery) {
    return {
        scannedFileCount: discovery.files.length,
        scannedDirectoryCount: discovery.scannedDirectoryCount,
        ignoredDirectoryCount: discovery.ignoredDirectoryCount,
        truncated: discovery.truncated,
        projectRoots: discovery.projectRoots.slice(0, 120),
        repositoryRoots: discovery.repositoryRoots.slice(0, 60),
        ...initializationDiscoveryPaths(discovery),
    };
}
function initializationDiscoveryPaths(discovery) {
    const summarize = (predicate, limit) => discoveryPathSummary(discovery, predicate, limit);
    const manifests = summarize(isProjectManifestPath, 120);
    const locks = summarize(isProjectLockFilePath, 120);
    const runtime = summarize(isRuntimeEvidencePath, 120);
    const entrypoints = summarize(isProjectEntrypointPath, 120);
    const database = summarize(isNonMigrationDatabasePath, 80);
    const migrations = summarize(isMigrationEvidencePath, 80);
    return {
        manifestFileCount: manifests.count,
        manifestPaths: manifests.paths,
        lockFileCount: locks.count,
        lockFilePaths: locks.paths,
        runtimeEvidenceFileCount: runtime.count,
        runtimeEvidencePaths: runtime.paths,
        entrypointFileCount: entrypoints.count,
        entrypointPaths: entrypoints.paths,
        databaseFileCount: database.count,
        databasePaths: database.paths,
        migrationFileCount: migrations.count,
        migrationPaths: migrations.paths,
    };
}
function discoveryPathSummary(discovery, predicate, limit) {
    const paths = matchingPaths(discovery, predicate);
    return {
        count: paths.length,
        paths: selectBalancedProjectPaths(paths, discovery.projectRoots, limit),
    };
}
function matchingPaths(discovery, predicate) {
    const matches = discovery.files.filter(predicate);
    return preferNonGeneratedProjectPaths(matches, discovery.projectRoots);
}
function isNonMigrationDatabasePath(path) {
    return isDatabaseEvidencePath(path) && !isMigrationEvidencePath(path);
}
