export async function listProviders(connection) {
    const [catalog, credentials] = await Promise.all([
        request(connection, "/providers/catalog"),
        request(connection, "/providers/credentials"),
    ]);
    const credentialList = normalizeCredentials(credentials);
    const connected = Array.from(new Set(credentialList.map((credential) => credential.providerId)));
    return {
        ...catalog,
        connected,
        credentials: credentialList,
    };
}
export function saveProviderCredential(connection, input) {
    return request(connection, "/providers/credentials", {
        body: JSON.stringify(input),
        method: "POST",
    });
}
export function saveOAuthCredential(connection, input) {
    return request(connection, "/providers/credentials/oauth", {
        body: JSON.stringify(input),
        method: "POST",
    });
}
export function deleteProviderCredential(connection, input) {
    return request(connection, `/providers/credentials/${input.id}`, {
        method: "DELETE",
    });
}
export function resolveProviderCredential(connection, input) {
    return request(connection, "/providers/credentials/resolve", {
        body: JSON.stringify(input),
        method: "POST",
    });
}
export function listProjectMemories(connection, projectId) {
    return request(connection, `/projects/${encodeURIComponent(projectId)}/agent-memories`, { signal: AbortSignal.timeout(1_500) });
}
export function saveProjectMemory(connection, projectId, candidate) {
    return request(connection, `/projects/${encodeURIComponent(projectId)}/agent-memories`, {
        body: JSON.stringify(candidate),
        method: "POST",
        signal: AbortSignal.timeout(1_500),
    });
}
async function request(connection, path, init) {
    const headers = new Headers(init?.headers);
    headers.set("Accept", "application/json");
    headers.set("Content-Type", "application/json");
    const authorization = authorizationHeader(connection);
    if (authorization)
        headers.set("Authorization", authorization);
    const response = await fetch(`${connection.url.replace(/\/$/, "")}${path}`, {
        ...init,
        headers,
    });
    if (!response.ok)
        throw new Error(await responseMessage(response));
    if (response.status === 204)
        return undefined;
    const json = (await response.json());
    return transformerValue(responseData(json));
}
function authorizationHeader(connection) {
    if (!connection.token)
        return undefined;
    return `Bearer ${connection.token}`;
}
async function responseMessage(response) {
    try {
        const body = await response.json();
        if (typeof body.message === "string")
            return body.message;
        if (typeof body.error === "string")
            return body.error;
    }
    catch {
        return `Request failed with status ${response.status}`;
    }
    return `Request failed with status ${response.status}`;
}
function responseData(value) {
    if (isRecord(value) && "data" in value)
        return value.data;
    return value;
}
function transformerValue(value) {
    if (Array.isArray(value))
        return value.map(transformerValue);
    if (!isRecord(value))
        return value;
    if ("data" in value)
        return transformerValue(value.data);
    if (!Array.isArray(value.transformerData))
        return value;
    return transformerValue(value.transformerData[0]);
}
function normalizeCredentials(value) {
    if (!Array.isArray(value))
        return [];
    const credentials = [];
    for (const item of value) {
        const credential = normalizeCredential(item);
        if (credential)
            credentials.push(credential);
    }
    return credentials;
}
function normalizeCredential(value) {
    const credential = transformerValue(value);
    if (!isRecord(credential))
        return undefined;
    const normalized = {
        id: stringField(credential, "id"),
        userId: stringField(credential, "userId", "user_id"),
        providerId: stringField(credential, "providerId", "provider_id"),
        label: stringField(credential, "label"),
        authMethod: authMethodField(credential),
        baseUrl: nullableStringField(credential, "baseUrl", "base_url"),
        modelIds: stringArrayField(credential, "modelIds", "model_ids"),
        accountId: nullableStringField(credential, "accountId", "account_id"),
        expiresAt: nullableStringField(credential, "expiresAt", "expires_at"),
        createdAt: stringField(credential, "createdAt", "created_at"),
        updatedAt: nullableStringField(credential, "updatedAt", "updated_at"),
    };
    if (!normalized.id || !normalized.providerId)
        return undefined;
    return normalized;
}
function stringField(value, ...keys) {
    const field = firstField(value, keys);
    return typeof field === "string" ? field : "";
}
function stringArrayField(value, ...keys) {
    const field = firstField(value, keys);
    return Array.isArray(field)
        ? field.filter((item) => typeof item === "string")
        : [];
}
function nullableStringField(value, ...keys) {
    const field = firstField(value, keys);
    return typeof field === "string" ? field : null;
}
function authMethodField(value) {
    const field = stringField(value, "authMethod", "auth_method");
    return field === "oauth" ? "oauth" : "api-key";
}
function firstField(value, keys) {
    return keys.map((key) => value[key]).find((field) => field !== undefined);
}
function isRecord(value) {
    return !!value && typeof value === "object";
}
