import { projectImageContext } from "./image-context.js";
const harnessNames = new Set(["read_code", "search_code", "edit_code", "run_task"]);
const textKeys = new Set(["content", "body", "imports", "signature", "snippet", "output", "message"]);
export function presentToolResults(messages) {
    const names = new Map();
    const presented = messages.map((message) => {
        if (!Array.isArray(message.content))
            return message;
        const content = message.content.map((block) => {
            if (block.type === "tool_use")
                names.set(block.id, block.name);
            return presentBlock(block, names);
        });
        return { ...message, content };
    });
    return projectImageContext(presented);
}
function presentBlock(block, names) {
    if (block.type !== "tool_result" || typeof block.content !== "string")
        return block;
    if (!harnessNames.has(names.get(block.tool_use_id) ?? block.name ?? ""))
        return block;
    let result;
    try {
        result = JSON.parse(block.content);
    }
    catch {
        return block;
    }
    if (!result || typeof result !== "object" || !('status' in result))
        return block;
    const sections = [];
    const metadata = extractText(result, "", sections);
    if (!sections.length)
        return block;
    return { ...block, content: [JSON.stringify(metadata), ...sections].join("\n\n") };
}
function extractText(value, path, sections) {
    if (Array.isArray(value))
        return value.map((item, index) => extractText(item, `${path}[${index}]`, sections));
    if (!value || typeof value !== "object")
        return value;
    return Object.fromEntries(Object.entries(value).flatMap(([key, item]) => {
        const field = path ? `${path}.${key}` : key;
        if (textKeys.has(key) && typeof item === "string" && /[\\\n\r\t"]/u.test(item)) {
            sections.push(textSection(field, item));
            return [];
        }
        return [[key, extractText(item, field, sections)]];
    }));
}
function textSection(field, source) {
    const runs = source.match(/`+/gu) ?? [];
    const length = runs.reduce((maximum, run) => Math.max(maximum, run.length + 1), 3);
    const fence = "`".repeat(length);
    return `${field}:\n${fence}\n${source}\n${fence}`;
}
