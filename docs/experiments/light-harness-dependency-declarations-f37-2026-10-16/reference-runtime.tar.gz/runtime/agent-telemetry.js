import { auditSdkUsage } from "./usage-audit.js";
import { AsyncLocalStorage } from "node:async_hooks";
import { randomUUID } from "node:crypto";
import { ATTR_BLAME_AGENT_ID, ATTR_BLAME_AGENT_ITERATION, ATTR_BLAME_AGENT_PARENT_ID, ATTR_BLAME_AGENT_ROLE, ATTR_BLAME_AGENT_STRATEGY, ATTR_BLAME_SHELL_CATEGORY, ATTR_BLAME_EXECUTION_ID, ATTR_BLAME_EXECUTION_KIND, ATTR_BLAME_INTERVENTION_TYPE, ATTR_BLAME_MULTI_AGENT_ENABLED, ATTR_BLAME_MULTI_AGENT_USED, ATTR_BLAME_OPERATION_NAME, ATTR_BLAME_OPERATION_STATUS, ATTR_BLAME_PROVIDER_AUTH_TYPE, ATTR_BLAME_REPOSITORY_LANGUAGE, ATTR_BLAME_REPOSITORY_SIZE_BUCKET, ATTR_BLAME_STORY_ID, ATTR_BLAME_TASK_COMPLEXITY_BUCKET, ATTR_BLAME_TOOL_CATEGORY, ATTR_BLAME_TOOL_NAME, ATTR_BLAME_TEST_STATUS, ATTR_ERROR_TYPE, ATTR_GEN_AI_OPERATION_NAME, ATTR_GEN_AI_PROVIDER_NAME, ATTR_GEN_AI_REQUEST_MODEL, ATTR_GEN_AI_RESPONSE_FINISH_REASONS, ATTR_GEN_AI_RESPONSE_MODEL, ATTR_GEN_AI_TOOL_CALL_ID, ATTR_GEN_AI_TOOL_NAME, ATTR_GEN_AI_USAGE_CACHE_CREATION_INPUT_TOKENS, ATTR_GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS, ATTR_GEN_AI_USAGE_INPUT_TOKENS, ATTR_GEN_AI_USAGE_OUTPUT_TOKENS, GEN_AI_OPERATION_CHAT, GEN_AI_OPERATION_EXECUTE_TOOL, GEN_AI_OPERATION_INVOKE_AGENT, METRIC_GEN_AI_OPERATION_DURATION, METRIC_GEN_AI_TIME_TO_FIRST_CHUNK, METRIC_GEN_AI_TOKEN_USAGE, SpanKind, boundedMetricDimensionName, getBlameTelemetry, getExecutionRegistry, semanticGenAiProviderName, } from "@blame/telemetry";
const telemetry = getBlameTelemetry();
const executions = getExecutionRegistry();
const businessExecutionScope = new AsyncLocalStorage();
const toolCallFinishPayload = { finishReason: "tool-calls" };
export class AgentTelemetry {
    sessions = new Map();
    start(sessionId, input) {
        const normalizedInput = normalizeTelemetryInput(input);
        const descriptor = executionDescriptor(sessionId, normalizedInput);
        const state = createSessionState(normalizedInput, descriptor);
        state.component = this.beginComponent(state);
        this.sessions.set(sessionId, state);
        telemetry.log("info", "blame.agent.started", traceAttributes(state), state.component.span.context);
    }
    setAuthentication(sessionId, authType) {
        const state = this.sessions.get(sessionId);
        const normalizedAuthType = providerAuthType(authType);
        if (!state || !normalizedAuthType)
            return;
        state.authType = normalizedAuthType;
        setDescriptorAttributes(state, {
            [ATTR_BLAME_PROVIDER_AUTH_TYPE]: normalizedAuthType,
        });
        executions.setAttributes(state.descriptor.executionId, {
            [ATTR_BLAME_PROVIDER_AUTH_TYPE]: normalizedAuthType,
        });
        if (!state.component)
            return;
        state.component.span.setAttributes({
            [ATTR_BLAME_PROVIDER_AUTH_TYPE]: normalizedAuthType,
        });
    }
    beginTurn(sessionId, executionId, storyId, complexityBucket) {
        const state = this.sessions.get(sessionId);
        if (!state)
            return;
        if (state.component)
            this.finish(sessionId, "succeeded");
        state.input.taskComplexityBucket =
            boundedComplexityBucket(complexityBucket);
        state.descriptor = nextExecutionDescriptor(state.descriptor, executionId, storyId);
        state.descriptor.attributes = {
            ...executionMetricAttributes(state.input),
            [ATTR_BLAME_PROVIDER_AUTH_TYPE]: state.authType,
        };
        resetTurn(state);
        state.component = this.beginComponent(state);
    }
    startModelRequest(sessionId) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        this.startModelSpan(state, leadDetails());
    }
    setRepositoryCohorts(sessionId, languages, fileCount) {
        const state = this.sessions.get(sessionId);
        if (!state)
            return;
        applyRepositoryCohorts(state.input, languages, fileCount);
        const attributes = cohortAttributes(state.input);
        setDescriptorAttributes(state, attributes);
        executions.setAttributes(state.descriptor.executionId, attributes);
        state.component?.span.setAttributes(attributes);
        setActiveSpanAttributes(state, attributes);
    }
    withinSession(sessionId, operation) {
        const state = this.sessions.get(sessionId);
        const activeSpan = state?.modelSpans.get("lead")?.span ?? state?.component?.span;
        return activeSpan
            ? telemetry.withinSpan(activeSpan, operation)
            : operation();
    }
    context(sessionId) {
        const state = this.sessions.get(sessionId);
        return (state?.modelSpans.get("lead")?.span.context ??
            state?.component?.span.context);
    }
    ready(sessionId, promptDeferred) {
        if (!promptDeferred)
            return;
        this.finish(sessionId, "succeeded");
    }
    restore(sourceSessionId, restoredSessionId) {
        const source = this.sessions.get(sourceSessionId);
        if (!source)
            return;
        this.finish(sourceSessionId, "succeeded");
        this.start(restoredSessionId, {
            ...source.input,
            executionId: source.descriptor.executionId,
            storyId: source.descriptor.storyId,
        });
        if (source.authType) {
            this.setAuthentication(restoredSessionId, source.authType);
        }
    }
    observeCoreEvent(sessionId, coreEvent) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        const details = coreEventDetails(coreEvent);
        if (details.role === "teammate")
            this.markMultiAgent(state);
        this.updateIteration(state, details.agentKey, details.iteration);
        if (details.role === "teammate")
            this.startAgentSpan(state, details);
        this.observeCoreDetails(state, coreEvent.type, details);
    }
    observeEvent(sessionId, event) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        if (event.type === "text" || event.type === "reasoning") {
            this.startModelSpan(state, leadDetails());
            this.recordFirstAction(state);
            this.recordModelFirstChunk(state, "lead");
        }
        if (event.type === "error")
            this.fail(sessionId, event.payload);
        if (event.type === "done")
            this.finishFromPayload(sessionId, event.payload);
    }
    recordUsageSummary(sessionId, summary) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        this.recordAggregateUsage(state, summary);
    }
    recordPostStopEvent(sessionId, tokens) {
        const state = this.sessions.get(sessionId);
        if (!state)
            return;
        const attributes = metricDimensions(state);
        telemetry.count("blame.harness.post_stop_events", 1, attributes, state.component?.span.context);
        if (tokens > 0)
            telemetry.record("blame.harness.post_stop_tokens", tokens, attributes, state.component?.span.context);
    }
    recordPostTerminalEvent(sessionId, tokens) {
        const state = this.sessions.get(sessionId);
        if (!state)
            return;
        const attributes = metricDimensions(state);
        telemetry.count("blame.harness.post_terminal_events", 1, attributes, state.component?.span.context);
        if (tokens > 0)
            telemetry.record("blame.harness.post_terminal_tokens", tokens, attributes, state.component?.span.context);
        telemetry.log("error", "blame.harness.post_terminal_event", { ...attributes, tokens }, state.component?.span.context);
    }
    completeModelRequest(sessionId, payload) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return undefined;
        this.finishModelSpans(state, finishStatus(asRecord(payload)), payload);
        return state.component.span.context;
    }
    humanIntervention(sessionId, kind) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        const intervention = boundedInterventionType(kind);
        const attributes = {
            ...metricDimensions(state),
            [ATTR_BLAME_INTERVENTION_TYPE]: intervention,
        };
        telemetry.count("blame.agent.human_intervention.count", 1, attributes, state.component.span.context);
        state.component.span.addEvent("blame.agent.human_intervention", {
            [ATTR_BLAME_INTERVENTION_TYPE]: intervention,
        });
    }
    recordQuality(sessionId, quality) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        const attributes = metricDimensions(state);
        telemetry.record("blame.agent.files_modified", quality.filesModified, attributes, state.component.span.context);
        telemetry.record("blame.agent.tests_added", quality.testsAdded, attributes, state.component.span.context);
    }
    recordRevertedChange(sessionId) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        telemetry.count("blame.agent.reverted_change.count", 1, metricDimensions(state), state.component.span.context);
    }
    cancel(sessionId) {
        this.finish(sessionId, "canceled");
    }
    fail(sessionId, error) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        this.finishActiveSpans(state, "failed", error);
        countProviderError(metricDimensions(state), state.component.span.context, error);
        this.recordCompletionMetrics(state, "failed", error);
        telemetry.log("error", "blame.agent.failed", { ...traceAttributes(state), ...errorRecord(error) }, state.component.span.context);
        state.component.fail(error);
        state.component = undefined;
    }
    remove(sessionId) {
        const state = this.sessions.get(sessionId);
        if (!state)
            return;
        if (state.component)
            this.finish(sessionId, "canceled");
        this.sessions.delete(sessionId);
    }
    shutdown() {
        for (const sessionId of this.sessions.keys())
            this.cancel(sessionId);
        this.sessions.clear();
    }
    async runOperation(input, operationName, operation, authType) {
        const operationState = beginDetachedOperation(normalizeTelemetryInput(input), operationName, authType);
        const { attributes, component, modelSpan } = operationState;
        try {
            const result = await telemetry.withinSpan(modelSpan, operation);
            finishDetachedOperation(component, modelSpan, attributes, result);
            return result;
        }
        catch (error) {
            failDetachedOperation(component, modelSpan, attributes, error);
            throw error;
        }
    }
    async runBusinessOperation(input, operationName, operation) {
        const current = beginBusinessOperation(normalizeTelemetryInput(input), operationName);
        try {
            const result = await runWithinBusinessScope(current, operation);
            finishBusinessOperation(current, "succeeded");
            return result;
        }
        catch (error) {
            finishBusinessOperation(current, "failed", error);
            throw error;
        }
    }
    async runCheckpointRestore(sessionId, operation) {
        const state = this.sessions.get(sessionId);
        if (!state)
            return operation();
        const current = beginCheckpointOperation(state);
        try {
            const result = await telemetry.withinSpan(current.component.span, operation);
            if (state.component)
                telemetry.count("blame.harness.checkpoint_restorations", 1, metricDimensions(state), state.component.span.context);
            finishBusinessOperation(current, "succeeded");
            return result;
        }
        catch (error) {
            finishBusinessOperation(current, "failed", error);
            throw error;
        }
    }
    recordOperationRetry(input, operationName, error) {
        const normalizedInput = normalizeTelemetryInput(input);
        telemetry.count("blame.agent.retry.count", 1, {
            ...detachedOperationAttributes(normalizedInput, operationName),
            [ATTR_ERROR_TYPE]: error ? "ModelError" : "AgentError",
        });
    }
    beginComponent(state) {
        return executions.beginComponent(state.descriptor, "invoke_agent", {
            ...traceAttributes(state),
            [ATTR_GEN_AI_OPERATION_NAME]: GEN_AI_OPERATION_INVOKE_AGENT,
        }, businessScopeParent(state.descriptor.executionId));
    }
    observeCoreDetails(state, coreType, details) {
        if (isUsageEvent(details.event)) {
            this.recordUsage(state, details.event, details.agentKey);
        }
        if (isRetryEvent(details.event))
            this.recordRetry(state, details);
        if (details.event.type === "iteration_start")
            telemetry.count("blame.harness.model_turns", 1, metricDimensions(state), state.component?.span.context);
        if (details.event.type === "iteration_start")
            this.startModelSpan(state, details);
        const tool = toolDetails(coreType, details);
        if (tool?.name === "spawn_agent")
            this.markMultiAgent(state);
        if (tool?.phase === "started")
            this.startTool(state, details, tool);
        if (tool?.phase === "finished")
            this.finishTool(state, details, tool);
        if (isContentEvent(details.event))
            this.observeContent(state, details);
        if (coreType === "chunk")
            this.observeChunk(state, details);
    }
    observeContent(state, details) {
        const contentType = stringValue(details.event.contentType);
        if (contentType !== "text" && contentType !== "reasoning")
            return;
        this.startModelSpan(state, details);
        this.recordFirstAction(state);
        this.recordModelFirstChunk(state, details.agentKey);
    }
    observeChunk(state, details) {
        if (details.payload.stream !== "agent")
            return;
        this.startModelSpan(state, details);
        this.recordFirstAction(state);
        this.recordModelFirstChunk(state, details.agentKey);
    }
    startAgentSpan(state, details) {
        if (state.agentSpans.has(details.agentKey) || !state.component)
            return;
        const parentTool = availableSpawnTool(state, details.parentAgentKey);
        const parent = parentTool?.span.context ?? state.component.span.context;
        const span = telemetry.startSpan(GEN_AI_OPERATION_INVOKE_AGENT, {
            attributes: agentSpanAttributes(state, details),
            parent,
        });
        state.agentSpans.set(details.agentKey, {
            parentAgentKey: details.parentAgentKey,
            parentTool: parentTool?.span,
            span,
        });
    }
    startModelSpan(state, details) {
        if (state.modelSpans.has(details.agentKey) || !state.component)
            return;
        const attributes = modelSpanAttributes(state, details);
        const span = telemetry.startSpan(`${GEN_AI_OPERATION_CHAT} ${state.input.modelId}`, {
            attributes,
            kind: SpanKind.CLIENT,
            parent: state.agentSpans.get(details.agentKey)?.span.context ??
                state.component.span.context,
        });
        state.modelSpans.set(details.agentKey, {
            firstChunkRecorded: false,
            iteration: agentIteration(state, details),
            role: details.role,
            span,
            usage: emptyUsage(),
        });
    }
    finishModelSpan(state, agentKey, payload, outcome = "succeeded") {
        const current = state.modelSpans.get(agentKey);
        if (!current)
            return;
        state.modelSpans.delete(agentKey);
        completeModelSpan(state, current, payload, outcome);
    }
    startTool(state, details, tool) {
        if (!state.component)
            return;
        this.finishModelSpan(state, details.agentKey, toolCallFinishPayload);
        const key = toolKey(details.agentKey, tool);
        if (state.toolSpans.has(key))
            return;
        const category = toolCategory(tool.name, tool.input);
        const toolName = boundedToolName(tool.name);
        const attributes = toolAttributes(state, details, { ...tool, name: toolName }, category);
        const span = trackToolSpan(state, state.component, details, key, toolName, category, attributes);
        this.recordToolStart(state);
        telemetry.count("blame.tool.call.count", 1, attributes, span.context);
    }
    recordToolStart(state) {
        state.toolCallCount += 1;
        this.recordFirstAction(state);
    }
    finishTool(state, details, tool) {
        const key = toolKey(details.agentKey, tool);
        const current = state.toolSpans.get(key);
        if (!current)
            return;
        const outcome = toolFailed(details.event) ? "failed" : "succeeded";
        if (current.name === "spawn_agent") {
            this.finishAgentsForTool(state, current.span, outcome);
        }
        recordHarnessToolMetrics(state, current, details.event, details.payload);
        state.toolSpans.delete(key);
        completeToolSpan(state, current, outcome);
    }
    finishAgentsForTool(state, parentTool, outcome) {
        const roots = [...state.agentSpans]
            .filter(([, current]) => current.parentTool === parentTool)
            .map(([agentKey]) => agentKey);
        this.finishAgentKeys(state, descendantAgentKeys(state, roots), outcome);
    }
    finishAgentKeys(state, agentKeys, outcome) {
        for (const agentKey of leafOrderedAgentKeys(state, agentKeys)) {
            this.finishAgentSpan(state, agentKey, outcome);
        }
    }
    finishAgentSpan(state, agentKey, outcome) {
        const current = state.agentSpans.get(agentKey);
        if (!current)
            return;
        this.finishModelSpan(state, agentKey, undefined, outcome);
        this.finishAgentToolSpans(state, agentKey, outcome);
        state.agentSpans.delete(agentKey);
        if (outcome === "failed") {
            current.span.setAttributes({ [ATTR_ERROR_TYPE]: "AgentError" });
        }
        current.span.end(outcome);
    }
    finishAgentToolSpans(state, agentKey, outcome) {
        for (const [key, current] of state.toolSpans) {
            if (current.agentKey !== agentKey)
                continue;
            state.toolSpans.delete(key);
            completeToolSpan(state, current, outcome);
        }
    }
    recordFirstAction(state) {
        if (state.firstActionRecorded || !state.component)
            return;
        state.firstActionRecorded = true;
        telemetry.record("blame.agent.time_to_first_action", turnDuration(state), metricDimensions(state), state.component.span.context);
    }
    recordModelFirstChunk(state, agentKey) {
        const current = state.modelSpans.get(agentKey);
        if (!current || current.firstChunkRecorded)
            return;
        current.firstChunkRecorded = true;
        const duration = current.span.durationSeconds();
        telemetry.record(METRIC_GEN_AI_TIME_TO_FIRST_CHUNK, duration, modelAttributes(state, current.role, current.iteration), current.span.context);
        telemetry.record("blame.model.time_to_first_token", duration, modelAttributes(state, current.role, current.iteration), current.span.context);
    }
    recordRetry(state, details) {
        state.retryCount += 1;
        const reason = retryReason(details.event);
        const attributes = {
            ...modelAttributes(state, details.role, agentIteration(state, details)),
            [ATTR_ERROR_TYPE]: retryErrorType(reason),
        };
        telemetry.count("blame.agent.retry.count", 1, attributes, state.component?.span.context);
        telemetry.count("blame.harness.model_retries", 1, attributes, state.component?.span.context);
        countProviderError(attributes, state.component?.span.context, {
            reason,
        });
        this.finishModelSpan(state, details.agentKey, { finishReason: reason }, "failed");
    }
    markMultiAgent(state) {
        if (state.multiAgentUsed)
            return;
        state.multiAgentUsed = true;
        const attributes = { [ATTR_BLAME_MULTI_AGENT_USED]: true };
        setDescriptorAttributes(state, attributes);
        executions.setAttributes(state.descriptor.executionId, attributes);
        state.component?.span.setAttributes(attributes);
        setActiveSpanAttributes(state, attributes);
    }
    recordUsage(state, value, agentKey) {
        if (!state.component)
            return;
        const next = usageSnapshot(value);
        const audit = auditSdkUsage(value);
        state.component.span.setAttributes({
            "blame.usage.completeness": audit.completeness,
            "blame.usage.normalization_version": audit.normalizationVersion,
            "blame.usage.cost_available": audit.cost !== null,
        });
        const previous = state.usageByAgent.get(agentKey) ?? emptyUsage();
        const delta = usageDelta(previous, next);
        state.usageByAgent.set(agentKey, next);
        state.usage = addUsage(state.usage, delta);
        recordModelUsage(state, agentKey, delta);
        recordTokenUsage(state, delta, state.component.span.context);
        if (delta.input > 0)
            telemetry.record("blame.harness.context_tokens_per_turn", delta.input, metricDimensions(state), state.component.span.context);
        recordCost(state, delta.cost, state.component.span.context);
        state.component.span.setAttributes(usageAttributes(state.usage));
    }
    recordAggregateUsage(state, value) {
        if (!state.component)
            return;
        const next = usageSnapshot(value);
        if (state.usageByAgent.size === 0) {
            const delta = usageDelta(state.aggregateUsageCursor, next);
            state.aggregateUsageCursor = next;
            state.usage = addUsage(state.usage, delta);
            recordTokenUsage(state, delta, state.component.span.context);
            recordCost(state, delta.cost, state.component.span.context);
        }
        else {
            const missing = missingUsage(state.usage, next);
            state.usage = addUsage(state.usage, missing);
            recordTokenUsage(state, missing, state.component.span.context);
            recordCost(state, missing.cost, state.component.span.context);
        }
        state.component.span.setAttributes(usageAttributes(state.usage));
    }
    updateIteration(state, agentKey, iteration) {
        if (iteration === undefined)
            return;
        state.agentIterations.set(agentKey, iteration);
        state.iterations.add(`${agentKey}:${iteration}`);
        state.iteration = Math.max(state.iteration, iteration);
        updateModelIteration(state, agentKey, iteration);
        state.component?.span.setAttributes({
            [ATTR_BLAME_AGENT_ITERATION]: state.iteration,
        });
    }
    finishFromPayload(sessionId, payload) {
        const state = this.sessions.get(sessionId);
        if (!state)
            return;
        this.finishFromPayloadForState(state, asRecord(payload), sessionId);
    }
    finishFromPayloadForState(state, payload, sessionId = sessionIdForState(this.sessions, state)) {
        const status = finishStatus(payload);
        if (status === "failed")
            this.fail(sessionId, payload);
        else if (status === "canceled")
            this.finish(sessionId, "canceled", payload);
        else
            this.finish(sessionId, "succeeded", payload);
    }
    finish(sessionId, outcome, payload) {
        const state = this.sessions.get(sessionId);
        if (!state?.component)
            return;
        const finishReason = normalizedFinishReason(payload, outcome);
        state.component.span.setAttributes({
            [ATTR_GEN_AI_RESPONSE_FINISH_REASONS]: [finishReason],
        });
        this.finishActiveSpans(state, outcome, payload);
        state.component.span.setAttributes(usageAttributes(state.usage));
        this.recordCompletionMetrics(state, outcome);
        telemetry.log("info", "blame.agent.completed", { ...traceAttributes(state), "blame.execution.status": outcome }, state.component.span.context);
        if (outcome === "canceled")
            state.component.cancel();
        else
            state.component.succeed();
        state.component = undefined;
    }
    finishActiveSpans(state, outcome, payload) {
        this.finishAgentSpans(state, outcome);
        this.finishModelSpans(state, outcome, payload);
        this.finishToolSpans(state, outcome);
    }
    finishAgentSpans(state, outcome) {
        const agentKeys = new Set(state.agentSpans.keys());
        this.finishAgentKeys(state, agentKeys, outcome);
    }
    finishModelSpans(state, outcome, payload) {
        for (const current of state.modelSpans.values()) {
            completeModelSpan(state, current, asRecord(payload), outcome);
        }
        state.modelSpans.clear();
    }
    finishToolSpans(state, outcome) {
        for (const current of state.toolSpans.values()) {
            completeToolSpan(state, current, outcome);
        }
        state.toolSpans.clear();
    }
    recordCompletionMetrics(state, outcome, error) {
        const attributes = {
            ...metricDimensions(state),
            [ATTR_BLAME_MULTI_AGENT_USED]: state.multiAgentUsed,
            "blame.execution.status": outcome,
            ...errorMetric(error),
        };
        const activeContext = state.component?.span.context;
        recordAgentOutcomeDistributions(state, attributes, activeContext);
    }
}
function beginBusinessOperation(input, operationName) {
    const descriptor = executionDescriptor(randomUUID(), input);
    const attributes = {
        ...executionMetricAttributes(input),
        [ATTR_BLAME_OPERATION_NAME]: operationName,
    };
    const component = executions.beginComponent(descriptor, `blame.${operationName}`, attributes, businessScopeParent(descriptor.executionId));
    return {
        attributes,
        component,
        executionId: descriptor.executionId,
        operationName,
    };
}
function runWithinBusinessScope(current, operation) {
    const scope = {
        executionId: current.executionId,
        parent: current.component.span.context,
    };
    return businessExecutionScope.run(scope, () => telemetry.withinSpan(current.component.span, operation));
}
function businessScopeParent(executionId) {
    const scope = businessExecutionScope.getStore();
    return scope?.executionId === executionId ? scope.parent : undefined;
}
function finishBusinessOperation(current, outcome, error) {
    recordBusinessOperation(current.component, current.operationName, current.attributes, outcome, error);
}
function beginCheckpointOperation(state) {
    const operationName = "checkpoint.restore";
    const attributes = {
        ...metricDimensions(state),
        [ATTR_BLAME_INTERVENTION_TYPE]: "checkpoint_restore",
        [ATTR_BLAME_OPERATION_NAME]: operationName,
    };
    const component = executions.beginComponent(state.descriptor, "blame.checkpoint.restore", attributes, state.component?.span.context);
    recordCheckpointMetrics(attributes, component.span.context);
    component.span.addEvent("blame.agent.human_intervention", {
        [ATTR_BLAME_INTERVENTION_TYPE]: "checkpoint_restore",
    });
    return {
        attributes,
        component,
        executionId: state.descriptor.executionId,
        operationName,
    };
}
function recordCheckpointMetrics(attributes, activeContext) {
    telemetry.count("blame.agent.human_intervention.count", 1, attributes, activeContext);
    telemetry.count("blame.agent.reverted_change.count", 1, attributes, activeContext);
}
function createSessionState(input, descriptor) {
    return {
        agentIterations: new Map(),
        agentSpans: new Map(),
        aggregateUsageCursor: emptyUsage(),
        descriptor,
        authType: undefined,
        firstActionRecorded: false,
        firstEditRecorded: false,
        input,
        iteration: 0,
        iterations: new Set(),
        modelSpans: new Map(),
        multiAgentUsed: false,
        retryCount: 0,
        toolCallCount: 0,
        toolSpans: new Map(),
        turnStartedAt: performance.now(),
        usage: emptyUsage(),
        usageByAgent: new Map(),
    };
}
function normalizeTelemetryInput(input) {
    return {
        ...input,
        modelId: boundedCohortName(input.modelId),
        providerId: semanticGenAiProviderName(input.providerId),
        repositoryLanguage: repositoryLanguage(input.repositoryLanguage ? [input.repositoryLanguage] : undefined),
        repositorySizeBucket: boundedRepositorySizeBucket(input.repositorySizeBucket),
        taskComplexityBucket: boundedComplexityBucket(input.taskComplexityBucket),
    };
}
export function boundedCohortName(value) {
    return boundedMetricDimensionName(value);
}
export function boundedToolName(value) {
    const toolName = boundedMetricDimensionName(value);
    return /^[A-Za-z][A-Za-z0-9._:/-]{0,95}$/.test(toolName) ? toolName : "other";
}
export function boundedInterventionType(value) {
    return interventionTypes.has(value) ? value : "other";
}
export function providerAuthType(value) {
    return value && providerAuthTypes.has(value)
        ? value
        : value
            ? "other"
            : undefined;
}
function resetTurn(state) {
    state.agentIterations.clear();
    state.agentSpans.clear();
    state.aggregateUsageCursor = emptyUsage();
    state.firstActionRecorded = false;
    state.firstEditRecorded = false;
    state.iteration = 0;
    state.iterations.clear();
    state.multiAgentUsed = false;
    state.retryCount = 0;
    state.toolCallCount = 0;
    state.turnStartedAt = performance.now();
    state.usage = emptyUsage();
    state.usageByAgent.clear();
}
function setActiveSpanAttributes(state, attributes) {
    for (const current of state.agentSpans.values()) {
        current.span.setAttributes(attributes);
    }
    for (const current of state.modelSpans.values()) {
        current.span.setAttributes(attributes);
    }
    for (const current of state.toolSpans.values()) {
        current.span.setAttributes(attributes);
    }
}
function setDescriptorAttributes(state, attributes) {
    state.descriptor.attributes = {
        ...state.descriptor.attributes,
        ...attributes,
    };
}
function executionDescriptor(sessionId, input) {
    return {
        attributes: executionMetricAttributes(input),
        executionId: input.executionId?.trim() ||
            businessExecutionScope.getStore()?.executionId ||
            sessionId,
        storyId: input.storyId,
    };
}
export function nextExecutionDescriptor(descriptor, executionId, storyId) {
    return {
        ...descriptor,
        executionId: executionId?.trim() || descriptor.executionId,
        storyId: storyId?.trim() || descriptor.storyId,
    };
}
function traceAttributes(state) {
    return {
        ...modelAttributes(state, "lead"),
        [ATTR_BLAME_EXECUTION_ID]: state.descriptor.executionId,
        [ATTR_BLAME_MULTI_AGENT_ENABLED]: multiAgentEnabled(state.input),
        [ATTR_BLAME_MULTI_AGENT_USED]: state.multiAgentUsed,
        [ATTR_BLAME_STORY_ID]: state.descriptor.storyId,
    };
}
function modelAttributes(state, role, iteration = state.iteration) {
    return {
        ...cohortAttributes(state.input),
        [ATTR_BLAME_AGENT_ITERATION]: iteration,
        [ATTR_BLAME_AGENT_ROLE]: role,
        [ATTR_BLAME_AGENT_STRATEGY]: sessionAgentStrategy(state),
        [ATTR_BLAME_MULTI_AGENT_ENABLED]: multiAgentEnabled(state.input),
        [ATTR_BLAME_PROVIDER_AUTH_TYPE]: state.authType,
        [ATTR_GEN_AI_OPERATION_NAME]: GEN_AI_OPERATION_CHAT,
        [ATTR_GEN_AI_PROVIDER_NAME]: state.input.providerId,
        [ATTR_GEN_AI_REQUEST_MODEL]: state.input.modelId,
    };
}
function modelMetricAttributes(state, role, iteration, outcome, response) {
    return {
        ...modelAttributes(state, role, iteration),
        ...response,
        [ATTR_BLAME_OPERATION_STATUS]: outcome,
        ...(outcome === "failed" ? { [ATTR_ERROR_TYPE]: "ModelError" } : {}),
    };
}
function completeModelSpan(state, current, payload, outcome) {
    const response = responseAttributes(payload, outcome);
    current.span.setAttributes(response);
    if (outcome === "failed") {
        current.span.setAttributes({ [ATTR_ERROR_TYPE]: "ModelError" });
    }
    const attributes = modelMetricAttributes(state, current.role, current.iteration, outcome, response);
    recordModelMetrics(current, attributes);
    current.span.end(outcome);
}
function recordModelMetrics(current, attributes) {
    telemetry.count("blame.model.request.count", 1, attributes, current.span.context);
    telemetry.record(METRIC_GEN_AI_OPERATION_DURATION, current.span.durationSeconds(), attributes, current.span.context);
}
function cohortAttributes(input) {
    return {
        [ATTR_BLAME_REPOSITORY_LANGUAGE]: input.repositoryLanguage,
        [ATTR_BLAME_REPOSITORY_SIZE_BUCKET]: input.repositorySizeBucket,
        [ATTR_BLAME_TASK_COMPLEXITY_BUCKET]: input.taskComplexityBucket,
    };
}
function executionMetricAttributes(input) {
    return {
        ...cohortAttributes(input),
        [ATTR_BLAME_AGENT_ROLE]: "lead",
        [ATTR_BLAME_AGENT_STRATEGY]: configuredAgentStrategy(input),
        [ATTR_BLAME_EXECUTION_KIND]: "agent",
        [ATTR_BLAME_MULTI_AGENT_ENABLED]: multiAgentEnabled(input),
        [ATTR_BLAME_MULTI_AGENT_USED]: false,
        [ATTR_GEN_AI_PROVIDER_NAME]: input.providerId,
        [ATTR_GEN_AI_REQUEST_MODEL]: input.modelId,
    };
}
function applyRepositoryCohorts(input, languages, fileCount) {
    const language = repositoryLanguage(languages);
    const sizeBucket = repositorySizeBucket(fileCount);
    if (language)
        input.repositoryLanguage = language;
    if (sizeBucket)
        input.repositorySizeBucket = sizeBucket;
}
export function repositoryLanguage(languages) {
    const normalizedLanguages = new Set();
    for (const language of languages ?? []) {
        const candidate = language.trim().toLowerCase();
        const normalized = repositoryLanguageAliases.get(candidate) ?? candidate;
        normalizedLanguages.add(repositoryLanguages.has(normalized) ? normalized : "other");
    }
    if (normalizedLanguages.size === 0)
        return undefined;
    if (normalizedLanguages.size > 1)
        return "mixed";
    return normalizedLanguages.values().next().value;
}
export function repositorySizeBucket(fileCount) {
    if (fileCount === undefined || !Number.isFinite(fileCount))
        return undefined;
    if (fileCount < 100)
        return "small";
    if (fileCount < 1_000)
        return "medium";
    if (fileCount < 10_000)
        return "large";
    return "very_large";
}
function boundedComplexityBucket(value) {
    return value && complexityBuckets.has(value) ? value : undefined;
}
function boundedRepositorySizeBucket(value) {
    return value && repositorySizeBuckets.has(value) ? value : undefined;
}
const repositoryLanguages = new Set([
    "c",
    "cpp",
    "csharp",
    "css",
    "dart",
    "go",
    "html",
    "java",
    "javascript",
    "kotlin",
    "mixed",
    "php",
    "python",
    "ruby",
    "rust",
    "shell",
    "swift",
    "typescript",
    "vue",
]);
const repositoryLanguageAliases = new Map([
    ["c#", "csharp"],
    ["c++", "cpp"],
    ["cs", "csharp"],
    ["jsx", "javascript"],
    ["sh", "shell"],
    ["tsx", "typescript"],
]);
const complexityBuckets = new Set(["small", "medium", "large"]);
const interventionTypes = new Set(["abort", "feedback", "tool_approval"]);
const providerAuthTypes = new Set(["api-key", "oauth"]);
const repositorySizeBuckets = new Set([
    "small",
    "medium",
    "large",
    "very_large",
]);
function modelSpanAttributes(state, details) {
    return {
        ...modelAttributes(state, details.role, agentIteration(state, details)),
        [ATTR_BLAME_AGENT_ID]: details.agentKey,
        [ATTR_BLAME_MULTI_AGENT_USED]: state.multiAgentUsed,
    };
}
function agentSpanAttributes(state, details) {
    return {
        ...modelAttributes(state, details.role, agentIteration(state, details)),
        [ATTR_BLAME_AGENT_ID]: details.agentKey,
        [ATTR_BLAME_AGENT_PARENT_ID]: details.parentAgentKey,
        [ATTR_BLAME_MULTI_AGENT_USED]: true,
        [ATTR_GEN_AI_OPERATION_NAME]: GEN_AI_OPERATION_INVOKE_AGENT,
    };
}
function availableSpawnTool(state, parentAgentKey) {
    const assigned = new Set([...state.agentSpans.values()].map((current) => current.parentTool));
    const candidates = [...state.toolSpans.values()].filter((current) => current.agentKey === parentAgentKey && current.name === "spawn_agent");
    return (candidates.find((current) => !assigned.has(current.span)) ??
        candidates[candidates.length - 1]);
}
function descendantAgentKeys(state, roots) {
    const agentKeys = new Set(roots);
    let changed = true;
    while (changed) {
        changed = false;
        for (const [agentKey, current] of state.agentSpans) {
            if (!agentKeys.has(current.parentAgentKey) || agentKeys.has(agentKey))
                continue;
            agentKeys.add(agentKey);
            changed = true;
        }
    }
    return agentKeys;
}
function leafOrderedAgentKeys(state, agentKeys) {
    const pending = new Set([...agentKeys].filter((agentKey) => state.agentSpans.has(agentKey)));
    const ordered = [];
    while (pending.size > 0) {
        const leaf = [...pending].find((agentKey) => !hasPendingChild(state, pending, agentKey));
        const next = leaf ?? pending.values().next().value;
        if (!next)
            break;
        ordered.push(next);
        pending.delete(next);
    }
    return ordered;
}
function hasPendingChild(state, pending, agentKey) {
    return [...pending].some((candidate) => state.agentSpans.get(candidate)?.parentAgentKey === agentKey);
}
function agentIteration(state, details) {
    return details.iteration ?? state.agentIterations.get(details.agentKey) ?? 0;
}
function updateModelIteration(state, agentKey, iteration) {
    const current = state.modelSpans.get(agentKey);
    if (!current)
        return;
    current.iteration = iteration;
    current.span.setAttributes({ [ATTR_BLAME_AGENT_ITERATION]: iteration });
}
function metricDimensions(state) {
    return {
        ...modelAttributes(state, "lead"),
        [ATTR_BLAME_PROVIDER_AUTH_TYPE]: state.authType,
    };
}
function recordAgentOutcomeDistributions(state, attributes, activeContext) {
    const values = [
        ["blame.agent.iterations_per_execution", state.iterations.size],
        ["blame.agent.tool_calls_per_execution", state.toolCallCount],
        ["blame.agent.retries_per_execution", state.retryCount],
    ];
    for (const [name, value] of values) {
        telemetry.record(name, value, attributes, activeContext);
    }
}
function toolAttributes(state, details, tool, category) {
    return {
        ...modelAttributes(state, details.role, agentIteration(state, details)),
        [ATTR_BLAME_AGENT_ID]: details.agentKey,
        [ATTR_BLAME_MULTI_AGENT_USED]: state.multiAgentUsed,
        [ATTR_BLAME_SHELL_CATEGORY]: commandCategory(tool.name, tool.input),
        [ATTR_BLAME_TOOL_CATEGORY]: category,
        [ATTR_BLAME_TOOL_NAME]: tool.name,
        [ATTR_GEN_AI_OPERATION_NAME]: GEN_AI_OPERATION_EXECUTE_TOOL,
        [ATTR_GEN_AI_TOOL_CALL_ID]: tool.id,
        [ATTR_GEN_AI_TOOL_NAME]: tool.name,
    };
}
function startToolSpan(parent, toolName, attributes) {
    return telemetry.startSpan(`${GEN_AI_OPERATION_EXECUTE_TOOL} ${toolName}`, {
        attributes,
        parent,
    });
}
function trackToolSpan(state, component, details, key, name, category, attributes) {
    const parent = state.agentSpans.get(details.agentKey)?.span.context ??
        component.span.context;
    const span = startToolSpan(parent, name, attributes);
    state.toolSpans.set(key, {
        agentKey: details.agentKey,
        category,
        iteration: agentIteration(state, details),
        name,
        role: details.role,
        span,
    });
    return span;
}
function toolMetricAttributes(state, tool) {
    return {
        ...modelAttributes(state, tool.role, tool.iteration),
        [ATTR_BLAME_TOOL_CATEGORY]: tool.category,
        [ATTR_BLAME_TOOL_NAME]: tool.name,
        [ATTR_GEN_AI_TOOL_NAME]: tool.name,
    };
}
function completeToolSpan(state, current, outcome) {
    const attributes = {
        ...toolMetricAttributes(state, current),
        ...(outcome === "failed" ? { [ATTR_ERROR_TYPE]: "ToolError" } : {}),
    };
    recordToolDuration(current, attributes);
    recordTestOutcome(current, outcome, attributes);
    if (outcome === "failed")
        recordToolFailure(current, attributes);
    current.span.end(outcome);
}
function recordHarnessToolMetrics(state, current, event, payload) {
    const attributes = toolMetricAttributes(state, current);
    const output = asRecord(event.output ?? payload.output);
    const body = asRecord(output.data ?? output.output ?? output);
    const data = {
        ...body,
        ...(body.status === undefined ? { status: output.status } : {}),
        ...(body.category === undefined ? { category: output.category } : {}),
    };
    const metricContext = { attributes, current, data, state };
    if (output.status === "blocked" && output.category === "environment")
        recordHarnessCount(metricContext, "blame.harness.unavailable_capabilities");
    current.span.setAttributes(harnessTraceAttributes(data));
    if (navigationReadTool(current.name))
        recordReadMetrics(metricContext);
    if (semanticEditTool(current.name))
        recordEditMetrics(metricContext);
    if (externalReadTool(current.name))
        recordExternalReadMetrics(metricContext);
    if (current.name === "consult_specialist")
        recordHarnessValue(metricContext, "blame.harness.specialist_duration", current.span.durationSeconds());
    if (current.name === "consult_specialist" &&
        stringValue(data.reason) === "SPECIALIST_TIMEOUT") {
        recordHarnessCount(metricContext, "blame.harness.specialist_timeouts");
        current.span.addEvent("blame.harness.alert", {
            alert: "SPECIALIST_TIMEOUT",
        });
    }
    if (current.name === "run_task")
        recordRunMetrics(metricContext);
}
function recordExternalReadMetrics(context) {
    recordHarnessCount(context, "blame.harness.external_reads");
    const governor = asRecord(context.data.governor);
    const status = stringValue(context.data.status);
    if (status === "already_available")
        recordHarnessCount(context, "blame.harness.external_read_cache_hits");
    if (status === "already_available" || status === "retry_suppressed")
        recordHarnessCount(context, "blame.harness.external_read_suppressed");
    const returned = numericValue(governor.external_read_returned_bytes);
    if (returned !== undefined)
        recordHarnessValue(context, "blame.harness.external_read_returned_bytes", returned);
}
function recordReadMetrics(context) {
    recordHarnessCount(context, "blame.harness.reads");
    const readBytes = readContentBytes(context.data);
    recordHarnessValue(context, "blame.harness.read_requested_bytes", readBytes);
    if (readBytes > 0)
        recordHarnessValue(context, "blame.harness.read_bytes", readBytes);
    recordHarnessValue(context, "blame.harness.new_read_bytes", readBytes);
    const returnedBytes = stringValue(context.data.status) === "already_in_context" ? 0 : readBytes;
    recordHarnessValue(context, "blame.harness.read_returned_bytes", returnedBytes);
    if (readBytes > 0)
        recordHarnessValue(context, "blame.harness.read_return_ratio", returnedBytes / readBytes);
    recordHarnessValue(context, "blame.harness.read_suppressed_bytes", Math.max(0, readBytes - returnedBytes));
    if (stringValue(context.data.status) === "already_in_context")
        recordHarnessCount(context, "blame.harness.deduplicated_reads");
    if (stringValue(context.data.status) === "already_in_context")
        recordHarnessCount(context, "blame.harness.duplicate_read_count");
    recordHarnessValue(context, "blame.harness.symbol_target_ratio", stringValue(context.data.view) === "symbol" ? 1 : 0);
}
function readContentBytes(data) {
    return [data.content, data.body, data.signature, data.imports]
        .filter((value) => typeof value === "string")
        .reduce((total, value) => total + Buffer.byteLength(value), 0);
}
function recordEditMetrics(context) {
    const status = stringValue(context.data.status);
    if (context.data.changed === true) {
        recordFirstEdit(context);
        recordHarnessCount(context, "blame.harness.direct_edits");
    }
    if (status === "blocked" && context.data.category === "input")
        recordHarnessCount(context, "blame.harness.edit_conflict_count");
}
function harnessTraceAttributes(data) {
    return compactAttributes({
        harness_category: stringValue(data.category),
        harness_status: stringValue(data.status),
        harness_view: stringValue(data.view),
    });
}
function semanticEditTool(name) {
    return name === "edit_code";
}
function navigationReadTool(name) {
    return name === "read_code" || name === "search_code";
}
function externalReadTool(name) {
    return [
        "consult_specialist",
        "fetch_web_content",
        "get_preview_container_logs",
        "get_preview_devtools",
    ].includes(name);
}
function compactAttributes(value) {
    return Object.fromEntries(Object.entries(value).filter(([, entry]) => entry !== undefined));
}
function recordFirstEdit(context) {
    const state = context.state;
    if (state.firstEditRecorded || !state.component)
        return;
    state.firstEditRecorded = true;
    telemetry.record("blame.harness.time_to_first_edit", turnDuration(state), metricDimensions(state), state.component.span.context);
    recordHarnessValue(context, "blame.harness.first_edit_iteration", context.current.iteration);
    recordHarnessValue(context, "blame.harness.tokens_before_first_edit", state.usage.input + state.usage.output);
    if (state.usage.input + state.usage.output > 250_000)
        context.current.span.addEvent("blame.harness.alert", {
            alert: "TOKENS_BEFORE_FIRST_MUTATION_EXCEEDED",
            tokens: state.usage.input + state.usage.output,
        });
}
function recordRunMetrics(context) {
    recordHarnessValue(context, "blame.harness.run_task_duration", context.current.span.durationSeconds());
    recordHarnessValue(context, "blame.harness.time_to_verifiable_result", turnDuration(context.state));
    if (!context.data.run_ref || !context.data.complete_log)
        recordHarnessCount(context, "blame.harness.missing_run_artifacts");
    const execution = asRecord(context.data.execution);
    const resolution = asRecord(execution.package_manager_resolution);
    if (stringValue(resolution.strategy) === "compatible_same_major")
        recordHarnessCount(context, "blame.harness.package_manager_compatible_resolutions");
}
function recordHarnessCount(context, name, value = 1) {
    telemetry.count(name, value, context.attributes, context.current.span.context);
}
function recordHarnessValue(context, name, value) {
    telemetry.record(name, value, context.attributes, context.current.span.context);
}
function recordToolDuration(current, attributes) {
    telemetry.record("blame.tool.duration", current.span.durationSeconds(), attributes, current.span.context);
}
function recordTestOutcome(current, outcome, attributes) {
    if (current.category !== "test")
        return;
    const status = outcome === "succeeded" ? "passed" : outcome;
    telemetry.record("blame.test.duration", current.span.durationSeconds(), attributes, current.span.context);
    telemetry.count("blame.test.run.count", 1, { ...attributes, [ATTR_BLAME_TEST_STATUS]: status }, current.span.context);
}
function recordToolFailure(current, attributes) {
    current.span.setAttributes({ [ATTR_ERROR_TYPE]: "ToolError" });
    telemetry.count("blame.tool.failure.count", 1, attributes, current.span.context);
}
export function coreEventDetails(coreEvent) {
    const payload = asRecord(coreEvent.payload);
    const event = coreEvent.type === "agent_event" ? asRecord(payload.event) : payload;
    const parentAgentId = stringValue(event.parentAgentId) ?? stringValue(payload.parentAgentId);
    const agentId = stringValue(event.agentId) ??
        stringValue(payload.teamAgentId) ??
        stringValue(payload.agentId);
    const teammate = payload.teamRole === "teammate" || Boolean(parentAgentId);
    return {
        agentKey: agentId ?? parentAgentId ?? (teammate ? "teammate" : "lead"),
        event,
        iteration: numericValue(event.iteration),
        payload,
        parentAgentKey: parentAgentId ?? "lead",
        role: teammate ? "teammate" : "lead",
    };
}
function toolDetails(coreType, details) {
    const source = details.event;
    const contentType = stringValue(source.contentType);
    const hookName = stringValue(details.payload.hookEventName);
    if (contentType !== "tool" && coreType !== "hook")
        return undefined;
    const name = stringValue(source.toolName) ?? stringValue(details.payload.toolName);
    if (!name)
        return undefined;
    const phase = toolPhase(stringValue(source.type), hookName);
    if (!phase)
        return undefined;
    const call = asRecord(source.toolCall);
    return {
        id: stringValue(call.id) ??
            stringValue(source.toolCallId) ??
            stringValue(source.contentId),
        input: call.input ?? source.input,
        name,
        phase,
    };
}
function toolPhase(type, hookName) {
    if (type === "content_start" || hookName === "tool_call")
        return "started";
    if (type === "content_end" || hookName === "tool_result")
        return "finished";
    return undefined;
}
function toolKey(agentKey, tool) {
    return `${agentKey}:${tool.id ?? tool.name}`;
}
function toolCategory(name, input) {
    if (name === "spawn_agent")
        return "agent";
    if (name === "run_commands")
        return containsTestCommand(input) ? "test" : "shell";
    if (["editor", "apply_patch"].includes(name))
        return "file_write";
    if (["read_files", "search_codebase"].includes(name))
        return "file_read";
    return "other";
}
function containsTestCommand(input) {
    const serialized = safeSerialization(input).slice(0, 4_096);
    return /(?:^|[\s"'])(?:test|tests|pytest|vitest|jest|japa|mocha|cargo test|go test|node --test)(?:[\s"']|$)/i.test(serialized);
}
export function commandCategory(toolName, input) {
    if (toolName !== "run_commands")
        return undefined;
    const command = safeSerialization(input).slice(0, 4_096).toLowerCase();
    if (containsTestCommand(input))
        return "test";
    if (/\bgit\b/.test(command))
        return "git";
    if (/\b(?:docker|podman|compose)\b/.test(command))
        return "container";
    if (isInstallCommand(command))
        return "install";
    if (/\b(?:build|compile|tsc)\b/.test(command))
        return "build";
    if (/\b(?:npm|pnpm|yarn|bun|pip|poetry|cargo|mvn|gradle)\b/.test(command))
        return "package_manager";
    return "other";
}
function isInstallCommand(command) {
    return /\b(?:install|add|fetch|sync)\b/.test(command);
}
function safeSerialization(value) {
    try {
        return JSON.stringify(value) ?? "";
    }
    catch {
        return "";
    }
}
function isContentEvent(event) {
    const type = stringValue(event.type);
    return type === "content_start" || type === "content_end";
}
function isUsageEvent(event) {
    return stringValue(event.type) === "usage";
}
export function isRetryEvent(event) {
    const type = stringValue(event.type);
    const status = stringValue(event.status);
    const reason = stringValue(event.reason);
    return (type === "retry" ||
        status === "retrying" ||
        (type === "notice" && event.noticeType === "recovery") ||
        retryReasons.has(reason ?? ""));
}
function retryReason(event) {
    return (stringValue(event.reason) ?? stringValue(event.status) ?? "model_retry");
}
function retryErrorType(reason) {
    if (reason === "api_error")
        return "ProviderApiError";
    if (reason === "tool_execution_failed")
        return "ToolError";
    return "ModelError";
}
export function toolFailed(event) {
    const status = stringValue(event.status);
    return (event.isError === true ||
        Boolean(stringValue(event.error)) ||
        status === "failed" ||
        status === "error");
}
function finishStatus(payload) {
    const status = rawFinishReason(payload)?.toLowerCase();
    if (status &&
        [
            "failed",
            "error",
            "max-iterations",
            "max_iterations",
            "mistake-limit",
            "mistake_limit",
        ].includes(status))
        return "failed";
    if (status && ["cancelled", "canceled", "aborted"].includes(status))
        return "canceled";
    return "succeeded";
}
function rawFinishReason(value) {
    const payload = asRecord(value);
    return (stringValue(payload.finishReason) ??
        stringValue(payload.status) ??
        stringValue(payload.reason));
}
export function responseAttributes(payload = {}, outcome = "succeeded") {
    const responseModel = stringValue(payload.responseModel) ?? stringValue(payload.model);
    const model = responseModel
        ? boundedMetricDimensionName(responseModel)
        : undefined;
    const reason = normalizedFinishReason(payload, outcome);
    return {
        [ATTR_GEN_AI_RESPONSE_FINISH_REASONS]: [reason],
        [ATTR_GEN_AI_RESPONSE_MODEL]: model,
    };
}
function normalizedFinishReason(value, outcome) {
    const reason = rawFinishReason(value)?.trim().toLowerCase();
    if (!reason)
        return outcomeFinishReason(outcome);
    if (["stop", "completed", "complete", "success", "succeeded"].includes(reason))
        return "stop";
    if (["tool-calls", "tool_calls"].includes(reason))
        return "tool-calls";
    if (["length", "max_tokens", "max-tokens"].includes(reason))
        return "max-tokens";
    if (["cancelled", "canceled", "aborted"].includes(reason))
        return "aborted";
    if (["failed", "error", "mistake-limit", "mistake_limit"].includes(reason))
        return "error";
    if (["max-iterations", "max_iterations"].includes(reason))
        return "max-iterations";
    return outcome === "succeeded" ? "other" : outcomeFinishReason(outcome);
}
function outcomeFinishReason(outcome) {
    if (outcome === "failed")
        return "error";
    if (outcome === "canceled")
        return "aborted";
    return "stop";
}
const retryReasons = new Set([
    "api_error",
    "completion_without_submit",
    "invalid_tool_call",
    "tool_execution_failed",
]);
export function usageSnapshot(value) {
    const envelope = asRecord(value);
    const usage = usageRecord(envelope);
    return {
        cacheCreated: usageNumber(usage, "totalCacheWriteTokens", "cacheWriteTokens"),
        cacheRead: usageNumber(usage, "totalCacheReadTokens", "cacheReadTokens"),
        cost: usageNumber(usage, "totalCost", "cost"),
        input: usageNumber(usage, "totalInputTokens", "inputTokens"),
        output: usageNumber(usage, "totalOutputTokens", "outputTokens"),
    };
}
export function usageDelta(previous, next) {
    return {
        cacheCreated: monotonicDelta(previous.cacheCreated, next.cacheCreated),
        cacheRead: monotonicDelta(previous.cacheRead, next.cacheRead),
        cost: monotonicDelta(previous.cost, next.cost),
        input: monotonicDelta(previous.input, next.input),
        output: monotonicDelta(previous.output, next.output),
    };
}
function usageRecord(envelope) {
    const aggregate = asRecord(envelope.aggregateUsage);
    if (Object.keys(aggregate).length)
        return aggregate;
    const usage = asRecord(envelope.usage);
    if (Object.keys(usage).length)
        return usage;
    const result = asRecord(envelope.result);
    const resultUsage = asRecord(result.usage);
    return Object.keys(resultUsage).length ? resultUsage : envelope;
}
function usageNumber(usage, totalKey, fallbackKey) {
    return numericValue(usage[totalKey]) ?? numericValue(usage[fallbackKey]) ?? 0;
}
function monotonicDelta(previous, next) {
    return next >= previous ? next - previous : next;
}
function recordTokenUsage(state, delta, activeContext) {
    recordToken(state, "input", delta.input, activeContext);
    recordToken(state, "output", delta.output, activeContext);
    recordCacheUsage(state, delta, activeContext);
}
function recordCacheUsage(state, usage, activeContext) {
    recordCacheMetric("blame.gen_ai.cache_read_token.usage", usage.cacheRead, state, activeContext);
    recordCacheMetric("blame.gen_ai.cache_creation_token.usage", usage.cacheCreated, state, activeContext);
}
function recordCacheMetric(name, value, state, activeContext) {
    if (value <= 0)
        return;
    telemetry.record(name, value, metricDimensions(state), activeContext);
}
function recordCost(state, cost, activeContext) {
    if (cost <= 0)
        return;
    telemetry.count("blame.gen_ai.estimated_cost", cost, metricDimensions(state), activeContext);
}
function recordToken(state, type, value, activeContext) {
    if (value <= 0)
        return;
    telemetry.record(METRIC_GEN_AI_TOKEN_USAGE, value, { ...metricDimensions(state), "gen_ai.token.type": type }, activeContext);
}
function usageAttributes(usage) {
    return {
        [ATTR_GEN_AI_USAGE_CACHE_CREATION_INPUT_TOKENS]: usage.cacheCreated,
        [ATTR_GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS]: usage.cacheRead,
        [ATTR_GEN_AI_USAGE_INPUT_TOKENS]: usage.input,
        [ATTR_GEN_AI_USAGE_OUTPUT_TOKENS]: usage.output,
    };
}
function turnDuration(state) {
    return Math.max(0, performance.now() - state.turnStartedAt) / 1_000;
}
function emptyUsage() {
    return { cacheCreated: 0, cacheRead: 0, cost: 0, input: 0, output: 0 };
}
function recordModelUsage(state, agentKey, delta) {
    if (!agentKey)
        return;
    const current = state.modelSpans.get(agentKey);
    if (!current)
        return;
    current.usage = addUsage(current.usage, delta);
    current.span.setAttributes(usageAttributes(current.usage));
}
function addUsage(current, delta) {
    return {
        cacheCreated: current.cacheCreated + delta.cacheCreated,
        cacheRead: current.cacheRead + delta.cacheRead,
        cost: current.cost + delta.cost,
        input: current.input + delta.input,
        output: current.output + delta.output,
    };
}
function missingUsage(current, candidate) {
    return {
        cacheCreated: Math.max(0, candidate.cacheCreated - current.cacheCreated),
        cacheRead: Math.max(0, candidate.cacheRead - current.cacheRead),
        cost: Math.max(0, candidate.cost - current.cost),
        input: Math.max(0, candidate.input - current.input),
        output: Math.max(0, candidate.output - current.output),
    };
}
function countProviderError(attributes, activeContext, error) {
    const errorType = providerErrorType(error);
    if (!errorType)
        return;
    telemetry.count("blame.provider.error.count", 1, { ...attributes, [ATTR_ERROR_TYPE]: errorType }, activeContext);
}
export function providerErrorType(error) {
    const signal = providerErrorSignal(error);
    if (/rate.?limit|too many requests|\b429\b/.test(signal))
        return "ProviderRateLimitError";
    if (/authentication|unauthorized|invalid api key|\b40[13]\b/.test(signal))
        return "ProviderAuthenticationError";
    if (/timeout|timed out|etimedout/.test(signal))
        return "ProviderTimeoutError";
    if (/econn|enotfound|overload|unavailable|\b5\d\d\b/.test(signal))
        return "ProviderUnavailableError";
    if (/api_error|api(?:connection|status)?error|\bapi\b|provider/.test(signal))
        return "ProviderApiError";
    return undefined;
}
function providerErrorSignal(error) {
    const record = asRecord(error);
    const nested = asRecord(record.error);
    const values = [
        error instanceof Error ? error.name : undefined,
        error instanceof Error ? error.message : undefined,
        ...providerSignalValues(record),
        ...providerSignalValues(nested),
    ];
    return values.filter(Boolean).join(" ").toLowerCase();
}
function providerSignalValues(record) {
    return ["code", "message", "name", "reason", "status", "type"].map((key) => signalValue(record[key]));
}
function signalValue(value) {
    if (typeof value === "string")
        return value;
    return typeof value === "number" && Number.isFinite(value)
        ? String(value)
        : undefined;
}
function errorRecord(error) {
    return {
        [ATTR_ERROR_TYPE]: providerErrorType(error) ?? "AgentError",
    };
}
function errorMetric(error) {
    return error
        ? { [ATTR_ERROR_TYPE]: providerErrorType(error) ?? "AgentError" }
        : {};
}
function sessionIdForState(sessions, state) {
    for (const [sessionId, candidate] of sessions) {
        if (candidate === state)
            return sessionId;
    }
    return "";
}
function asRecord(value) {
    return value && typeof value === "object"
        ? value
        : {};
}
function stringValue(value) {
    return typeof value === "string" && value ? value : undefined;
}
function numericValue(value) {
    return typeof value === "number" && Number.isFinite(value)
        ? value
        : undefined;
}
function leadDetails() {
    return {
        agentKey: "lead",
        event: {},
        payload: {},
        parentAgentKey: "lead",
        role: "lead",
    };
}
function sessionAgentStrategy(state) {
    return configuredAgentStrategy(state.input);
}
function configuredAgentStrategy(input) {
    return multiAgentEnabled(input) ? "multi_agent" : "single_agent";
}
function multiAgentEnabled(input) {
    return Boolean(input.enableAgentTeams || input.enableSpawnAgent);
}
function detachedOperationAttributes(input, operationName, authType) {
    return {
        [ATTR_BLAME_AGENT_ROLE]: "lead",
        [ATTR_BLAME_AGENT_STRATEGY]: configuredAgentStrategy(input),
        [ATTR_BLAME_EXECUTION_KIND]: "agent",
        [ATTR_BLAME_MULTI_AGENT_ENABLED]: multiAgentEnabled(input),
        [ATTR_BLAME_MULTI_AGENT_USED]: false,
        [ATTR_BLAME_OPERATION_NAME]: operationName,
        [ATTR_BLAME_PROVIDER_AUTH_TYPE]: providerAuthType(authType),
        [ATTR_GEN_AI_OPERATION_NAME]: GEN_AI_OPERATION_INVOKE_AGENT,
        [ATTR_GEN_AI_PROVIDER_NAME]: input.providerId,
        [ATTR_GEN_AI_REQUEST_MODEL]: input.modelId,
    };
}
function beginDetachedOperation(input, operationName, authType) {
    const descriptor = executionDescriptor(randomUUID(), input);
    const attributes = detachedOperationAttributes(input, operationName, authType);
    const component = executions.beginComponent(descriptor, "invoke_agent", attributes, businessScopeParent(descriptor.executionId));
    const modelAttributes = detachedModelAttributes(input, attributes);
    const modelSpan = startDetachedModelSpan(input, modelAttributes, component);
    return { attributes: modelAttributes, component, modelSpan };
}
function detachedModelAttributes(input, attributes) {
    return {
        ...attributes,
        [ATTR_GEN_AI_OPERATION_NAME]: GEN_AI_OPERATION_CHAT,
        [ATTR_GEN_AI_REQUEST_MODEL]: input.modelId,
    };
}
function startDetachedModelSpan(input, attributes, component) {
    return telemetry.startSpan(`${GEN_AI_OPERATION_CHAT} ${input.modelId}`, {
        attributes,
        kind: SpanKind.CLIENT,
        parent: component.span.context,
    });
}
function finishDetachedOperation(component, modelSpan, attributes, result) {
    const usage = usageSnapshot(result);
    const response = responseAttributes(asRecord(result));
    const metricAttributes = {
        ...attributes,
        ...response,
        [ATTR_BLAME_OPERATION_STATUS]: "succeeded",
    };
    modelSpan.setAttributes({
        ...response,
        ...usageAttributes(usage),
    });
    recordDetachedModelMetrics(modelSpan, metricAttributes);
    recordDetachedUsage(usage, metricAttributes, modelSpan.context);
    modelSpan.end("succeeded");
    component.succeed();
}
function recordDetachedModelMetrics(modelSpan, attributes) {
    telemetry.count("blame.model.request.count", 1, attributes, modelSpan.context);
    telemetry.record(METRIC_GEN_AI_OPERATION_DURATION, modelSpan.durationSeconds(), attributes, modelSpan.context);
}
function failDetachedOperation(component, modelSpan, attributes, error) {
    const failureAttributes = {
        ...attributes,
        ...responseAttributes({}, "failed"),
        [ATTR_BLAME_OPERATION_STATUS]: "failed",
        [ATTR_ERROR_TYPE]: "ModelError",
    };
    modelSpan.setAttributes(failureAttributes);
    telemetry.count("blame.model.request.count", 1, failureAttributes, modelSpan.context);
    telemetry.record(METRIC_GEN_AI_OPERATION_DURATION, modelSpan.durationSeconds(), failureAttributes, modelSpan.context);
    countProviderError(failureAttributes, modelSpan.context, error);
    modelSpan.recordError(error).setAttributes(failureAttributes).end("failed");
    component.fail(error);
}
function recordDetachedUsage(usage, attributes, activeContext) {
    recordDetachedTokens(usage, attributes, activeContext);
    recordDetachedValue("blame.gen_ai.cache_read_token.usage", usage.cacheRead, attributes, activeContext);
    recordDetachedValue("blame.gen_ai.cache_creation_token.usage", usage.cacheCreated, attributes, activeContext);
    recordDetachedCost(usage.cost, attributes, activeContext);
}
function recordDetachedTokens(usage, attributes, activeContext) {
    for (const [type, value] of tokenEntries(usage)) {
        if (value <= 0)
            continue;
        telemetry.record(METRIC_GEN_AI_TOKEN_USAGE, value, { ...attributes, "gen_ai.token.type": type }, activeContext);
    }
}
function recordDetachedValue(name, value, attributes, activeContext) {
    if (value <= 0)
        return;
    telemetry.record(name, value, attributes, activeContext);
}
function recordDetachedCost(cost, attributes, activeContext) {
    if (cost <= 0)
        return;
    telemetry.count("blame.gen_ai.estimated_cost", cost, attributes, activeContext);
}
function tokenEntries(usage) {
    return [
        ["input", usage.input],
        ["output", usage.output],
    ];
}
function recordBusinessOperation(component, operationName, baseAttributes, outcome, error) {
    const attributes = {
        ...baseAttributes,
        [ATTR_BLAME_OPERATION_NAME]: operationName,
        "blame.execution.status": outcome,
        ...errorMetric(error),
    };
    telemetry.count(`blame.${operationName}.count`, 1, attributes, component.span.context);
    telemetry.record(`blame.${operationName}.duration`, component.span.durationSeconds(), attributes, component.span.context);
    if (outcome === "failed")
        component.fail(error);
    else
        component.succeed();
}
