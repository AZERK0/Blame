import { authorizeMcpServerOAuth, listMcpServerOAuthStatuses, updateMcpServerOAuthState, } from "@cline/sdk";
export function listMcpOAuthStatuses(filePath) {
    return listMcpServerOAuthStatuses({ filePath }).map((status) => ({
        configured: status.oauthConfigured,
        lastAuthenticatedAt: status.lastAuthenticatedAt,
        lastError: status.lastError,
        serverName: status.serverName,
        supported: status.oauthSupported,
    }));
}
export async function authorizeMcpOAuth(input) {
    return authorizeMcpServerOAuth({
        callbackHost: "127.0.0.1",
        clientName: "Blame",
        clientVersion: "0.0.0",
        filePath: input.filePath,
        openUrl: input.openUrl,
        serverName: input.serverName,
    });
}
export function clearMcpOAuth(filePath, serverName) {
    updateMcpServerOAuthState(serverName, () => ({}), { filePath });
}
