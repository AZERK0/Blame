export function taskComplexityBucket(promptLength, attachmentCount) {
    if (promptLength < 1_000 && attachmentCount === 0)
        return "small";
    if (promptLength < 4_000 && attachmentCount <= 3)
        return "medium";
    return "large";
}
