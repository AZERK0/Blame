console.log(process.execArgv);
