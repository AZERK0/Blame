type DefinitionData =
  | 'string'
  | 'symbol'
  | 'number'
  | 'bigint'
  | 'boolean'
  | 'null'
  | 'undefined'
  | 'void'
  | 'never'
  | 'any'
  | 'unknown'
  | 'object'
  | 'array'
  | 'tuple'
  | 'function'
  | {
      type: 'string';
      value: string;
    }
  | {
      type: 'number';
      value: number;
    }
  | {
      type: 'bigint';
      value: number;
    }
  | {
      type: 'boolean';
      value: boolean;
    }
  | {
      type: 'object';
      entries: {
        key:
          | string
          | { name: string; modifier?: string; type?: DefinitionData };
        optional?: boolean;
        value: DefinitionData;
      }[];
    }
  | {
      type: 'array';
      modifier?: string;
      spread?: boolean;
      item: DefinitionData;
    }
  | {
      type: 'tuple';
      modifier?: string;
      items: DefinitionData[];
    }
  | {
      type: 'function';
      params: {
        spread?: boolean;
        name: string;
        optional?: boolean;
        type: DefinitionData;
      }[];
      return: DefinitionData;
    }
  | {
      type: 'template';
      parts: DefinitionData[];
    }
  | {
      type: 'union';
      options: [DefinitionData, DefinitionData, ...DefinitionData[]];
    }
  | {
      type: 'intersect';
      options: [DefinitionData, DefinitionData, ...DefinitionData[]];
    }
  | {
      type: 'conditional';
      conditions: {
        type: DefinitionData;
        extends: DefinitionData;
        true: DefinitionData;
      }[];
      false: DefinitionData;
    }
  | {
      type: 'custom';
      modifier?: string;
      spread?: boolean;
      name: string;
      href?: string;
      generics?: DefinitionData[];
      indexes?: DefinitionData[];
    };

export type PropertyProps = {
  modifier?: string;
  type: DefinitionData;
  default?: DefinitionData;
};

