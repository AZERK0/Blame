const clineEditTools = new Set(["apply_patch", "editor"]);
export class BenchmarkMetricsCollector {
    activeTools = new Map();
    inputTokens = [];
    spans = [];
    toolsByName = new Map();
    compositionCategories = new Map();
    composedBytes = 0;
    composedRequests = 0;
    compactions = 0;
    duplicateBytes = 0;
    deduplicatedReads = 0;
    editAttempts = 0;
    editBlocked = 0;
    editSuccesses = 0;
    firstEditAttemptAt;
    firstEditSuccessAt;
    hybridCalls = 0;
    latestComposedBytes = 0;
    latestDuplicateBytes = 0;
    latestMessageBytes = 0;
    latestProjectedBytesSaved = 0;
    latestSystemPromptBytes = 0;
    latestToolDefinitionBytes = 0;
    maximumComposedBytes = 0;
    messageBytes = 0;
    navigationBytes = 0;
    patchOperations = 0;
    projectedBytesSaved = 0;
    projectMemoryCandidates = 0;
    projectMemoryInjectedBytes = 0;
    projectMemoryRelevant = 0;
    projectMemoryRequests = 0;
    projectMemorySelected = 0;
    projectMemoryStale = 0;
    readCalls = 0;
    searchCalls = 0;
    symbolOperations = 0;
    staleReadReplacements = 0;
    successfulEditReplacements = 0;
    validatedEditReplacements = 0;
    systemPromptBytes = 0;
    toolDefinitionBytes = 0;
    record(event, recordedAt = Date.now()) {
        if (event.type === "usage")
            return this.recordUsage(event);
        if (event.type === "notice")
            return this.recordNotice(event);
        if (event.type !== "tool")
            return;
        this.recordTool(event, recordedAt);
    }
    summary(startedAt, finishedAt) {
        this.attributeReplayExposure();
        const toolsByName = Object.fromEntries(this.toolsByName);
        const tools = totalToolMetrics(toolsByName);
        return {
            context: this.contextMetrics(tools),
            editing: this.editingMetrics(startedAt),
            navigation: this.navigationMetrics(),
            toolFreeGaps: toolFreeGaps(this.spans, startedAt, finishedAt),
            tools,
            toolsByName,
        };
    }
    recordUsage(event) {
        const usage = recordValue(recordValue(event.payload).usage);
        const inputTokens = numberValue(usage.inputTokens);
        if (inputTokens !== undefined)
            this.inputTokens.push(inputTokens);
    }
    recordNotice(event) {
        const payload = recordValue(event.payload);
        const kind = stringValue(payload.kind) ?? stringValue(payload.reason) ?? "";
        const message = stringValue(payload.message) ?? "";
        if (kind === "context_composed")
            this.recordComposition(payload.metrics);
        if (kind === "project_memory_selected")
            this.recordProjectMemory(payload.metrics);
        if (kind.includes("compaction") && payload.phase === "completed")
            this.compactions += 1;
        else if (message.endsWith("compacted"))
            this.compactions += 1;
    }
    recordProjectMemory(value) {
        const metrics = recordValue(value);
        this.projectMemoryRequests += 1;
        this.projectMemoryCandidates += numberValue(metrics.candidates) ?? 0;
        this.projectMemoryInjectedBytes += numberValue(metrics.bytes) ?? 0;
        this.projectMemoryRelevant += numberValue(metrics.relevant) ?? 0;
        this.projectMemorySelected += numberValue(metrics.selected) ?? 0;
        this.projectMemoryStale += numberValue(metrics.stale) ?? 0;
    }
    recordComposition(value) {
        const metrics = recordValue(value);
        const composedBytes = numberValue(metrics.composedBytes) ?? 0;
        const duplicateBytes = numberValue(metrics.duplicateBytes) ?? 0;
        const messageBytes = numberValue(metrics.messageBytes) ?? 0;
        const projectedBytesSaved = numberValue(metrics.projectedBytesSaved) ?? 0;
        const systemPromptBytes = numberValue(metrics.systemPromptBytes) ?? 0;
        const toolDefinitionBytes = numberValue(metrics.toolDefinitionBytes) ?? 0;
        this.composedRequests += 1;
        this.composedBytes += composedBytes;
        this.duplicateBytes += duplicateBytes;
        this.messageBytes += messageBytes;
        this.projectedBytesSaved += projectedBytesSaved;
        this.systemPromptBytes += systemPromptBytes;
        this.toolDefinitionBytes += toolDefinitionBytes;
        this.latestComposedBytes = composedBytes;
        this.latestDuplicateBytes = duplicateBytes;
        this.latestMessageBytes = messageBytes;
        this.latestProjectedBytesSaved = projectedBytesSaved;
        this.latestSystemPromptBytes = systemPromptBytes;
        this.latestToolDefinitionBytes = toolDefinitionBytes;
        this.maximumComposedBytes = Math.max(this.maximumComposedBytes, composedBytes);
        this.staleReadReplacements += numberValue(metrics.staleReadsReplaced) ?? 0;
        this.successfulEditReplacements +=
            numberValue(metrics.successfulEditsReplaced) ?? 0;
        this.validatedEditReplacements +=
            numberValue(metrics.validatedEditsReplaced) ?? 0;
        this.recordCompositionCategories(metrics.categories);
    }
    recordCompositionCategories(value) {
        const categories = recordValue(value);
        for (const [category, bytes] of Object.entries(categories)) {
            const amount = numberValue(bytes);
            if (amount === undefined)
                continue;
            this.compositionCategories.set(category, (this.compositionCategories.get(category) ?? 0) + amount);
        }
    }
    recordTool(event, recordedAt) {
        const payload = recordValue(event.payload);
        const call = recordValue(payload.toolCall);
        const tool = stringValue(payload.toolName) ?? stringValue(call.name) ?? "unknown";
        const id = stringValue(payload.toolCallId) ?? stringValue(call.id) ?? tool;
        if (payload.phase === "started")
            this.activeTools.set(id, {
                input: call.input,
                startedAt: recordedAt,
                tool,
            });
        if (payload.phase === "finished")
            this.finishTool(id, tool, call.input, payload, recordedAt);
    }
    finishTool(id, fallbackTool, fallbackInput, payload, finishedAt) {
        const active = this.activeTools.get(id);
        this.activeTools.delete(id);
        const tool = active?.tool ?? fallbackTool;
        const input = active?.input ?? fallbackInput;
        const output = payload.output;
        const metric = this.namedToolMetric(tool);
        const inputBytes = serializedBytes(input);
        const outputBytes = serializedBytes(output);
        updateToolMetric(metric, inputBytes, outputBytes, output, payload);
        this.spans.push({
            finishedAt,
            inputBytes,
            outputBytes,
            startedAt: active?.startedAt ?? finishedAt,
            tool,
            usageCount: this.inputTokens.length,
        });
        this.recordToolKind(tool, input, output, active?.startedAt ?? finishedAt, finishedAt);
    }
    namedToolMetric(tool) {
        const existing = this.toolsByName.get(tool);
        if (existing)
            return existing;
        const metric = emptyNamedToolMetrics();
        this.toolsByName.set(tool, metric);
        return metric;
    }
    recordToolKind(tool, input, output, startedAt, finishedAt) {
        if (tool === "edit_code")
            this.recordEdit(input, output, startedAt, finishedAt, "blame");
        if (clineEditTools.has(tool))
            this.recordEdit(input, output, startedAt, finishedAt, "cline");
        if (tool === "read_code" || tool === "read_files")
            this.recordRead(tool, input, output);
        if (tool === "search_code" || tool === "search_codebase")
            this.recordSearch(tool, input, output);
    }
    recordEdit(input, output, startedAt, finishedAt, harness) {
        this.editAttempts += 1;
        this.firstEditAttemptAt ??= startedAt;
        const operations = harness === "blame"
            ? arrayValue(recordValue(input).operations).map(recordValue)
            : [{ kind: "patch" }];
        const kinds = new Set(operations.map(({ kind }) => kind));
        this.symbolOperations += operations.filter(({ kind }) => kind === "symbol").length;
        this.patchOperations += operations.filter(({ kind }) => kind === "patch").length;
        if (kinds.has("symbol") && kinds.has("patch"))
            this.hybridCalls += 1;
        if (editRejected(output))
            this.editBlocked += 1;
        if (!editSucceeded(output, harness))
            return;
        this.editSuccesses += 1;
        this.firstEditSuccessAt ??= finishedAt;
    }
    recordRead(tool, input, output) {
        const requestedFiles = arrayValue(recordValue(input).files).length;
        this.readCalls += tool === "read_files" ? Math.max(1, requestedFiles) : 1;
        const data = recordValue(recordValue(output).data);
        if (data.status === "already_in_context")
            this.deduplicatedReads += 1;
        this.navigationBytes += serializedBytes(output);
    }
    recordSearch(tool, input, output) {
        const requestedQueries = arrayValue(recordValue(input).queries).length;
        this.searchCalls +=
            tool === "search_codebase" ? Math.max(1, requestedQueries) : 1;
        this.navigationBytes += serializedBytes(output);
    }
    contextMetrics(tools) {
        const totalInput = this.inputTokens.reduce((sum, value) => sum + value, 0);
        return {
            averageInputTokens: roundedAverage(totalInput, this.inputTokens.length),
            composition: this.compositionMetrics(),
            compactions: this.compactions,
            maximumInputTokens: Math.max(0, ...this.inputTokens),
            modelRequests: this.inputTokens.length,
            projectMemory: this.projectMemoryMetrics(),
            toolPayloadBytes: tools.inputBytes + tools.outputBytes,
            toolPayloadReplayExposureBytes: this.replayExposureBytes(),
        };
    }
    projectMemoryMetrics() {
        return {
            candidates: this.projectMemoryCandidates,
            injectedBytes: this.projectMemoryInjectedBytes,
            relevant: this.projectMemoryRelevant,
            requests: this.projectMemoryRequests,
            selected: this.projectMemorySelected,
            stale: this.projectMemoryStale,
        };
    }
    compositionMetrics() {
        return {
            categoryBytes: Object.fromEntries(this.compositionCategories),
            composedBytes: this.composedBytes,
            duplicateBytes: this.duplicateBytes,
            latestComposedBytes: this.latestComposedBytes,
            latestDuplicateBytes: this.latestDuplicateBytes,
            latestMessageBytes: this.latestMessageBytes,
            latestProjectedBytesSaved: this.latestProjectedBytesSaved,
            latestSystemPromptBytes: this.latestSystemPromptBytes,
            latestToolDefinitionBytes: this.latestToolDefinitionBytes,
            maximumComposedBytes: this.maximumComposedBytes,
            messageBytes: this.messageBytes,
            projectedBytesSaved: this.projectedBytesSaved,
            requests: this.composedRequests,
            staleReadReplacements: this.staleReadReplacements,
            successfulEditReplacements: this.successfulEditReplacements,
            validatedEditReplacements: this.validatedEditReplacements,
            systemPromptBytes: this.systemPromptBytes,
            toolDefinitionBytes: this.toolDefinitionBytes,
        };
    }
    replayExposureBytes() {
        const requests = this.inputTokens.length;
        return this.spans.reduce((total, span) => total +
            (span.inputBytes + span.outputBytes) *
                Math.max(0, requests - span.usageCount), 0);
    }
    attributeReplayExposure() {
        for (const metric of this.toolsByName.values())
            metric.replayExposureBytes = 0;
        const requests = this.inputTokens.length;
        for (const span of this.spans) {
            const metric = this.toolsByName.get(span.tool);
            if (!metric)
                continue;
            metric.replayExposureBytes +=
                (span.inputBytes + span.outputBytes) *
                    Math.max(0, requests - span.usageCount);
        }
    }
    editingMetrics(startedAt) {
        return {
            attempts: this.editAttempts,
            blocked: this.editBlocked,
            ...(this.firstEditAttemptAt === undefined
                ? {}
                : { firstAttemptMs: this.firstEditAttemptAt - startedAt.getTime() }),
            ...(this.firstEditSuccessAt === undefined
                ? {}
                : { firstSuccessMs: this.firstEditSuccessAt - startedAt.getTime() }),
            hybridCalls: this.hybridCalls,
            patchOperations: this.patchOperations,
            successful: this.editSuccesses,
            symbolOperations: this.symbolOperations,
        };
    }
    navigationMetrics() {
        return {
            deduplicatedReads: this.deduplicatedReads,
            readCalls: this.readCalls,
            returnedBytes: this.navigationBytes,
            searchCalls: this.searchCalls,
        };
    }
}
function updateToolMetric(metric, inputBytes, outputBytes, output, payload) {
    const result = recordValue(output);
    metric.calls += 1;
    metric.inputBytes += inputBytes;
    metric.outputBytes += outputBytes;
    if (result.status === "blocked")
        metric.blockedCalls += 1;
    if (payload.success === false || outputFailed(output))
        metric.failedCalls += 1;
}
function editRejected(output) {
    const result = recordValue(output);
    return result.status === "blocked" || outputFailed(output);
}
function editSucceeded(output, harness) {
    const result = recordValue(output);
    if (harness === "blame")
        return result.status === "ok" && recordValue(result.data).changed === true;
    return result.success === true;
}
function outputFailed(output) {
    if (Array.isArray(output))
        return output.some((item) => outputFailed(item));
    const result = recordValue(output);
    return (result.status === "failed" ||
        result.isError === true ||
        result.success === false);
}
function totalToolMetrics(tools) {
    const total = emptyNamedToolMetrics();
    for (const metric of Object.values(tools)) {
        total.calls += metric.calls;
        total.inputBytes += metric.inputBytes;
        total.outputBytes += metric.outputBytes;
        total.blockedCalls += metric.blockedCalls;
        total.failedCalls += metric.failedCalls;
        total.replayExposureBytes += metric.replayExposureBytes;
    }
    return { ...total, distinctTools: Object.keys(tools).length };
}
function toolFreeGaps(spans, startedAt, finishedAt) {
    const intervals = mergedIntervals(spans);
    const gaps = intervalGaps(intervals, startedAt.getTime(), finishedAt.getTime());
    const longGaps = gaps.filter((duration) => duration > 30_000);
    return {
        countOverThirtySeconds: longGaps.length,
        maximumMs: Math.max(0, ...gaps),
        totalOverThirtySecondsMs: longGaps.reduce((sum, value) => sum + value, 0),
    };
}
function mergedIntervals(spans) {
    const ordered = spans
        .map(({ startedAt, finishedAt }) => [startedAt, finishedAt])
        .sort((left, right) => left[0] - right[0]);
    const merged = [];
    for (const [start, end] of ordered)
        mergeInterval(merged, start, end);
    return merged;
}
function mergeInterval(intervals, start, end) {
    const previous = intervals.at(-1);
    if (!previous || start > previous[1])
        intervals.push([start, end]);
    else
        previous[1] = Math.max(previous[1], end);
}
function intervalGaps(intervals, startedAt, finishedAt) {
    const gaps = [];
    let cursor = startedAt;
    for (const [start, end] of intervals) {
        if (start > cursor)
            gaps.push(start - cursor);
        cursor = Math.max(cursor, end);
    }
    if (finishedAt > cursor)
        gaps.push(finishedAt - cursor);
    return gaps;
}
function emptyNamedToolMetrics() {
    return {
        blockedCalls: 0,
        calls: 0,
        failedCalls: 0,
        inputBytes: 0,
        outputBytes: 0,
        replayExposureBytes: 0,
    };
}
function roundedAverage(total, count) {
    return count ? Math.round((total / count) * 100) / 100 : 0;
}
function serializedBytes(value) {
    if (value === undefined)
        return 0;
    try {
        return Buffer.byteLength(JSON.stringify(value));
    }
    catch {
        return Buffer.byteLength(String(value));
    }
}
function recordValue(value) {
    return value && typeof value === "object" && !Array.isArray(value)
        ? value
        : {};
}
function arrayValue(value) {
    return Array.isArray(value) ? value : [];
}
function stringValue(value) {
    return typeof value === "string" ? value : undefined;
}
function numberValue(value) {
    return typeof value === "number" && Number.isFinite(value)
        ? value
        : undefined;
}
