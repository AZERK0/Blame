export * from './trimEnd.ts';
