export * from './startsWith.ts';
