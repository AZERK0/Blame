export * from './notWords.ts';
