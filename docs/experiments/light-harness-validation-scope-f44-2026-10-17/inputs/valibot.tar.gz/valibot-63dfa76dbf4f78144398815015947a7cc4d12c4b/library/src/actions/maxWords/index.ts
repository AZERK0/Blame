export * from './maxWords.ts';
