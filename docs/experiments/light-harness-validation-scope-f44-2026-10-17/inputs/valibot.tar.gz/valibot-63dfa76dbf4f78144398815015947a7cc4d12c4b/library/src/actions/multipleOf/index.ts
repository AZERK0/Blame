export * from './multipleOf.ts';
