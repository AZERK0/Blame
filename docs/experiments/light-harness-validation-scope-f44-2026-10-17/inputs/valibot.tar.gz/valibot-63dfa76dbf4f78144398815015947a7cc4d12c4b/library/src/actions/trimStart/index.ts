export * from './trimStart.ts';
