export * from './toUpperCase.ts';
