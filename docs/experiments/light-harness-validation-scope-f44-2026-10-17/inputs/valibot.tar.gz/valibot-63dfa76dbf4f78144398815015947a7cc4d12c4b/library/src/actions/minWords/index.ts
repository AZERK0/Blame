export * from './minWords.ts';
